import { world, system } from '@minecraft/server';
import { gabrielTier } from './difficulty.js';

const BOSS = 'gabriel:gabriel';
const DIMS = ['overworld', 'nether', 'the_end'];
const HIT_RADIUS = 1.7;
const HIT_DROP = 0.9;
const BOSS_RADIUS = 2.6;
const BOSS_CENTER = 1.7;
const MAX_STEP = 0.75;
const REFLECT_BOOST = 1.3;
const REFLECT_TURN = 14;
const AIM_HEIGHT = 1.0;
const MIN_TRACK_DIST = 4;
const MAX_TRACK_ANGLE = 100;
const NON_PLAYER_TURN = { 'gabriel:sword_beam': 4, 'gabriel:light_greatsword': 4, 'gabriel:light_axe': 5, 'gabriel:sword_throw': 6 };

const KINDS = {
  'gabriel:sword_beam': {
    speed: [3.752, 4.2, 5.4, 6.0],
    turn: 0,
    life: 160,
    hit: 'gabriel/impact_sword_beam',
    end: 'gabriel/end_sword_beam',
    parry: 40,
  },
  'gabriel:sword_throw': {
    speed: [2.124, 2.38, 3.06, 3.4],
    turn: 1.6,
    life: 600,
    hit: 'gabriel/impact_sword_throw',
    end: 'gabriel/end_sword_throw',
    parry: 80,
  },
  'gabriel:light_axe': {
    speed: [2.248, 2.52, 3.24, 3.6],
    turn: 1.8,
    life: 160,
    hit: 'gabriel/impact_light_axe',
    end: 'gabriel/end_light_axe',
    parry: 40,
  },
  'gabriel:light_greatsword': {
    speed: [2.376, 2.66, 3.42, 3.8],
    turn: 0,
    life: 160,
    hit: 'gabriel/impact_light_greatsword',
    end: 'gabriel/end_light_greatsword',
    parry: 40,
  },
};

const flights = new Map();

const sub = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
const len = (a) => Math.hypot(a.x, a.y, a.z);
const norm = (a) => {
  const l = len(a) || 1;
  return { x: a.x / l, y: a.y / l, z: a.z / l };
};
const dot = (a, b) => a.x * b.x + a.y * b.y + a.z * b.z;

function tierSpeed() {
  return gabrielTier().proj;
}

function variantOf(e) {
  try {
    const c = e.getComponent('minecraft:mark_variant');
    const v = c ? c.value : 0;
    return v >= 1 && v <= 4 ? v : 0;
  } catch (e2) {
    return 0;
  }
}

function steer(dir, want, maxDeg) {
  const c = Math.max(-1, Math.min(1, dot(dir, want)));
  const ang = (Math.acos(c) * 180) / Math.PI;
  if (ang <= maxDeg) return want;
  const t = maxDeg / ang;
  return norm({
    x: dir.x * (1 - t) + want.x * t,
    y: dir.y * (1 - t) + want.y * t,
    z: dir.z * (1 - t) + want.z * t,
  });
}

function angleBetween(a, b) {
  return (Math.acos(Math.max(-1, Math.min(1, dot(a, b)))) * 180) / Math.PI;
}

function targetOf(e) {
  try {
    const list = e.dimension.getEntities({ tags: ['gtgt'], location: e.location, maxDistance: 128, closest: 1 });
    return list.length ? list[0] : undefined;
  } catch (err) {
    return undefined;
  }
}

function bossOf(e) {
  try {
    const list = e.dimension.getEntities({ type: BOSS, location: e.location, maxDistance: 256, closest: 1 });
    return list.length ? list[0] : undefined;
  } catch (err) {
    return undefined;
  }
}

function bodyOf(v) {
  const feet = v.location.y;
  let head = feet + 1.6;
  try {
    head = v.getHeadLocation().y;
  } catch (err) {}
  const height = Math.max(head - feet, 0.6);
  return { feet, height, center: feet + height * 0.55 };
}

function velocityOf(v) {
  try {
    return v.getVelocity();
  } catch (err) {
    return { x: 0, y: 0, z: 0 };
  }
}

function isVictim(v) {
  try {
    if (!v || !v.isValid) return false;
    if (v.typeId === 'minecraft:player') {
      const g = String(v.getGameMode()).toLowerCase();
      return g !== 'creative' && g !== 'spectator';
    }
    return v.hasTag('gabriel_target') || v.matches({ families: ['sam'] });
  } catch (err) {
    return false;
  }
}

function solid(dim, p) {
  try {
    const b = dim.getBlock({ x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z) });
    if (!b) return true;
    return !b.isAir && !b.isLiquid;
  } catch (err) {
    return true;
  }
}

function isStruck(v) {
  try {
    if (!v || !v.isValid) return false;
    if (v.typeId === 'minecraft:player') {
      const g = String(v.getGameMode()).toLowerCase();
      return g !== 'creative' && g !== 'spectator';
    }
    return !!v.getComponent('minecraft:health');
  } catch (err) {
    return false;
  }
}

function strikesVictim(dim, p, any) {
  try {
    const list = dim.getEntities({
      location: p,
      maxDistance: 6,
      excludeFamilies: ['gabriel', 'gabriel_projectile', 'inanimate'],
    });
    for (const v of list) {
      if (!(any ? isStruck(v) : isVictim(v))) continue;
      const b = bodyOf(v);
      const horizontal = Math.hypot(p.x - v.location.x, p.z - v.location.z);
      const below = b.feet - 0.4 - p.y;
      const above = p.y - (b.feet + b.height + 0.4);
      if (horizontal <= HIT_RADIUS + 0.3 && below <= 0 && above <= 0) return v;
    }
  } catch (err) {}
  return undefined;
}

function aftermath(dim, p, typeId) {
  if (typeId !== 'gabriel:sword_beam' && typeId !== 'gabriel:sword_throw') return;
  try {
    dim.spawnParticle('gabriel:blast_shell', p);
    dim.spawnParticle('gabriel:blast_core', p);
    dim.spawnParticle('gabriel:blast_bolts', p);
  } catch (err) {}
  try {
    for (const v of dim.getEntities({ location: p, maxDistance: 4.5, excludeFamilies: ['gabriel', 'gabriel_projectile', 'inanimate'] })) {
      if (isVictim(v)) v.setOnFire(5, true);
    }
  } catch (err) {}
  try {
    if (!world.gameRules.mobGriefing) return;
    const r = 3.5;
    for (let dx = -3; dx <= 3; dx++) {
      for (let dz = -3; dz <= 3; dz++) {
        const d = Math.hypot(dx, dz);
        if (d > r) continue;
        const top = dim.getTopmostBlock({ x: Math.floor(p.x) + dx, z: Math.floor(p.z) + dz }, Math.floor(p.y) + 6);
        if (!top || top.isLiquid || top.isAir) continue;
        const id = top.typeId;
        if (id === 'minecraft:bedrock' || id.includes('leaves') || id.includes('log') || id.includes('chest')) continue;
        top.setType(d < 1.8 ? 'minecraft:gravel' : 'minecraft:coarse_dirt');
      }
    }
  } catch (err) {}
}

function pose(e, p, dir) {
  const flat = Math.hypot(dir.x, dir.z);
  const yaw = (Math.atan2(-dir.x, dir.z) * 180) / Math.PI;
  const pitch = (-Math.atan2(dir.y, flat) * 180) / Math.PI;
  try {
    e.teleport(p, { rotation: { x: pitch, y: yaw } });
  } catch (err) {}
}

function run(e, fn) {
  try {
    e.runCommand('function ' + fn);
  } catch (err) {
    try {
      e.triggerEvent('gabriel:despawn');
    } catch (err2) {}
  }
}

function fizzle(e, p) {
  try {
    e.dimension.runCommand('playsound gabriel.weapon_break @a ' + p.x + ' ' + p.y + ' ' + p.z + ' 125');
  } catch (err) {}
  try {
    e.dimension.spawnParticle('minecraft:large_explosion', p);
  } catch (err) {}
  try {
    e.dimension.runCommand('playsound gabriel.sword.break @a ' + p.x + ' ' + p.y + ' ' + p.z + ' 2');
  } catch (err) {}
  try {
    e.triggerEvent('gabriel:despawn');
  } catch (err) {
    try {
      e.remove();
    } catch (err2) {}
  }
}

function reflect(e, st, kind) {
  const boss = bossOf(e);
  if (!boss) {
    fizzle(e, e.location);
    return;
  }
  st.parried = true;
  st.speed *= REFLECT_BOOST;
  const c = { x: boss.location.x, y: boss.location.y + BOSS_CENTER, z: boss.location.z };
  st.dir = norm(sub(c, e.location));
  try {
    e.dimension.runCommand('playsound random.anvil_land @a ' + e.location.x + ' ' + e.location.y + ' ' + e.location.z + ' 3 1.6');
  } catch (err) {}
  try {
    e.dimension.spawnParticle('minecraft:totem_particle', e.location);
  } catch (err) {}
}

function strikeBoss(e, st, kind, boss) {
  let amount = kind.parry;
  try {
    if (boss.getProperty('gabriel:form') === 1) amount *= 2;
  } catch (err) {}
  try {
    boss.applyDamage(amount);
  } catch (err) {}
  fizzle(e, e.location);
}

function advance(e, st, kind) {
  st.age++;
  const typeId = e.typeId;
  if (e.hasTag('gdone')) return;
  if (st.age % 5 === 0 && (typeId === 'gabriel:light_greatsword' || typeId === 'gabriel:light_axe' || typeId === 'gabriel:sword_throw')) {
    try {
      const l = e.location;
      e.dimension.runCommand('playsound gabriel.swing_loop @a ' + l.x + ' ' + l.y + ' ' + l.z + ' 60');
    } catch (err) {}
  }

  let v = st.variant;
  if (!v) {
    v = variantOf(e);
    if (!v) {
      if (st.age < 3) return;
      v = 1;
    }
    st.variant = v;
    st.speed = kind.speed[v - 1] * tierSpeed();
  }

  if (e.hasTag('gparry')) {
    try {
      e.removeTag('gparry');
    } catch (err) {}
    if (!st.parried) reflect(e, st, kind);
  }

  if (st.age > kind.life) {
    if (st.parried) fizzle(e, e.location);
    else run(e, kind.end);
    return;
  }

  let pos = e.location;
  let boss;
  if (st.parried) {
    boss = bossOf(e);
    if (!boss) {
      fizzle(e, pos);
      return;
    }
    const c = { x: boss.location.x, y: boss.location.y + BOSS_CENTER, z: boss.location.z };
    st.dir = steer(st.dir, norm(sub(c, pos)), REFLECT_TURN);
  } else {
    const t = targetOf(e);
    if (t) {
      const b = bodyOf(t);
      if (!st.aimed) {
        st.aimed = true;
        const vel = velocityOf(t);
        const dist0 = len(sub({ x: t.location.x, y: b.center, z: t.location.z }, pos));
        const ticks = Math.min(40, dist0 / Math.max(st.speed, 0.5));
        const lead = { x: t.location.x + vel.x * ticks, y: b.center + vel.y * ticks * 0.5, z: t.location.z + vel.z * ticks };
        st.dir = norm(sub(lead, pos));
      }
      const isPlayer = t.typeId === 'minecraft:player';
      const extra = NON_PLAYER_TURN[typeId] || 0;
      const turn = kind.turn > 0 ? (isPlayer ? kind.turn : Math.max(kind.turn, extra)) : isPlayer ? 0 : extra;
      if (turn > 0) {
        const d = sub({ x: t.location.x, y: b.center, z: t.location.z }, pos);
        if (len(d) > MIN_TRACK_DIST) {
          const want = norm(d);
          if (angleBetween(st.dir, want) < MAX_TRACK_ANGLE) st.dir = steer(st.dir, want, turn);
        }
      }
    }
  }

  const dim = e.dimension;
  const steps = Math.max(1, Math.ceil(st.speed / MAX_STEP));
  const each = st.speed / steps;
  for (let i = 0; i < steps; i++) {
    const prev = pos;
    pos = { x: pos.x + st.dir.x * each, y: pos.y + st.dir.y * each, z: pos.z + st.dir.z * each };
    if (solid(dim, pos)) {
      if (!st.parried && typeId === 'gabriel:sword_throw') {
        pose(e, prev, st.dir);
        run(e, kind.hit);
        aftermath(dim, prev, typeId);
        return;
      }
      pose(e, pos, st.dir);
      if (st.parried) fizzle(e, pos);
      else {
        run(e, kind.end);
        aftermath(dim, pos, typeId);
      }
      return;
    }
    if (st.parried) {
      const c = { x: boss.location.x, y: boss.location.y + BOSS_CENTER, z: boss.location.z };
      if (len(sub(c, pos)) <= BOSS_RADIUS) {
        pose(e, pos, st.dir);
        strikeBoss(e, st, kind, boss);
        return;
      }
    } else {
      const v = strikesVictim(dim, pos, typeId === 'gabriel:sword_throw');
      if (v) {
        const b = bodyOf(v);
        const at = { x: v.location.x, y: b.feet + 1.1, z: v.location.z };
        pose(e, at, st.dir);
        run(e, kind.hit);
        aftermath(dim, at, typeId);
        return;
      }
    }
  }
  pose(e, pos, st.dir);
  try {
    dim.spawnParticle(st.parried ? 'minecraft:totem_particle' : 'minecraft:endrod', pos);
  } catch (err) {}
}

system.runInterval(() => {
  const seen = new Set();
  for (const d of DIMS) {
    let list = [];
    try {
      list = world.getDimension(d).getEntities({ families: ['gabriel_projectile'] });
    } catch (err) {}
    for (const e of list) {
      const kind = KINDS[e.typeId];
      if (!kind) continue;
      seen.add(e.id);
      let st = flights.get(e.id);
      if (!st) {
        let dir;
        try {
          dir = norm(e.getViewDirection());
        } catch (err) {
          dir = { x: 0, y: 0, z: 1 };
        }
        st = { dir, speed: 0, variant: 0, age: 0, parried: false };
        flights.set(e.id, st);
      }
      try {
        advance(e, st, kind);
      } catch (err) {}
    }
  }
  for (const id of flights.keys()) if (!seen.has(id)) flights.delete(id);
}, 1);

world.beforeEvents.entityHurt.subscribe((ev) => {
  try {
    const e = ev.hurtEntity;
    if (!e || e.typeId !== 'gabriel:sword_throw') return;
    const src = ev.damageSource;
    const by = src && (src.damagingEntity || src.damagingProjectile);
    if (by && by.matches({ families: ['gabriel'] })) return;
    ev.cancel = true;
    system.run(() => {
      try {
        if (e.isValid) e.addTag('gparry');
      } catch (err) {}
    });
  } catch (err) {}
});
