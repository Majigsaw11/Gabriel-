import { world, system } from '@minecraft/server';
import { TYPE, gabrielTier } from './difficulty.js';
import { applyAntiHeal } from './anti_heal.js';
import { charaDamage, charaTrue, charaStrike } from '../chara_buffs.js';

// Wiki damage (ULTRAKILL wiki, Gabriel page) is used 1:1, same as Minos's DMG table.
// Judge of Hell:   spear dive 25, thrown spear 35, rapier slashes 15, rapier thrust 25,
//                  greatsword swings 35, thrown greatsword 35, twin axes 30, spiral swords 35.
// Apostate of Hate: light combo 20 x4 + 35, medium 30 x2 + 35 + 35, heavy 35 + 45 + 35 thrown,
//                  sword throw 35, spiral swords 35.

const CAUSE_CMD = {
  override: 'override',
  selfDestruct: 'self_destruct',
  entityAttack: 'entity_attack',
  entityExplosion: 'entity_explosion',
  void: 'void',
  sonicBoom: 'sonic_boom',
  blockExplosion: 'block_explosion',
};

const BASE = { melee: 'entityAttack', projectile: 'entityExplosion', spiral: 'entityAttack' };

// Mob Battle only: the damage source changes per hit (joh = Judge of Hell, aoh = Apostate of Hate).
const SOURCES = {
  melee: { joh: ['override', 'selfDestruct'], aoh: ['void', 'sonicBoom'] },
  projectile: { joh: ['entityExplosion', 'blockExplosion'], aoh: ['blockExplosion', 'override'] },
  spiral: { joh: ['selfDestruct'], aoh: ['override'] },
};
const FALLBACK = { melee: 'override', projectile: 'selfDestruct', spiral: 'override' };

let applying = false;

const hpNow = (e) => {
  try {
    return e.getComponent('minecraft:health').currentValue;
  } catch (err) {
    return undefined;
  }
};

function scaled(victim, base, t) {
  let dmg = base * t.dmg;
  if (victim.typeId !== 'minecraft:player' && t.mobPct > 0) {
    let max = 0;
    try {
      max = victim.getComponent('minecraft:health').effectiveMax;
    } catch (e) {}
    dmg = Math.min(t.mobCap, Math.max(dmg, Math.round(max * t.mobPct)));
  }
  return Math.max(1, Math.round(dmg));
}

function pickSource(boss, kind) {
  let form = 0;
  try {
    form = boss.getProperty('gabriel:form');
  } catch (e) {}
  const list = SOURCES[kind][form === 1 ? 'aoh' : 'joh'];
  return list[Math.floor(Math.random() * list.length)];
}

function deliver(boss, victim, dmg, kind, explosion, raw) {
  const t = gabrielTier();
  dmg = Math.round(charaDamage(boss, victim, dmg, raw));
  if (charaTrue(victim)) {
    charaStrike(victim, dmg);
    if (t.antiHeal) applyAntiHeal(victim);
    return;
  }
  const base = explosion ? 'entityExplosion' : BASE[kind];
  let attempts = [base];
  if (t.varied) {
    const picked = pickSource(boss, kind);
    let fb = FALLBACK[kind];
    if (fb === picked) fb = picked === 'override' ? 'selfDestruct' : 'override';
    attempts = [picked, fb];
  }
  const tag = 'gb_src_' + String(boss.id).replace(/[^0-9a-zA-Z]/g, 'n');
  try {
    if (!boss.hasTag(tag)) boss.addTag(tag);
  } catch (e) {}
  system.run(() => {
    applying = true;
    try {
      let ok = false;
      for (const cause of attempts) {
        try {
          if (!victim.isValid || !boss.isValid) break;
          const before = hpNow(victim);
          const r = victim.runCommand(`damage @s ${dmg} ${CAUSE_CMD[cause] || 'entity_attack'} entity @e[tag=${tag},c=1]`);
          if (r && r.successCount > 0) ok = true;
          const after = victim.isValid ? hpNow(victim) : undefined;
          if (after === undefined || before === undefined || after < before - 0.001) break;
        } catch (e) {}
      }
      if (!ok) {
        try {
          if (victim.isValid) victim.applyDamage(dmg, { cause: base, damagingEntity: boss });
        } catch (e) {}
      }
    } finally {
      applying = false;
    }
  });
}

export function hurtAs(boss, victim, amount, kind = 'melee', explosion = false) {
  try {
    if (!boss || !victim || !victim.isValid) return;
    deliver(boss, victim, scaled(victim, amount, gabrielTier()), kind, explosion, amount);
  } catch (e) {}
}

// Commands in animations/functions already carry the wiki number; here the number is scaled
// for mobs and, in Mob Battle, the hit is re-delivered with a different damage source.
world.beforeEvents.entityHurt.subscribe((ev) => {
  if (applying) return;
  const src = ev.damageSource && ev.damageSource.damagingEntity;
  if (!src || src.typeId !== TYPE) return;
  const victim = ev.hurtEntity;
  if (!victim || victim.typeId === TYPE) return;
  const t = gabrielTier();
  const raw = ev.damage;
  const dmg = scaled(victim, raw, t);
  if (!t.varied) {
    ev.damage = dmg;
    return;
  }
  const kind = ev.damageSource.cause === 'entityExplosion' ? 'projectile' : 'melee';
  ev.cancel = true;
  ev.damage = 0;
  system.run(() => {
    try {
      if (victim.isValid && src.isValid) deliver(src, victim, dmg, kind, false, raw);
    } catch (e) {}
  });
});
