import './difficulty.js';
import './armor.js';
import './damage.js';
import './anti_heal.js';
import './target.js';
import './subtitles.js';
import './ai.js';
import './projectiles.js';
import { world, system } from '@minecraft/server';

const TYPE = 'gabriel:gabriel';
const DIMS = ['overworld', 'nether', 'the_end'];
const TRACKS = { 1: 'gabriel.music.p1', 2: 'gabriel.music.p2', 3: 'gabriel.music.p3' };
const RANGE = 80;
const state = new Map();

function stop(p) {
  try {
    p.stopMusic();
  } catch (e) {
    try {
      p.runCommand('music stop 1');
    } catch (e2) {}
  }
}

function play(p, id) {
  try {
    p.playMusic(id, { volume: 1.0, fade: 1.0, loop: true });
  } catch (e) {
    try {
      p.runCommand(`music play ${id} 1 1 loop`);
    } catch (e2) {}
  }
}

function stopAll(s) {
  for (const pid of s.heard) {
    try {
      const p = world.getEntity(pid);
      if (p) stop(p);
    } catch (e) {}
  }
  s.heard = new Set();
}

system.runInterval(() => {
  const seen = new Set();
  for (const d of DIMS) {
    let list = [];
    try {
      list = world.getDimension(d).getEntities({ type: TYPE });
    } catch (e) {}
    for (const g of list) {
      seen.add(g.id);
      let s = state.get(g.id);
      if (!s) {
        s = { track: 0, heard: new Set() };
        state.set(g.id, s);
      }
      let m = 0;
      try {
        m = g.getProperty('gabriel:music') ?? 0;
      } catch (e) {}
      if (m !== s.track) {
        stopAll(s);
        s.track = m;
      }
      if (!m) continue;
      const near = new Set();
      for (const p of g.dimension.getPlayers({ location: g.location, maxDistance: RANGE })) {
        near.add(p.id);
        if (!s.heard.has(p.id)) {
          play(p, TRACKS[m]);
          s.heard.add(p.id);
        }
      }
      for (const pid of [...s.heard]) {
        if (near.has(pid)) continue;
        try {
          const p = world.getEntity(pid);
          if (p) stop(p);
        } catch (e) {}
        s.heard.delete(pid);
      }
    }
  }
  for (const [id, s] of state) {
    if (seen.has(id)) continue;
    stopAll(s);
    state.delete(id);
  }
}, 20);

system.runInterval(() => {
  for (const p of world.getAllPlayers()) {
    if (!p.hasTag('gabriel_cine')) continue;
    let active = false;
    for (const d of DIMS) {
      try {
        for (const g of world.getDimension(d).getEntities({ type: TYPE })) {
          { const st = g.getProperty('gabriel:stage'); if (st === 3 || st === 6) active = true; }
        }
      } catch (e) {}
    }
    if (active) continue;
    for (const c of ['hud @s reset all', 'camera @s clear', 'inputpermission set @s movement enabled', 'inputpermission set @s camera enabled']) {
      try {
        p.runCommand(c);
      } catch (e) {}
    }
    p.removeTag('gabriel_cine');
  }
}, 20);
