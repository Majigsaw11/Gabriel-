import { world } from '@minecraft/server';
import { TYPE, gabrielTier } from './difficulty.js';
import { isGabrielIntro } from '../immortal.js';

const AOH_CUT = 0.85;

function prop(e, name, fallback) {
  try {
    const v = e.getProperty(name);
    return v === undefined ? fallback : v;
  } catch (err) {
    return fallback;
  }
}

world.beforeEvents.entityHurt.subscribe((ev) => {
  const e = ev.hurtEntity;
  if (!e || e.typeId !== TYPE) return;
  if (isGabrielIntro(e)) return;
  const stage = prop(e, 'gabriel:stage', 1);
  if (stage === 0 || stage === 3) return;
  try {
    if (e.hasTag('gabriel_stunned')) return;
  } catch (err) {}

  let max = 0;
  try {
    max = e.getComponent('minecraft:health').effectiveMax;
  } catch (err) {}

  const t = gabrielTier();
  let dmg = ev.damage;
  if (max > 0) dmg = Math.min(dmg, max * t.armorCap);
  if (prop(e, 'gabriel:form', 0) === 1) dmg *= AOH_CUT;
  ev.damage = Math.max(1, Math.round(dmg));
});
