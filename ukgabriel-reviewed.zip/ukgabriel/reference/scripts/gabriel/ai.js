import { world, system } from '@minecraft/server';
import { gabrielTier, applyTier } from './difficulty.js';
import { openHealWindow } from './anti_heal.js';
import { hurtAs } from './damage.js';
import './armor.js';
import { markSettingsSpawn } from '../summon_rules.js';
import './target.js';

const TYPE = 'gabriel:gabriel';
const DIMS = ['overworld', 'nether', 'the_end'];
const TARGET_RANGE = 64;
const LEASH = 22;
const CATCH_UP = 1.1;
const CLOSE_DIST = 2.0;
const CLOSE_SPEED = 1.6;
const ENGAGE_RANGE = 14;
const ORBIT_MIN = 6;
const ORBIT_MAX = 9.5;
const ORBIT_FAR = 26;
const HOVER_ABOVE = 1.8;
const VERT_STEP = 0.22;
const ACTIVE_STAGES = [1, 2, 4, 5];
const SPEED = { 1: 0.46, 2: 0.54, 4: 0.62, 5: 0.7 };
const GAP = { 1: 10, 2: 8, 4: 6, 5: 5 };
const states = new Map();
let bosses = [];
let tick = 0;

const sub = (a, b) => ({ x: a.x - b.x, y: a.y - b.y, z: a.z - b.z });
const len = (a) => Math.hypot(a.x, a.y, a.z);
const yawOf = (dx, dz) => (Math.atan2(-dx, dz) * 180) / Math.PI;

function prop(e, name, fallback) {
  try {
    const v = e.getProperty(name);
    return v === undefined ? fallback : v;
  } catch (e2) {
    return fallback;
  }
}

function setProp(e, name, value) {
  try {
    e.setProperty(name, value);
  } catch (e2) {}
}

function alive(e) {
  try {
    if (!e || !e.isValid) return false;
    const h = e.getComponent('minecraft:health');
    return !h || h.currentValue > 0;
  } catch (e2) {
    return false;
  }
}

function gameMode(p) {
  try {
    return String(p.getGameMode()).toLowerCase();
  } catch (e) {
    return 'survival';
  }
}

function nearest(list, from) {
  let best;
  let bd = Infinity;
  for (const e of list) {
    const d = len(sub(e.location, from));
    if (d < bd) {
      bd = d;
      best = e;
    }
  }
  return best;
}

function findMob(boss) {
  const dim = boss.dimension;
  const loc = boss.location;
  try {
    const tagged = dim
      .getEntities({ location: loc, maxDistance: TARGET_RANGE, tags: ['gabriel_target'], excludeFamilies: ['gabriel', 'inanimate', 'gabriel_projectile'] })
      .filter((e) => e.typeId !== 'minecraft:player' && alive(e));
    const t = nearest(tagged, loc);
    if (t) return t;
  } catch (e) {}
  try {
    const sam = dim.getEntities({ location: loc, maxDistance: TARGET_RANGE, families: ['sam'], excludeFamilies: ['gabriel'] }).filter((e) => alive(e));
    return nearest(sam, loc);
  } catch (e) {}
  return undefined;
}

function findTarget(boss, preferMob) {
  const dim = boss.dimension;
  const loc = boss.location;
  if (preferMob) {
    const m = findMob(boss);
    if (m) return m;
  }
  try {
    const players = dim
      .getPlayers({ location: loc, maxDistance: TARGET_RANGE })
      .filter((p) => {
        const g = gameMode(p);
        return g !== 'creative' && g !== 'spectator' && alive(p);
      });
    const p = nearest(players, loc);
    if (p) return p;
  } catch (e) {}
  try {
    const tagged = dim
      .getEntities({
        location: loc,
        maxDistance: TARGET_RANGE,
        tags: ['gabriel_target'],
        excludeFamilies: ['gabriel', 'inanimate', 'gabriel_projectile'],
      })
      .filter((e) => e.typeId !== 'minecraft:player' && alive(e));
    const t = nearest(tagged, loc);
    if (t) return t;
  } catch (e) {}
  try {
    const sam = dim
      .getEntities({
        location: loc,
        maxDistance: TARGET_RANGE,
        families: ['sam'],
        excludeFamilies: ['gabriel'],
      })
      .filter((e) => alive(e));
    return nearest(sam, loc);
  } catch (e) {}
  return undefined;
}

function taggedTarget(boss) {
  try {
    const list = boss.dimension.getEntities({ tags: ['gtgt'], location: boss.location, maxDistance: 96 });
    return nearest(list.filter(alive), boss.location);
  } catch (e) {}
  return undefined;
}

function markTarget(s, t) {
  if (t) {
    try {
      if (s.tagId === t.id && t.hasTag('gtgt')) return;
    } catch (e) {}
  } else if (!s.tagId) {
    return;
  }
  try {
    (t || world.getEntity(s.tagId)).dimension.runCommand('tag @e[tag=gtgt] remove gtgt');
  } catch (e) {}
  s.tagId = undefined;
  if (t) {
    try {
      t.addTag('gtgt');
      s.tagId = t.id;
    } catch (e) {}
  }
}

function solid(dim, p) {
  try {
    const b = dim.getBlock({ x: Math.floor(p.x), y: Math.floor(p.y), z: Math.floor(p.z) });
    return !!b && !b.isAir && !b.isLiquid;
  } catch (e) {
    return true;
  }
}

function clear(dim, p) {
  return !solid(dim, p) && !solid(dim, { x: p.x, y: p.y + 1.5, z: p.z }) && !solid(dim, { x: p.x, y: p.y + 3, z: p.z });
}

function face(boss, target) {
  try {
    const d = sub(target.location, boss.location);
    boss.setRotation({ x: boss.getRotation().x, y: yawOf(d.x, d.z) });
  } catch (e) {}
}

function stepTo(boss, goal, speed, target) {
  const from = boss.location;
  const d = sub(goal, from);
  const dist = len(d);
  if (dist < 0.05) return;
  const k = Math.min(1, speed / dist);
  const next = { x: from.x + d.x * k, y: from.y + d.y * k, z: from.z + d.z * k };
  const dim = boss.dimension;
  let dest = next;
  if (!clear(dim, dest)) {
    dest = { x: next.x, y: from.y + VERT_STEP, z: next.z };
    if (!clear(dim, dest)) dest = { x: from.x, y: from.y + VERT_STEP, z: from.z };
    if (!clear(dim, dest)) return;
  }
  try {
    const dd = sub(target.location, dest);
    boss.teleport(dest, { dimension: dim, rotation: { x: 0, y: yawOf(dd.x, dd.z) } });
  } catch (e) {}
}

system.afterEvents.scriptEventReceive.subscribe((ev) => {
  if (ev.id === 'gabriel:ground') {
    const boss = ev.sourceEntity;
    if (!boss || boss.typeId !== TYPE) return;
    const lift = parseFloat(ev.message) || 0;
    try {
      const hit = boss.dimension.getBlockFromRay(boss.location, { x: 0, y: -1, z: 0 }, { maxDistance: 96, includeLiquidBlocks: false, includePassableBlocks: false });
      if (hit) boss.teleport({ x: boss.location.x, y: hit.block.location.y + 1 + lift, z: boss.location.z });
    } catch (e) {}
    return;
  }
  if (ev.id === 'gabriel:skip_aoh_intro') {
    const p = ev.sourceEntity;
    let skipped = false;
    for (const d of DIMS) {
      let list = [];
      try {
        list = world.getDimension(d).getEntities({ type: TYPE });
      } catch (e) {}
      for (const b of list) {
        try {
          if (b.getProperty('gabriel:stage') !== 3) continue;
          b.triggerEvent('gabriel:skip_on');
          for (const snd of ['gabriel.intro.phase2', 'gabriel.insignificant', 'gabriel.enrage_end']) b.dimension.runCommand('stopsound @a ' + snd);
          b.runCommand('scriptevent gabriel:sub 0.05| ');
          skipped = true;
        } catch (e) {}
      }
    }
    try {
      if (!skipped && p && p.typeId === 'minecraft:player') p.onScreenDisplay.setActionBar("Gabriel isn't transforming.");
    } catch (e) {}
    return;
  }
  if (ev.id === 'gabriel:summon') {
    const p = ev.sourceEntity;
    if (!p || p.typeId !== 'minecraft:player') return;
    try {
      const v = p.getViewDirection();
      const spawned = p.dimension.spawnEntity(TYPE, { x: p.location.x + v.x * 8, y: p.location.y + 2, z: p.location.z + v.z * 8 });
      markSettingsSpawn(spawned, p);
    } catch (e) {}
    return;
  }
  if (ev.id === 'gabriel:spiral') {
    const sb = ev.sourceEntity;
    if (!sb || sb.typeId !== TYPE) return;
    if ((ev.message || '').trim() === 'strike') startStrike(sb);
    else startOrbit(sb);
    return;
  }
  if (ev.id !== 'gabriel:close') return;
  const b = ev.sourceEntity;
  if (!b || b.typeId !== TYPE) return;
  const s = states.get(b.id);
  if (s) s.close = 6;
});

function closeIn(boss, tg) {
  const from = boss.location;
  const d = sub(tg.location, from);
  const flat = Math.hypot(d.x, d.z);
  if (flat <= CLOSE_DIST) return;
  const step = Math.min(CLOSE_SPEED, flat - CLOSE_DIST);
  stepTo(boss, { x: from.x + (d.x / flat) * step, y: from.y, z: from.z + (d.z / flat) * step }, step, tg);
}


const SWORD = 'gabriel:spiral_sword';
const SENSOR = 'gabriel:orbit_sensor';
const SW_COUNT = 8;
const ORBIT_LIFE = 100;
const STRIKE_PAUSE = 20;
const STRIKE_RADIUS = 4.4;
const STRIKE_SPEED = 0.5;
const STRIKE_BLAST = 3.2;
const STRIKE_DAMAGE = 35;
const swarms = new Map();

function isVictim(e) {
  try {
    if (!e || !e.isValid || !alive(e)) return false;
    if (e.typeId.startsWith('gabriel:')) return false;
    if (e.typeId === 'minecraft:player') {
      const g = gameMode(e);
      return g !== 'creative' && g !== 'spectator';
    }
    return e.hasTag('gabriel_target');
  } catch (err) {
    return false;
  }
}

function hurt(boss, victim, amount, explosion = false) {
  hurtAs(boss, victim, amount, 'spiral', explosion);
}

function killSword(sw, broke) {
  if (broke) {
    try {
      const l = sw.location;
      sw.dimension.runCommand('playsound gabriel.weapon_break @a ' + l.x + ' ' + l.y + ' ' + l.z + ' 125');
    } catch (e) {}
  }
  try {
    sw.remove();
  } catch (e) {
    try {
      sw.triggerEvent('gabriel:despawn');
    } catch (e2) {}
  }
}

function clearSwarm(id) {
  const w = swarms.get(id);
  if (!w) return;
  for (const sw of w.swords) if (sw.ent && !sw.dead) killSword(sw.ent);
  swarms.delete(id);
}

function place(sw, pos, dir) {
  const flat = Math.hypot(dir.x, dir.z);
  const yaw = yawOf(dir.x, dir.z);
  const pitch = (-Math.atan2(dir.y, flat) * 180) / Math.PI;
  try {
    sw.teleport(pos, { rotation: { x: pitch, y: yaw } });
  } catch (e) {}
}

function sound(dim, id, loc) {
  try {
    dim.runCommand('playsound ' + id + ' @a ' + loc.x + ' ' + loc.y + ' ' + loc.z + ' 3');
  } catch (e) {}
}

function spawnSwords(boss, at, type = SWORD) {
  const list = [];
  for (let i = 0; i < SW_COUNT; i++) {
    try {
      list.push({ ent: boss.dimension.spawnEntity(type, at), pos: { ...at }, launched: false, dead: false, age: 0 });
    } catch (e) {}
  }
  return list;
}

function startOrbit(boss) {
  clearSwarm(boss.id);
  const l = boss.location;
  swarms.set(boss.id, { mode: 'orbit', t: 0, boss, swords: spawnSwords(boss, { x: l.x, y: l.y + 1.5, z: l.z }, SENSOR), target: undefined });
  sound(boss.dimension, 'gabriel.sword.spawn', l);
}

function startStrike(boss) {
  const s = states.get(boss.id);
  const target = taggedTarget(boss) || (s && s.target);
  clearSwarm(boss.id);
  if (!target || !alive(target)) return;
  const l = target.location;
  swarms.set(boss.id, { mode: 'strike', t: 0, boss, target, swords: spawnSwords(boss, { x: l.x, y: l.y + 2, z: l.z }), aim: undefined });
  sound(boss.dimension, 'gabriel.sword.spawn', l);
}

function hitNear(w, sw, radius, dmg) {
  let list = [];
  try {
    list = sw.ent.dimension.getEntities({ location: sw.pos, maxDistance: radius, excludeTypes: [SWORD, SENSOR] });
  } catch (e) {}
  for (const e of list) {
    if (isVictim(e)) {
      hurt(w.boss, e, dmg);
      return true;
    }
  }
  return false;
}

function tickOrbit(w) {
  const c = w.boss.location;
  const spin = w.t * 0.314;
  const grow = Math.min(1, w.t / 8);
  w.swords.forEach((sw, i) => {
    if (sw.dead) return;
    const a = spin + (i * Math.PI * 2) / SW_COUNT;
    const r = 0.6 + 1.9 * grow;
    sw.pos = { x: c.x + Math.cos(a) * r, y: c.y + 1.5, z: c.z + Math.sin(a) * r };
    place(sw.ent, sw.pos, { x: Math.cos(a), y: 0, z: Math.sin(a) });
    if (w.t % 2 === 0 && hitNear(w, sw, 1.5, 35)) {
      killSword(sw.ent, true);
      sw.dead = true;
    }
  });
  if (w.t >= ORBIT_LIFE) clearSwarm(w.boss.id);
}

function tickStrike(w) {
  const tg = w.target;
  if (tg && alive(tg) && w.t < STRIKE_PAUSE) w.last = tg.location;
  const c = w.last || w.boss.location;
  const center = { x: c.x, y: c.y + 0.6, z: c.z };
  if (!w.hit) w.hit = new Set();
  let r = STRIKE_RADIUS;
  if (w.t >= STRIKE_PAUSE) r = Math.max(0.5, STRIKE_RADIUS - (w.t - STRIKE_PAUSE + 1) * STRIKE_SPEED);
  const spin = w.t < STRIKE_PAUSE ? w.t * 0.09 : STRIKE_PAUSE * 0.09;
  w.swords.forEach((sw, i) => {
    if (sw.dead) return;
    const a = spin + (i * Math.PI * 2) / SW_COUNT;
    sw.pos = { x: center.x + Math.cos(a) * r, y: center.y, z: center.z + Math.sin(a) * r };
    place(sw.ent, sw.pos, { x: -Math.cos(a), y: 0, z: -Math.sin(a) });
  });
  if (w.t === STRIKE_PAUSE) sound(w.boss.dimension, 'gabriel.swing.aoh', center);
  if (w.t >= STRIKE_PAUSE && r <= 0.8) {
    let list = [];
    try {
      list = w.boss.dimension.getEntities({ location: center, maxDistance: STRIKE_BLAST, excludeTypes: [SWORD, SENSOR] });
    } catch (e) {}
    for (const e of list) if (isVictim(e)) hurt(w.boss, e, STRIKE_DAMAGE, true);
    try {
      w.boss.dimension.runCommand('particle minecraft:large_explosion ' + center.x + ' ' + center.y + ' ' + center.z);
    } catch (e) {}
    sound(w.boss.dimension, 'gabriel.sword.break', center);
    clearSwarm(w.boss.id);
  }
}

function tickSwarms() {
  for (const [id, w] of swarms) {
    try {
      if (!w.boss.isValid) {
        clearSwarm(id);
        continue;
      }
      if (w.mode === 'orbit') tickOrbit(w);
      else tickStrike(w);
      w.t++;
    } catch (e) {
      clearSwarm(id);
    }
  }
}

function newState() {
  return { gap: 20, attacking: false, wasBusy: false, goSince: -1, tagId: undefined, target: undefined, tgtTick: -99, dir: Math.random() < 0.5 ? 1 : -1, flipAt: 0, radius: 7.5, radiusAt: 0, lastMove: 0, hoverY: HOVER_ABOVE, preferMob: false };
}

function refresh() {
  const out = [];
  for (const d of DIMS) {
    try {
      out.push(...world.getDimension(d).getEntities({ type: TYPE }));
    } catch (e) {}
  }
  bosses = out;
  for (const b of out) applyTier(b);
  const ids = new Set(out.map((b) => b.id));
  for (const [id, s] of states) {
    if (!ids.has(id)) {
      markTarget(s, undefined);
      states.delete(id);
    }
  }
}

function chase(boss, s, stage, target, mult) {
  const from = boss.location;
  const tl = target.location;
  const d = sub(tl, from);
  const flat = Math.hypot(d.x, d.z);
  const speed = flat > 30 ? CATCH_UP : (SPEED[stage] || 0.5) * mult;
  const bob = Math.sin(tick * 0.06) * 0.5;
  const wantY = tl.y + s.hoverY + bob;
  const gy = from.y + Math.max(-VERT_STEP, Math.min(VERT_STEP, wantY - from.y));
  if (flat > ORBIT_FAR) {
    const r = (flat - s.radius) / flat;
    stepTo(boss, { x: from.x + d.x * r, y: gy, z: from.z + d.z * r }, speed, target);
    return;
  }
  if (tick >= s.flipAt) {
    if (Math.random() < 0.5) s.dir = -s.dir;
    s.flipAt = tick + 40 + Math.floor(Math.random() * 60);
  }
  if (tick >= s.radiusAt) {
    const aoh = stage >= 4;
    s.radius = aoh ? 3 + Math.random() * 6 : ORBIT_MIN + Math.random() * (ORBIT_MAX - ORBIT_MIN);
    s.hoverY = aoh ? 2 + Math.random() * 6.5 : HOVER_ABOVE + Math.random() * 1.2;
    s.radiusAt = tick + 50 + Math.floor(Math.random() * 70);
  }
  const angle = Math.atan2(from.z - tl.z, from.x - tl.x);
  const radius = Math.max(flat, 1);
  const nextRadius = radius + Math.max(-0.35, Math.min(0.35, (s.radius - radius) * 0.15));
  const nextAngle = angle + (s.dir * speed * 0.8) / Math.max(radius, 3);
  const goal = { x: tl.x + Math.cos(nextAngle) * nextRadius, y: gy, z: tl.z + Math.sin(nextAngle) * nextRadius };
  if (!clear(boss.dimension, goal)) {
    s.dir = -s.dir;
    s.flipAt = tick + 40;
  }
  stepTo(boss, goal, speed, target);
}

const MOVE_WEIGHTS_JOH = { 1: [2, 4, 4], 2: [5, 1, 0], 3: [4, 4, 1], 4: [1, 3, 5] };
const MOVE_WEIGHTS_AOH = { 1: [5, 3, 0.5], 2: [4, 2, 0], 3: [4, 3, 0.5], 4: [1, 4, 6] };

system.runInterval(() => {
  for (const name of DIMS) {
    try {
      for (const b of world.getDimension(name).getEntities({ type: TYPE })) {
        if (b.getProperty('gabriel:enrage') !== 1 || b.getProperty('gabriel:defeat') === 1) continue;
        const l = b.location;
        b.dimension.runCommand('playsound gabriel.rageloop @a ' + l.x + ' ' + l.y + ' ' + l.z + ' 125');
      }
    } catch (e) {}
  }
}, 23);

function pickMove(boss, s, stage, dist) {
  s.sinceTaunt = (s.sinceTaunt || 0) + 1;
  const limit = prop(boss, 'gabriel:tier', 2) <= 1 ? 2 : 3;
  if (s.sinceTaunt > limit) {
    s.sinceTaunt = 0;
    s.lastMove = 20;
    return 20;
  }
  const aoh = stage >= 4;
  if (aoh && s.lastMove === 1 && Math.random() < 0.55) {
    s.lastMove = 4;
    return 4;
  }
  const band = dist <= 6 ? 0 : dist <= 12 ? 1 : 2;
  const table = aoh ? MOVE_WEIGHTS_AOH : MOVE_WEIGHTS_JOH;
  const axeUsed = !aoh && prop(boss, 'gabriel:throw', 0) === 1;
  let options = Object.keys(table).map((m) => [Number(m), table[m][band]]).filter(([m, w]) => w > 0 && !(m === 4 && axeUsed));
  const fresh = options.filter(([m]) => m !== s.lastMove);
  if (fresh.length) options = fresh;
  if (!options.length) return 0;
  let roll = Math.random() * options.reduce((a, o) => a + o[1], 0);
  let chosen = options[options.length - 1][0];
  for (const [m, w] of options) {
    roll -= w;
    if (roll <= 0) {
      chosen = m;
      break;
    }
  }
  s.lastMove = chosen;
  if (!aoh && chosen === 4) setProp(boss, 'gabriel:throw', 1);
  return chosen;
}

function tickBoss(boss, s) {
  const stage = prop(boss, 'gabriel:stage', 0);
  const busy = prop(boss, 'gabriel:busy', 0) === 1;
  const go = prop(boss, 'gabriel:go', 0) === 1;
  const t = gabrielTier();

  if (s.wasBusy && !busy) {
    s.gap = s.attacking ? Math.round((GAP[stage] * (1 + Math.random() * 2)) / t.pace) : 30;
    s.attacking = false;
  }
  s.wasBusy = busy;

  const form = prop(boss, 'gabriel:form', 0);
  if (s.form !== form) {
    if (s.form !== undefined) openHealWindow(boss.id, 100);
    s.form = form;
  }

  if (!ACTIVE_STAGES.includes(stage)) return;

  if (busy) {
    const tg = s.attacking || go ? taggedTarget(boss) : undefined;
    if (tg) {
      face(boss, tg);
      const dist = len(sub(tg.location, boss.location));
      if (s.attacking && dist > LEASH) stepTo(boss, tg.location, CATCH_UP, tg);
      else if (s.close > 0) closeIn(boss, tg);
    }
    if (s.close > 0) s.close--;
    return;
  }

  if (go) {
    if (s.goSince < 0) s.goSince = tick;
    if (tick - s.goSince > 30) {
      setProp(boss, 'gabriel:go', 0);
      s.goSince = -1;
      s.attacking = false;
      s.gap = 20;
    }
    return;
  }
  s.goSince = -1;

  if (!s.target || !alive(s.target) || tick - s.tgtTick >= 10) {
    s.target = findTarget(boss, s.preferMob);
    s.tgtTick = tick;
    markTarget(s, s.target);
  }
  const target = s.target;
  if (!target) return;

  chase(boss, s, stage, target, t.pace);

  if (s.gap > 0) {
    s.gap--;
    return;
  }
  const move = prop(boss, 'gabriel:move', 0);
  if (move >= 90) return;
  const dist = len(sub(target.location, boss.location));
  if (dist > ENGAGE_RANGE) return;
  s.attacking = true;
  s.preferMob = Math.random() < 0.45 && !!findMob(boss);
  try {
    if (s.preferMob) boss.addTag('g_prefmob');
    else boss.removeTag('g_prefmob');
  } catch (e) {}
  s.tgtTick = -99;
  if (prop(boss, 'gabriel:next', 0) === 0) {
    const m = pickMove(boss, s, stage, dist);
    if (m > 0) setProp(boss, 'gabriel:next', m);
  }
  setProp(boss, 'gabriel:go', 1);
}

system.runInterval(() => {
  tick++;
  if (tick % 20 === 1) refresh();
  tickSwarms();
  for (const boss of bosses) {
    try {
      if (!boss.isValid) continue;
      let s = states.get(boss.id);
      if (!s) {
        s = newState();
        states.set(boss.id, s);
      }
      tickBoss(boss, s);
    } catch (e) {}
  }
}, 1);
