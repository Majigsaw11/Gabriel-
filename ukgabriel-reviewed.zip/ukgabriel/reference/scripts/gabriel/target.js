import { world } from '@minecraft/server';
import { TYPE } from './difficulty.js';

export const TARGET_TAG = 'gabriel_target';

function eligible(e) {
  try {
    if (!e || !e.isValid) return false;
    if (e.typeId === TYPE || e.typeId.startsWith('gabriel:')) return false;
    if (e.hasTag(TARGET_TAG)) return false;
    if (e.typeId === 'minecraft:player') {
      const g = String(e.getGameMode()).toLowerCase();
      return g !== 'creative' && g !== 'spectator';
    }
    return !e.matches({ families: ['gabriel', 'gabriel_projectile', 'inanimate'] });
  } catch (err) {
    return false;
  }
}

world.afterEvents.entityHurt.subscribe((ev) => {
  const e = ev.hurtEntity;
  if (!e || !e.isValid || e.typeId !== TYPE) return;
  const src = ev.damageSource && ev.damageSource.damagingEntity;
  if (!eligible(src)) return;
  try {
    src.addTag(TARGET_TAG);
  } catch (err) {}
});
