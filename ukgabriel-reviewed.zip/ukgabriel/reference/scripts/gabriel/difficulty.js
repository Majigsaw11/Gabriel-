import { world, system } from '@minecraft/server';
import { TIERS, getDifficulty } from '../difficulty.js';
import { adaptFactor } from '../chara_buffs.js';

export const TYPE = 'gabriel:gabriel';

const HP_KEY = 'gabriel:hp_tier';

// Mob Battle reference numbers, copied from Minos Prime (main.js) and Sisyphus Prime (sisyphus.js).
const MINOS_MB = { mobPct: 0.07, mobCap: 400, pace: 1.75 };
const SISYPHUS_MB = { mobPct: 0.07, mobCap: 400, pace: 1.75 };
// Gabriel's Mob Battle stats = (Minos + Sisyphus) x 1.5. Change this one number to retune.
const MB_BONUS = 1.5;
const MB_HP = 15000;
const MB_PROJ_CLAMP = 2.0;

const MB = {
  mobPct: (MINOS_MB.mobPct + SISYPHUS_MB.mobPct) * MB_BONUS,
  mobCap: (MINOS_MB.mobCap + SISYPHUS_MB.mobCap) * MB_BONUS,
  pace: Math.max(MINOS_MB.pace, SISYPHUS_MB.pace) * MB_BONUS,
};

// pace: AI/cooldown/dash speed. proj: projectile speed. dmg: multiplier on the wiki damage numbers vs players (1 = accurate).
// mobPct/mobCap: damage vs non-player mobs as a % of their max health (Minos's system: 7%, cap 400).
// armorCap: max % of Gabriel's max health one hit can take. antiHeal: his hits strip healing.
// varied: damage source (cause) changes per hit, like Minos in Mob Battle.
const MOB_BASE = { mobPct: MINOS_MB.mobPct, mobCap: MINOS_MB.mobCap };
const CONFIG = {
  Harmless: { pace: 0.8, proj: 0.8, dmg: 1, ...MOB_BASE, armorCap: 0.05, antiHeal: false, varied: false },
  Lenient: { pace: 0.9, proj: 0.9, dmg: 1, ...MOB_BASE, armorCap: 0.04, antiHeal: false, varied: false },
  Standard: { pace: 1.0, proj: 1.0, dmg: 1, ...MOB_BASE, armorCap: 0.03, antiHeal: false, varied: false },
  Violent: { pace: 1.25, proj: 1.25, dmg: 1, ...MOB_BASE, armorCap: 0.025, antiHeal: false, varied: false },
  Brutal: { pace: 1.5, proj: 1.5, dmg: 1, ...MOB_BASE, armorCap: 0.02, antiHeal: false, varied: false },
  'Mob Battle': {
    pace: MB.pace,
    proj: Math.min(MB.pace, MB_PROJ_CLAMP),
    dmg: 1,
    mobPct: MB.mobPct,
    mobCap: MB.mobCap,
    armorCap: 0.015,
    antiHeal: true,
    varied: true,
    hp: MB_HP,
  },
};

export function tierIndex() {
  const i = TIERS.indexOf(getDifficulty());
  return i < 0 ? 2 : i;
}

export function gabrielTier() {
  const d = getDifficulty();
  const cfg = CONFIG[d.name] || CONFIG.Standard;
  return { index: Math.max(0, TIERS.indexOf(d)), name: d.name, ...cfg, pace: cfg.pace * adaptFactor(TYPE) };
}

export function applyTier(boss) {
  const t = gabrielTier();
  try {
    if (boss.getProperty('gabriel:tier') !== t.index) boss.setProperty('gabriel:tier', t.index);
  } catch (e) {}
  if (!t.hp) return;
  try {
    if (boss.getDynamicProperty(HP_KEY) === t.name) return;
    boss.triggerEvent('gabriel:hp_mob_battle');
    boss.setDynamicProperty(HP_KEY, t.name);
  } catch (e) {}
}

world.afterEvents.entitySpawn.subscribe((ev) => {
  const e = ev.entity;
  if (!e || e.typeId !== TYPE) return;
  system.run(() => {
    try {
      if (e.isValid) applyTier(e);
    } catch (err) {}
  });
});
