import { world, system } from '@minecraft/server';
import { NO_HEAL_TAG } from '../anti_heal.js';
import { TYPE, gabrielTier } from './difficulty.js';

const NO_HEAL_TICKS = 100;
const STAMP = 'uk:no_heal_stamp';
const windows = new Map();

export function openHealWindow(id, ticks) {
  windows.set(id, system.currentTick + ticks);
}

export function applyAntiHeal(target) {
  for (const id of ['regeneration', 'health_boost', 'absorption']) {
    try {
      target.removeEffect(id);
    } catch (e) {}
  }
  try {
    target.addTag(NO_HEAL_TAG);
    const stamp = system.currentTick;
    target.setDynamicProperty(STAMP, stamp);
    system.runTimeout(() => {
      try {
        if (target.isValid && target.getDynamicProperty(STAMP) === stamp) target.removeTag(NO_HEAL_TAG);
      } catch (e) {}
    }, NO_HEAL_TICKS);
  } catch (e) {}
}

world.afterEvents.entityHurt.subscribe((ev) => {
  const src = ev.damageSource && ev.damageSource.damagingEntity;
  if (!src || src.typeId !== TYPE) return;
  const victim = ev.hurtEntity;
  if (!victim || !victim.isValid || victim.typeId === TYPE) return;
  if (!gabrielTier().antiHeal) return;
  applyAntiHeal(victim);
});

world.afterEvents.entityHealthChanged.subscribe((ev) => {
  const e = ev.entity;
  if (!e || !e.isValid || e.typeId !== TYPE) return;
  if (!gabrielTier().antiHeal) return;
  const gained = ev.newValue - ev.oldValue;
  if (gained <= 0) return;
  let stage = 1;
  try {
    stage = e.getProperty('gabriel:stage');
  } catch (err) {}
  if (stage === 0 || stage === 3) return;
  if ((windows.get(e.id) || 0) > system.currentTick) return;
  system.run(() => {
    try {
      if (!e.isValid) return;
      const h = e.getComponent('minecraft:health');
      if (h) h.setCurrentValue(Math.max(h.currentValue - gained, 1));
    } catch (err) {}
  });
});
