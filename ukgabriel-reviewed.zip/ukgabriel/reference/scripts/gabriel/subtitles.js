import { world, system } from '@minecraft/server';

const JOH_TAUNTS = [
  ['You defy the light!', 2.29],
  ['A mere object!', 2.78],
  ['There can be only light!', 3.21],
  ['Foolishness, machine. Foolishness.', 2.97],
  ['An imperfection to be cleansed...', 2.8],
  ['Not. Even. Mortal.', 2.78],
  ['You are less than nothing', 2.6],
  ["You're an error to be corrected!", 2.96],
  ['The light IS perfection!', 2.72],
  ['You are outclassed!', 2.05],
  ['Your crime is existence!', 2.4],
  ['You make even the DEVIL CRY!', 2.51],
];

const APO_TAUNTS = [
  ['IS THIS WHAT I LOST TO!?', 2.47],
  ["YOU'RE GETTING RUSTY, MACHINE!", 2.7],
  ["LET'S SETTLE THIS!", 2.08],
  ['NOTHING BUT SCRAP!', 2.05],
  ["I'LL SHOW YOU DIVINE JUSTICE!", 3.51],
  ['TIME TO RIGHT MY WRONG!', 2.97],
  ['YOU NEED. MORE. POWER!', 3.17],
];

const ECSTATIC_TAUNTS = [
  ["I've never had a fight like this before!", 3.01],
  ['Show me what you were made for!', 3.68],
  ["Now THIS is a fight worthy of God's Will!", 3.56],
  ['What is this FEELING?', 3.8],
  ['Come get some BLOOD!', 3.55],
  ['Come on, machine! Fight me like an ANIMAL!', 3.19],
  ["I'll show you TRUE splendor!", 2.61],
];

const RANGE = 96;
const last = new Map();
let current;

function show(boss, seconds, text) {
  try {
    current = { dim: boss.dimension, loc: { x: boss.location.x, y: boss.location.y, z: boss.location.z }, text, until: system.currentTick + Math.round(seconds * 20) };
    push();
  } catch (e) {}
}

function push() {
  if (!current) return;
  if (system.currentTick >= current.until) {
    current = undefined;
    return;
  }
  try {
    for (const p of current.dim.getPlayers({ location: current.loc, maxDistance: RANGE })) p.onScreenDisplay.setActionBar(current.text);
  } catch (e) {}
}

system.runInterval(push, 5);

function taunt(boss) {
  let stage = 1;
  try {
    stage = boss.getProperty('gabriel:stage');
  } catch (e) {}
  let prefix = 'gabriel.taunt.judge';
  let list = JOH_TAUNTS;
  if (stage === 4) {
    prefix = 'gabriel.taunt.apostate';
    list = APO_TAUNTS;
  } else if (stage === 5) {
    prefix = 'gabriel.taunt.ecstatic';
    list = ECSTATIC_TAUNTS;
  }
  let i = Math.floor(Math.random() * list.length);
  if (list.length > 1 && last.get(prefix) === i) i = (i + 1) % list.length;
  last.set(prefix, i);
  try {
    for (const p of boss.dimension.getPlayers({ location: boss.location, maxDistance: 128 })) {
      try {
        p.playSound(prefix + '.' + i, { volume: 3, pitch: 1 });
      } catch (e) {}
    }
  } catch (e) {}
  show(boss, list[i][1] + 0.4, list[i][0]);
}

system.afterEvents.scriptEventReceive.subscribe((ev) => {
  const boss = ev.sourceEntity;
  if (!boss || boss.typeId !== 'gabriel:gabriel') return;
  if (ev.id === 'gabriel:taunt') {
    taunt(boss);
    return;
  }
  if (ev.id === 'gabriel:sub') {
    const cut = ev.message.indexOf('|');
    if (cut < 1) return;
    const seconds = parseFloat(ev.message.slice(0, cut));
    if (!(seconds > 0)) return;
    show(boss, seconds, ev.message.slice(cut + 1));
  }
});
