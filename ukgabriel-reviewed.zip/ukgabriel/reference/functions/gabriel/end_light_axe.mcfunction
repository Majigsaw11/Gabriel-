tag @s add gdone
event entity @s gabriel:despawn
