particle minecraft:large_explosion ~ ~ ~
particle uk:shockwave_white ~ ~ ~
particle uk:soul_burst ~ ~ ~
particle uk:orange_glow ~ ~ ~
particle uk:shockwave_orange ~ ~ ~
particle uk:flash_yellow ~ ~ ~
particle uk:gold_shards ~ ~ ~
playsound random.explode @a ~ ~ ~ 2
playsound gabriel.sword.break @a ~ ~ ~ 125
execute positioned ~ ~-0.9 ~ run damage @a[m=!creative,m=!spectator,r=1.7] 35 entity_explosion entity @n[type=gabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!player,tag=gabriel_target,family=!gabriel,family=!inanimate,family=!gabriel_projectile,r=1.7] 35 entity_explosion entity @n[type=gabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!player,tag=!gabriel_target,family=sam,family=!gabriel,r=1.7] 35 entity_explosion entity @n[type=gabriel:gabriel]
execute positioned ~ ~-0.9 ~ run tag @a[m=!creative,m=!spectator,r=1.7] add g_hit
execute positioned ~ ~-0.9 ~ run tag @e[type=!player,tag=gabriel_target,family=!gabriel,family=!inanimate,family=!gabriel_projectile,r=1.7] add g_hit
execute positioned ~ ~-0.9 ~ run tag @e[type=!player,tag=!gabriel_target,family=sam,family=!gabriel,r=1.7] add g_hit
function gabriel/end_sword_beam
