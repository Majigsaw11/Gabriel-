particle minecraft:large_explosion ~ ~ ~
particle uk:shockwave_white ~ ~ ~
particle uk:soul_burst ~ ~ ~
particle uk:orange_glow ~ ~ ~
playsound gabriel.sword.break @a ~ ~ ~ 125
execute positioned ~ ~-0.9 ~ run damage @a[m=!creative,m=!spectator,r=3] 35 entity_explosion entity @n[type=gabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!player,family=!gabriel,family=!inanimate,family=!gabriel_projectile,r=3] 35 entity_explosion entity @n[type=gabriel:gabriel]
function gabriel/end_sword_throw
