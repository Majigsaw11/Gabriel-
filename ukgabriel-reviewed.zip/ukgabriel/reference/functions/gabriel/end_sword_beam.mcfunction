tag @s add gdone
particle minecraft:huge_explosion_emitter ~ ~ ~
playsound random.explode @a ~ ~ ~ 2 1
execute positioned ~ ~-0.9 ~ run damage @a[m=!creative,m=!spectator,r=4.1,tag=!g_hit] 35 entity_explosion entity @n[type=gabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!player,tag=gabriel_target,family=!gabriel,family=!inanimate,family=!gabriel_projectile,r=4.1,tag=!g_hit] 35 entity_explosion entity @n[type=gabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!player,tag=!gabriel_target,family=sam,family=!gabriel,r=4.1,tag=!g_hit] 35 entity_explosion entity @n[type=gabriel:gabriel]
event entity @s gabriel:despawn
tag @e[tag=g_hit] remove g_hit