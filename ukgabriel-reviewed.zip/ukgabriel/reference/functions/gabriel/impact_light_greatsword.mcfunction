particle minecraft:large_explosion ~ ~ ~
playsound gabriel.sword.break @a ~ ~ ~ 125
execute positioned ~ ~-0.9 ~ run damage @a[m=!creative,m=!spectator,r=1.7] 35 entity_explosion entity @n[type=gabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!player,tag=gabriel_target,family=!gabriel,family=!inanimate,family=!gabriel_projectile,r=1.7] 35 entity_explosion entity @n[type=gabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!player,tag=!gabriel_target,family=sam,family=!gabriel,r=1.7] 35 entity_explosion entity @n[type=gabriel:gabriel]
function gabriel/end_light_greatsword
