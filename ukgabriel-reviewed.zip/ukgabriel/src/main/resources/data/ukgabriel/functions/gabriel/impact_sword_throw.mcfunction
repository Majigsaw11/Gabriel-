particle minecraft:explosion ~ ~ ~
ukgabriel particle uk:shockwave_white ~ ~ ~
ukgabriel particle uk:soul_burst ~ ~ ~
ukgabriel particle uk:orange_glow ~ ~ ~
playsound ukgabriel:gabriel.sword.break hostile @a ~ ~ ~ 125
execute positioned ~ ~-0.9 ~ run damage @a[gamemode=!creative,gamemode=!spectator,distance=..3] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!minecraft:player,type=!#ukgabriel:family/gabriel,type=!#ukgabriel:family/inanimate,type=!#ukgabriel:family/gabriel_projectile,distance=..3] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
function ukgabriel:gabriel/end_sword_throw
