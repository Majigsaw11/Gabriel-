particle minecraft:explosion ~ ~ ~
ukgabriel particle uk:shockwave_white ~ ~ ~
ukgabriel particle uk:soul_burst ~ ~ ~
ukgabriel particle uk:orange_glow ~ ~ ~
ukgabriel particle uk:shockwave_orange ~ ~ ~
ukgabriel particle uk:flash_yellow ~ ~ ~
ukgabriel particle uk:gold_shards ~ ~ ~
playsound minecraft:entity.generic.explode hostile @a ~ ~ ~ 2
playsound ukgabriel:gabriel.sword.break hostile @a ~ ~ ~ 125
execute positioned ~ ~-0.9 ~ run damage @a[gamemode=!creative,gamemode=!spectator,distance=..1.7] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!minecraft:player,tag=gabriel_target,type=!#ukgabriel:family/gabriel,type=!#ukgabriel:family/inanimate,type=!#ukgabriel:family/gabriel_projectile,distance=..1.7] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!minecraft:player,tag=!gabriel_target,type=#ukgabriel:family/sam,type=!#ukgabriel:family/gabriel,distance=..1.7] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
execute positioned ~ ~-0.9 ~ run tag @a[gamemode=!creative,gamemode=!spectator,distance=..1.7] add g_hit
execute positioned ~ ~-0.9 ~ run tag @e[type=!minecraft:player,tag=gabriel_target,type=!#ukgabriel:family/gabriel,type=!#ukgabriel:family/inanimate,type=!#ukgabriel:family/gabriel_projectile,distance=..1.7] add g_hit
execute positioned ~ ~-0.9 ~ run tag @e[type=!minecraft:player,tag=!gabriel_target,type=#ukgabriel:family/sam,type=!#ukgabriel:family/gabriel,distance=..1.7] add g_hit
function ukgabriel:gabriel/end_sword_beam
