particle minecraft:explosion ~ ~ ~
playsound ukgabriel:gabriel.sword.break hostile @a ~ ~ ~ 125
execute positioned ~ ~-0.9 ~ run damage @a[gamemode=!creative,gamemode=!spectator,distance=..1.7] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!minecraft:player,tag=gabriel_target,type=!#ukgabriel:family/gabriel,type=!#ukgabriel:family/inanimate,type=!#ukgabriel:family/gabriel_projectile,distance=..1.7] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!minecraft:player,tag=!gabriel_target,type=#ukgabriel:family/sam,type=!#ukgabriel:family/gabriel,distance=..1.7] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
function ukgabriel:gabriel/end_light_greatsword
