tag @s add gdone
ukgabriel event @s gabriel:despawn
