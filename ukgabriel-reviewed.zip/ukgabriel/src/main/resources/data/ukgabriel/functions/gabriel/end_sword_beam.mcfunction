tag @s add gdone
particle minecraft:explosion_emitter ~ ~ ~
playsound minecraft:entity.generic.explode hostile @a ~ ~ ~ 2 1
execute positioned ~ ~-0.9 ~ run damage @a[gamemode=!creative,gamemode=!spectator,tag=!g_hit,distance=..4.1] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!minecraft:player,tag=gabriel_target,type=!#ukgabriel:family/gabriel,type=!#ukgabriel:family/inanimate,type=!#ukgabriel:family/gabriel_projectile,tag=!g_hit,distance=..4.1] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
execute positioned ~ ~-0.9 ~ run damage @e[type=!minecraft:player,tag=!gabriel_target,type=#ukgabriel:family/sam,type=!#ukgabriel:family/gabriel,tag=!g_hit,distance=..4.1] 35 minecraft:explosion by @e[sort=nearest,limit=1,type=ukgabriel:gabriel]
ukgabriel event @s gabriel:despawn
tag @e[tag=g_hit] remove g_hit
