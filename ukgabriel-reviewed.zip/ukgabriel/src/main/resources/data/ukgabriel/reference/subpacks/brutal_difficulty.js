export const DIFF = {
  name: "Brutal",
  maxHealth: 195,
  hpEvent: "uk:hp_brutal",
  staminaP1: 15,
  staminaP2: Infinity,
  recoverySec: 2,
  pace: 1.5,
  serpentWeight: 1.8,
  harmlessNerf: false,
  bypassResistance: true,
  antiHeal: false,
};
