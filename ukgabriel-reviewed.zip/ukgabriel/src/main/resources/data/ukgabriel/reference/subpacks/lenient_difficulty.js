export const DIFF = {
  name: "Lenient",
  maxHealth: 130,
  hpEvent: "uk:hp_lenient",
  staminaP1: 6,
  staminaP2: 6,
  recoverySec: 3,
  pace: 0.9,
  serpentWeight: 0.6,
  harmlessNerf: false,
  bypassResistance: false,
  antiHeal: false,
};
