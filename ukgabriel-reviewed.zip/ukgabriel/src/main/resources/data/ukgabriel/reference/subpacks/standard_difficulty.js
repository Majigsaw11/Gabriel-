export const DIFF = {
  name: "Standard",
  maxHealth: 130,
  hpEvent: "uk:hp_standard",
  staminaP1: 6,
  staminaP2: 12,
  recoverySec: 2,
  pace: 1.0,
  serpentWeight: 1.0,
  harmlessNerf: false,
  bypassResistance: false,
  antiHeal: false,
};
