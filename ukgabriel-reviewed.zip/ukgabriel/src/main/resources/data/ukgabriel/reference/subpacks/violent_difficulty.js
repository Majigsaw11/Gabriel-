export const DIFF = {
  name: "Violent",
  maxHealth: 130,
  hpEvent: "uk:hp_violent",
  staminaP1: 10,
  staminaP2: Infinity,
  recoverySec: 2,
  pace: 1.25,
  serpentWeight: 1.0,
  harmlessNerf: false,
  bypassResistance: true,
  antiHeal: false,
};
