export const DIFF = {
  name: "Harmless",
  maxHealth: 130,
  hpEvent: "uk:hp_harmless",
  staminaP1: 6,
  staminaP2: 6,
  recoverySec: 4,
  pace: 0.8,
  serpentWeight: 0.35,
  harmlessNerf: true,
  bypassResistance: false,
  antiHeal: false,
};
