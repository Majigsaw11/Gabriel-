export const DIFF = {
  name: "Mob Battle",
  maxHealth: 13000,
  hpEvent: "uk:hp_mob_battle",
  staminaP1: 15,
  staminaP2: Infinity,
  recoverySec: 2,
  pace: 1.75,
  serpentWeight: 1.8,
  harmlessNerf: false,
  bypassResistance: true,
  antiHeal: true,
};
