package com.ukgabriel.bedrock.particle;

import com.ukgabriel.bedrock.molang.Molang;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

/** One live particle. Position is world-space; ages in seconds. */
public final class BedrockParticle implements Molang.Scope {
    public final ParticleDef def;
    private final BedrockEmitter emitter;
    private final Random rng;
    public double x, y, z, vx, vy, vz;
    public double age, lifetime = 1;
    public double rotation, rotationRate;
    public final double[] r = new double[4];
    private final Map<String, Double> vars = new HashMap<>(2);

    BedrockParticle(ParticleDef def, BedrockEmitter emitter, Random rng) {
        this.def = def;
        this.emitter = emitter;
        this.rng = rng;
        for (int i = 0; i < 4; i++) r[i] = rng.nextDouble();
    }

    private double ageOverride = Double.NaN;

    @Override
    public double get(String n) {
        switch (n) {
            case "v.particle_age": return Double.isNaN(ageOverride) ? age : ageOverride;
            case "v.particle_lifetime": return lifetime;
            case "v.particle_random_1": return r[0];
            case "v.particle_random_2": return r[1];
            case "v.particle_random_3": return r[2];
            case "v.particle_random_4": return r[3];
            default: break;
        }
        Double v = vars.get(n);
        return v != null ? v : emitter.get(n);
    }

    @Override public void set(String n, double value) { vars.put(n, value); }
    @Override public double random() { return rng.nextDouble(); }

    void update(double dt) {
        age += dt;
        ParticleDef d = def;
        if (d.hasMotion) {
            double ax = d.linearAccel[0].eval(this), ay = d.linearAccel[1].eval(this), az = d.linearAccel[2].eval(this);
            double drag = d.linearDrag.eval(this);
            vx += (ax - drag * vx) * dt;
            vy += (ay - drag * vy) * dt;
            vz += (az - drag * vz) * dt;
            double ra = d.rotAccel.eval(this) - d.rotDrag.eval(this) * rotationRate;
            rotationRate += ra * dt;
            x += vx * dt; y += vy * dt; z += vz * dt;
        }
        rotation += rotationRate * dt;
    }

    public boolean expired() { return age >= lifetime; }

    /** Render-time snapshot, evaluated at age + partialSeconds. */
    public static final class Sample {
        public double x, y, z, dirX, dirY, dirZ;
        public float w, h, rotation, red, green, blue, alpha;
        public float u0, v0, u1, v1;
    }

    public void sample(double partialSeconds, Sample o) {
        ageOverride = Math.min(age + partialSeconds, lifetime);
        ParticleDef d = def;
        o.x = x + vx * partialSeconds; o.y = y + vy * partialSeconds; o.z = z + vz * partialSeconds;
        o.dirX = vx; o.dirY = vy; o.dirZ = vz;
        o.w = (float) d.sizeW.eval(this);
        o.h = (float) d.sizeH.eval(this);
        o.rotation = (float) (rotation + rotationRate * partialSeconds);
        if (d.color != null) {
            o.red = (float) d.color[0].eval(this); o.green = (float) d.color[1].eval(this);
            o.blue = (float) d.color[2].eval(this); o.alpha = (float) d.color[3].eval(this);
        } else {
            float t = (float) d.gradientInterpolant.eval(this);
            float[] s = d.gradientStops;
            int n = s.length;
            float[] c;
            if (t <= s[0]) c = d.gradientColors[0];
            else if (t >= s[n - 1]) c = d.gradientColors[n - 1];
            else {
                int i = 0;
                while (i < n - 2 && t > s[i + 1]) i++;
                float k = (t - s[i]) / (s[i + 1] - s[i]);
                float[] a = d.gradientColors[i], b = d.gradientColors[i + 1];
                c = new float[]{a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k, a[2] + (b[2] - a[2]) * k, a[3] + (b[3] - a[3]) * k};
            }
            o.red = c[0]; o.green = c[1]; o.blue = c[2]; o.alpha = c[3];
        }
        o.u0 = (float) (d.u / d.texW); o.v0 = (float) (d.v / d.texH);
        o.u1 = (float) ((d.u + d.uSize) / d.texW); o.v1 = (float) ((d.v + d.vSize) / d.texH);
        ageOverride = Double.NaN;
    }
}
