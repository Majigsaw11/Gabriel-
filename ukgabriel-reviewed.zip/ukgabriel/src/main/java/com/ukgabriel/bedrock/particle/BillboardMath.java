package com.ukgabriel.bedrock.particle;

/**
 * Corner offsets for Bedrock billboards (facing_camera_mode). Pure maths so it is unit-testable.
 * Bedrock's size is the HALF extent of the quad (size 0.5 = a 1x1 block quad).
 * Output order (12 doubles): bottom-left, top-left, top-right, bottom-right, relative to the particle centre,
 * matching UVs (u0,v1), (u0,v0), (u1,v0), (u1,v1).
 */
public final class BillboardMath {
    private BillboardMath() {}

    public static void corners(ParticleDef.Facing facing, double halfW, double halfH, double spinRad,
                               double[] toCam, double[] camRight, double[] camUp,
                               double[] dir, double minSpeed, double[] out) {
        double[] right, up;
        switch (facing) {
            case ROTATE_XYZ -> { right = camRight.clone(); up = camUp.clone(); }
            case ROTATE_Y -> {
                right = norm(new double[]{camRight[0], 0, camRight[2]}, new double[]{1, 0, 0});
                up = new double[]{0, 1, 0};
            }
            case LOOKAT_XYZ -> {
                double[] f = norm(toCam, new double[]{0, 0, 1});
                right = norm(cross(new double[]{0, 1, 0}, f), camRight);
                up = cross(f, right);
            }
            case LOOKAT_Y -> {
                double[] f = norm(new double[]{toCam[0], 0, toCam[2]}, new double[]{0, 0, 1});
                right = norm(cross(new double[]{0, 1, 0}, f), camRight);
                up = new double[]{0, 1, 0};
            }
            case DIRECTION_Y, DIRECTION_X, DIRECTION_Z -> {
                double speed = Math.sqrt(dir[0] * dir[0] + dir[1] * dir[1] + dir[2] * dir[2]);
                double[] axis = speed >= minSpeed && speed > 1e-9 ? new double[]{dir[0] / speed, dir[1] / speed, dir[2] / speed} : new double[]{0, 1, 0};
                double[] tc = norm(toCam, new double[]{0, 0, 1});
                if (facing == ParticleDef.Facing.DIRECTION_Y) {          // quad's Y axis follows the direction, turned to face the camera
                    right = norm(cross(axis, tc), camRight);
                    up = axis;
                } else if (facing == ParticleDef.Facing.DIRECTION_X) {   // quad's X axis follows the direction
                    right = axis;
                    up = norm(cross(tc, axis), camUp);
                } else {                                                 // DIRECTION_Z: quad normal follows the direction
                    right = norm(cross(new double[]{0, 1, 0}, axis), camRight);
                    up = cross(axis, right);
                }
            }
            default -> throw new IllegalStateException();
        }
        if (spinRad != 0) {
            double c = Math.cos(spinRad), s = Math.sin(spinRad);
            double[] r2 = new double[3], u2 = new double[3];
            for (int i = 0; i < 3; i++) { r2[i] = right[i] * c + up[i] * s; u2[i] = -right[i] * s + up[i] * c; }
            right = r2; up = u2;
        }
        double[][] sign = {{-1, -1}, {-1, 1}, {1, 1}, {1, -1}};
        for (int k = 0; k < 4; k++)
            for (int i = 0; i < 3; i++) out[k * 3 + i] = right[i] * halfW * sign[k][0] + up[i] * halfH * sign[k][1];
    }

    static double[] cross(double[] a, double[] b) {
        return new double[]{a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]};
    }

    static double[] norm(double[] v, double[] fallback) {
        double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        if (l < 1e-9) return fallback.clone();
        return new double[]{v[0] / l, v[1] / l, v[2] / l};
    }
}
