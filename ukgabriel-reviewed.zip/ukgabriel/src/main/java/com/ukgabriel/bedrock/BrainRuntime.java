package com.ukgabriel.bedrock;

import com.ukgabriel.bedrock.molang.Molang;

import java.util.*;

/**
 * Runs Gabriel's BP "brain" + "phase" animation controllers: state machine transitions, on_entry commands and
 * the per-state timeline animations (timed commands). Pure Java; the Forge entity implements Host.
 */
public final class BrainRuntime {
    public interface Host extends BedrockEvents.Target {
        double health();
        double maxHealth();
        default int markVariant() { return 0; }
    }

    private final Host host;
    private final Map<String, Timeline> timelines;
    private final Map<String, String> aliases;
    private final List<Ctx> ctxs = new ArrayList<>();

    private final class Ctx implements Molang.Scope {
        final BedrockController ctl;
        final List<Timeline.Player> players = new ArrayList<>();
        BedrockController.State last;
        Ctx(BedrockController c) { ctl = c; }

        @Override public double get(String n) {
            return switch (n) {
                case "q.health" -> host.health();
                case "q.max_health" -> host.maxHealth();
                case "q.mark_variant" -> host.markVariant();
                case "q.all_animations_finished" -> { for (Timeline.Player p : players) if (!p.finished()) yield 0; yield 1; }
                default -> throw new IllegalStateException("brain controller uses unsupported symbol " + n);
            };
        }
        @Override public double query(String n, String arg) {
            if (n.equals("property")) return host.prop(arg);
            throw new IllegalStateException("brain controller uses unsupported query " + n);
        }
    }

    public BrainRuntime(Host host, Map<String, BedrockController> controllers, Map<String, Timeline> timelines,
                        Map<String, String> aliases, List<String> animate) {
        this.host = host; this.timelines = timelines; this.aliases = aliases;
        for (String a : animate) {
            BedrockController c = controllers.get(aliases.get(a));
            if (c == null) throw new IllegalArgumentException("no controller for " + a);
            ctxs.add(new Ctx(c));
        }
    }

    public BedrockController controller(String alias) {
        for (Ctx c : ctxs) if (c.ctl.id.equals(aliases.get(alias))) return c.ctl;
        throw new IllegalArgumentException(alias);
    }

    public String stateOf(String alias) { return controller(alias).current().name; }

    /** One tick (dt seconds). */
    public void tick(double dt) {
        for (Ctx c : ctxs) {
            List<String> entry = c.ctl.update(c, dt);
            if (c.ctl.current() != c.last) {
                c.last = c.ctl.current();
                c.players.clear();
                for (String alias : c.last.animations) {
                    Timeline tl = timelines.get(aliases.get(alias));
                    if (tl == null) throw new IllegalStateException("no timeline for animation " + alias);
                    c.players.add(new Timeline.Player(tl));
                }
                for (String cmd : entry) host.command(cmd);
            }
            for (Timeline.Player p : c.players) for (String cmd : p.advance(dt)) host.command(cmd);
        }
    }
}
