package com.ukgabriel.bedrock.particle;

import com.ukgabriel.bedrock.molang.Molang;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** One running instance of a Bedrock particle effect. Tick at 20 Hz (dt = 0.05) or any dt. */
public final class BedrockEmitter implements Molang.Scope {
    public final ParticleDef def;
    public double x, y, z;
    public final List<BedrockParticle> particles = new ArrayList<>();
    private final Random rng;
    private final double[] er = new double[4];
    private final Map<String, Double> vars = new HashMap<>(2);
    private double age, activeTime, spawnAccum;
    private boolean started;

    public BedrockEmitter(ParticleDef def, double x, double y, double z, long seed) {
        this.def = def;
        this.x = x; this.y = y; this.z = z;
        this.rng = new Random(seed);
        for (int i = 0; i < 4; i++) er[i] = rng.nextDouble();
        this.activeTime = def.emitterActiveTime != null ? def.emitterActiveTime.eval(this) : Double.MAX_VALUE;
    }

    @Override
    public double get(String n) {
        switch (n) {
            case "v.emitter_age": return age;
            case "v.emitter_lifetime": return activeTime == Double.MAX_VALUE ? 0 : activeTime;
            case "v.emitter_random_1": return er[0];
            case "v.emitter_random_2": return er[1];
            case "v.emitter_random_3": return er[2];
            case "v.emitter_random_4": return er[3];
            default: Double v = vars.get(n); return v != null ? v : 0;
        }
    }
    @Override public void set(String n, double v) { vars.put(n, v); }
    @Override public double random() { return rng.nextDouble(); }

    public boolean emitting() { return age < activeTime; }
    public boolean done() { return !emitting() && particles.isEmpty(); }

    public void tick(double dt) {
        ParticleDef d = def;
        if (emitting()) {
            if (!started) {
                started = true;
                if (d.instantCount != null) {
                    int n = (int) d.instantCount.eval(this);
                    for (int i = 0; i < n; i++) spawn();
                }
            }
            if (d.steadyRate != null) {
                spawnAccum += d.steadyRate.eval(this) * dt;
                int max = (int) d.steadyMax.eval(this);
                while (spawnAccum >= 1) {
                    spawnAccum -= 1;
                    if (particles.size() < max) spawn();
                }
            }
        }
        age += dt;
        for (int i = particles.size() - 1; i >= 0; i--) {
            BedrockParticle p = particles.get(i);
            p.update(dt);
            if (p.expired()) particles.remove(i);
        }
    }

    private void spawn() {
        ParticleDef d = def;
        BedrockParticle p = new BedrockParticle(d, this, rng);
        p.lifetime = d.maxLifetime.eval(p);
        double ox = d.shapeOffset[0].eval(p), oy = d.shapeOffset[1].eval(p), oz = d.shapeOffset[2].eval(p);
        double px = ox, py = oy, pz = oz, dx, dy, dz;
        if (d.shape == ParticleDef.ShapeKind.SPHERE) {
            double rad = d.shapeRadius.eval(p);
            double ux, uy, uz, len;
            do { ux = rng.nextDouble() * 2 - 1; uy = rng.nextDouble() * 2 - 1; uz = rng.nextDouble() * 2 - 1; len = Math.sqrt(ux * ux + uy * uy + uz * uz); } while (len > 1 || len < 1e-6);
            double dist = d.shapeSurfaceOnly ? rad : rad * Math.cbrt(rng.nextDouble());
            ux /= len; uy /= len; uz /= len;
            px += ux * dist; py += uy * dist; pz += uz * dist;
            switch (d.dirMode) {
                case OUTWARDS -> { dx = ux; dy = uy; dz = uz; }
                case INWARDS -> { dx = -ux; dy = -uy; dz = -uz; }
                default -> { dx = d.dirCustom[0].eval(p); dy = d.dirCustom[1].eval(p); dz = d.dirCustom[2].eval(p); }
            }
        } else {
            dx = d.dirCustom[0].eval(p); dy = d.dirCustom[1].eval(p); dz = d.dirCustom[2].eval(p);
        }
        p.x = x + px; p.y = y + py; p.z = z + pz;
        if (d.initialVelocity != null) {
            p.vx = d.initialVelocity[0].eval(p); p.vy = d.initialVelocity[1].eval(p); p.vz = d.initialVelocity[2].eval(p);
        } else {
            double sp = d.initialSpeed.eval(p);
            double l = Math.sqrt(dx * dx + dy * dy + dz * dz);
            if (l > 1e-9) { p.vx = dx / l * sp; p.vy = dy / l * sp; p.vz = dz / l * sp; }
        }
        p.rotation = d.initialRotation.eval(p);
        p.rotationRate = d.initialRotationRate.eval(p);
        particles.add(p);
    }
}
