package com.ukgabriel.bedrock;

import java.util.*;

/** A BP animation's timed command list (translated Java 1.20.1 commands) plus its length. */
public final class Timeline {
    public final String name;
    public final double length;
    public final boolean loop;
    final double[] times;
    final List<String>[] commands;

    @SuppressWarnings("unchecked")
    private Timeline(String name, Double len, Object loop, Map<String, Object> tl) {
        this.name = name;
        this.loop = Boolean.TRUE.equals(loop);
        TreeMap<Double, List<String>> sorted = new TreeMap<>();
        for (Map.Entry<String, Object> e : tl.entrySet()) {
            List<String> l = new ArrayList<>();
            for (Object c : (List<Object>) e.getValue()) l.add((String) c);
            sorted.put(Double.parseDouble(e.getKey()), l);
        }
        this.times = sorted.keySet().stream().mapToDouble(Double::doubleValue).toArray();
        this.commands = sorted.values().toArray(new List[0]);
        this.length = len != null ? len : (times.length == 0 ? 0 : times[times.length - 1]);
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Timeline> parse(Object root) {
        Map<String, Timeline> out = new LinkedHashMap<>();
        for (Map.Entry<String, Object> e : ((Map<String, Object>) root).entrySet()) {
            Map<String, Object> a = (Map<String, Object>) e.getValue();
            Number len = (Number) a.get("animation_length");
            out.put(e.getKey(), new Timeline(e.getKey(), len == null ? null : len.doubleValue(), a.get("loop"), (Map<String, Object>) a.get("timeline")));
        }
        return out;
    }

    public int commandCount() { int n = 0; for (List<String> l : commands) n += l.size(); return n; }

    /** Plays a timeline; advance() returns commands that became due. */
    public static final class Player {
        public final Timeline tl;
        private double t;
        private int idx;
        private boolean finished;
        public Player(Timeline tl) { this.tl = tl; }
        public boolean finished() { return finished; }
        public double time() { return t; }

        public List<String> advance(double dt) {
            if (finished) return List.of();
            t += dt;
            List<String> out = new ArrayList<>();
            while (idx < tl.times.length && tl.times[idx] <= t + 1e-9) out.addAll(tl.commands[idx++]);
            if (t >= tl.length - 1e-9) {
                if (tl.loop) { t -= tl.length; idx = 0; } else finished = true;
            }
            return out;
        }
    }
}
