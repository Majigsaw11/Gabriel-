package com.ukgabriel.bedrock;

import java.util.List;
import java.util.Map;

/**
 * Interpreter for Bedrock entity "events" as used by gabriel.entity.json: add/remove component_groups,
 * set_property, sequence (with int_property filters, all_of/any_of), randomize (weights), queue_command, trigger.
 * Unknown keys throw. Pure Java.
 */
public final class BedrockEvents {
    public interface Target {
        int prop(String name);
        void setProp(String name, int value);
        void addGroup(String group);
        void removeGroup(String group);
        void command(String command);
        double random();
    }

    private final Map<String, Object> events;

    public BedrockEvents(Map<String, Object> events) { this.events = events; }

    public boolean has(String event) { return events.containsKey(event); }

    @SuppressWarnings("unchecked")
    public void fire(String event, Target t) { fire(event, t, 0); }

    @SuppressWarnings("unchecked")
    private void fire(String event, Target t, int depth) {
        if (depth > 8) throw new IllegalStateException("event recursion at " + event);
        Object n = events.get(event);
        if (n == null) throw new IllegalArgumentException("unknown event " + event);
        apply((Map<String, Object>) n, t, depth);
    }

    @SuppressWarnings("unchecked")
    private void apply(Map<String, Object> node, Target t, int depth) {
        for (Map.Entry<String, Object> e : node.entrySet()) {
            Object v = e.getValue();
            switch (e.getKey()) {
                case "filters", "weight" -> { }
                case "add" -> { for (Object g : (List<Object>) ((Map<String, Object>) v).get("component_groups")) t.addGroup((String) g); }
                case "remove" -> { for (Object g : (List<Object>) ((Map<String, Object>) v).get("component_groups")) t.removeGroup((String) g); }
                case "set_property" -> { for (Map.Entry<String, Object> p : ((Map<String, Object>) v).entrySet()) t.setProp(p.getKey(), ((Number) p.getValue()).intValue()); }
                case "queue_command" -> { for (Object c : (List<Object>) ((Map<String, Object>) v).get("command")) t.command((String) c); }
                case "trigger" -> fire(v instanceof Map ? (String) ((Map<String, Object>) v).get("event") : (String) v, t, depth + 1);
                case "sequence" -> { for (Object el : (List<Object>) v) {
                    Map<String, Object> m = (Map<String, Object>) el;
                    if (passes(m.get("filters"), t)) apply(m, t, depth); } }
                case "randomize" -> {
                    List<Object> opts = (List<Object>) v;
                    double total = 0;
                    for (Object o : opts) total += ((Number) ((Map<String, Object>) o).getOrDefault("weight", 1.0)).doubleValue();
                    double r = t.random() * total;
                    for (Object o : opts) {
                        Map<String, Object> m = (Map<String, Object>) o;
                        r -= ((Number) m.getOrDefault("weight", 1.0)).doubleValue();
                        if (r < 0) { apply(m, t, depth); break; }
                    }
                }
                default -> throw new UnsupportedOperationException("event key " + e.getKey());
            }
        }
    }

    @SuppressWarnings("unchecked")
    private boolean passes(Object f, Target t) {
        if (f == null) return true;
        Map<String, Object> m = (Map<String, Object>) f;
        if (m.containsKey("all_of")) { for (Object o : (List<Object>) m.get("all_of")) if (!passes(o, t)) return false; return true; }
        if (m.containsKey("any_of")) { for (Object o : (List<Object>) m.get("any_of")) if (passes(o, t)) return true; return false; }
        if (!"int_property".equals(m.get("test"))) throw new UnsupportedOperationException("filter test " + m.get("test"));
        if (!"self".equals(m.get("subject"))) throw new UnsupportedOperationException("filter subject " + m.get("subject"));
        int a = t.prop((String) m.get("domain")), b = ((Number) m.get("value")).intValue();
        String op = (String) m.getOrDefault("operator", "==");
        return switch (op) {
            case "==", "equals" -> a == b;
            case "!=", "not_equals" -> a != b;
            case "<" -> a < b;
            case ">" -> a > b;
            case "<=" -> a <= b;
            case ">=" -> a >= b;
            default -> throw new UnsupportedOperationException("operator " + op);
        };
    }
}
