package com.ukgabriel.bedrock;

import com.ukgabriel.bedrock.molang.Molang;
import com.ukgabriel.bedrock.molang.Molang.Expr;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Runtime for Bedrock animation_controllers (format 1.10.0) as used by Gabriel's RP and BP controllers:
 * initial_state, states{animations[], blend_transition, transitions[{state: molang}], on_entry[]}.
 * Unknown keys throw so nothing is silently ignored. Pure Java.
 */
public final class BedrockController {
    public record Transition(String target, Expr condition) {}

    public static final class State {
        public final String name;
        public final List<String> animations = new ArrayList<>();
        public double blendSeconds;
        public final List<Transition> transitions = new ArrayList<>();
        public final List<String> onEntry = new ArrayList<>();
        State(String name) { this.name = name; }
    }

    public final String id;
    public final String initial;
    public final Map<String, State> states = new LinkedHashMap<>();
    private State current;
    public double stateTime;

    private BedrockController(String id, String initial) {
        this.id = id;
        this.initial = initial;
        reset();
    }

    public void reset() { current = states.get(initial); stateTime = 0; }
    public State current() { return current; }

    /** Advance one frame. Returns on_entry commands of a state entered this frame (empty if none). */
    public List<String> update(Molang.Scope scope, double dt) {
        if (current == null) current = states.get(initial);
        stateTime += dt;
        for (Transition t : current.transitions) {
            if (t.condition().eval(scope) != 0) {
                State next = states.get(t.target());
                if (next == null) throw new IllegalStateException("controller " + id + ": unknown state " + t.target());
                if (next != current) {
                    current = next;
                    stateTime = 0;
                    return current.onEntry;
                }
                return List.of();
            }
        }
        return List.of();
    }

    @SuppressWarnings("unchecked")
    public static Map<String, BedrockController> parse(Object root) {
        Map<String, BedrockController> out = new LinkedHashMap<>();
        Map<String, Object> all = (Map<String, Object>) ((Map<String, Object>) root).get("animation_controllers");
        for (Map.Entry<String, Object> e : all.entrySet()) {
            Map<String, Object> c = (Map<String, Object>) e.getValue();
            for (String k : c.keySet()) if (!k.equals("initial_state") && !k.equals("states"))
                throw new UnsupportedOperationException("controller key " + k + " in " + e.getKey());
            BedrockController bc = new BedrockController(e.getKey(), (String) c.get("initial_state"));
            for (Map.Entry<String, Object> se : ((Map<String, Object>) c.get("states")).entrySet()) {
                State st = new State(se.getKey());
                Map<String, Object> sm = (Map<String, Object>) se.getValue();
                for (Map.Entry<String, Object> ke : sm.entrySet()) {
                    switch (ke.getKey()) {
                        case "animations" -> { for (Object a : (List<Object>) ke.getValue()) {
                            if (!(a instanceof String)) throw new UnsupportedOperationException("conditional animation entry in " + e.getKey());
                            st.animations.add((String) a); } }
                        case "blend_transition" -> st.blendSeconds = ((Number) ke.getValue()).doubleValue();
                        case "transitions" -> { for (Object t : (List<Object>) ke.getValue()) {
                            Map<String, Object> tm = (Map<String, Object>) t;
                            Map.Entry<String, Object> te = tm.entrySet().iterator().next();
                            st.transitions.add(new Transition(te.getKey(), Molang.compile(te.getValue()))); } }
                        case "on_entry" -> { for (Object cmd : (List<Object>) ke.getValue()) st.onEntry.add((String) cmd); }
                        default -> throw new UnsupportedOperationException("state key " + ke.getKey() + " in " + e.getKey());
                    }
                }
                bc.states.put(st.name, st);
            }
            bc.reset();
            out.put(e.getKey(), bc);
        }
        return out;
    }
}
