package com.ukgabriel.bedrock;

import com.ukgabriel.bedrock.molang.Molang;

import java.util.*;

/**
 * Evaluates the resource-pack side of Gabriel's client entity: scripts.animate conditions, the joh/aoh animation
 * controllers (gabriel:anim -> animation(s)) and plain animations like enrage_ring. Pure Java; the Forge client
 * feeds it entity properties every tick and reads the resulting animation ids (to play with GeckoLib).
 */
public final class RpAnimator {
    public interface Props { int prop(String name); }

    private record Entry(String alias, Molang.Expr condition) {}
    private final List<Entry> animate = new ArrayList<>();
    private final Map<String, BedrockController> controllersById;
    private final Map<String, String> aliases = new HashMap<>();
    private final Map<String, String> particleEffects = new HashMap<>();
    private final List<String> active = new ArrayList<>();
    private double blend;

    @SuppressWarnings("unchecked")
    public RpAnimator(Object controllersRoot, Object clientEntityRoot) {
        controllersById = BedrockController.parse(controllersRoot);
        Map<String, Object> desc = (Map<String, Object>) ((Map<String, Object>) ((Map<String, Object>) clientEntityRoot).get("minecraft:client_entity")).get("description");
        for (Map.Entry<String, Object> e : ((Map<String, Object>) desc.get("animations")).entrySet()) aliases.put(e.getKey(), (String) e.getValue());
        Map<String, Object> pe = (Map<String, Object>) desc.get("particle_effects");
        if (pe != null) for (Map.Entry<String, Object> e : pe.entrySet()) particleEffects.put(e.getKey(), (String) e.getValue());
        for (Object o : (List<Object>) ((Map<String, Object>) desc.get("scripts")).get("animate")) {
            Map.Entry<String, Object> en = ((Map<String, Object>) o).entrySet().iterator().next();
            animate.add(new Entry(en.getKey(), Molang.compile(en.getValue())));
        }
    }

    /** Bedrock particle id for an animation particle-effect alias (e.g. "ring" -> "gabriel:enrage_ring"). */
    public String particleFor(String alias) { return particleEffects.get(alias); }

    public void tick(Props props, double dt) {
        Molang.Scope scope = new Molang.Scope() {
            public double get(String n) { return 0; }
            public double query(String n, String arg) {
                if (n.equals("property")) return props.prop(arg);
                throw new IllegalStateException("unsupported query " + n);
            }
        };
        active.clear();
        blend = 0;
        for (Entry e : animate) {
            String target = aliases.get(e.alias());
            BedrockController c = controllersById.get(target);
            if (e.condition().eval(scope) == 0) { if (c != null) c.reset(); continue; }
            if (c == null) { active.add(target); continue; }
            c.update(scope, dt);
            for (String a : c.current().animations) active.add(aliases.get(a));
            blend = Math.max(blend, c.current().blendSeconds);
        }
    }

    /** Animation ids to play right now, in slot order. */
    public List<String> active() { return active; }
    public double blendSeconds() { return blend; }
}
