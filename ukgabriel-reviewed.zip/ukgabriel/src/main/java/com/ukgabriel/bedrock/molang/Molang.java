package com.ukgabriel.bedrock.molang;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Small Molang interpreter (superset of what Gabriel's particles/animations use). Pure Java, no Minecraft deps. */
public final class Molang {
    private Molang() {}

    public interface Scope {
        double get(String name);
        default void set(String name, double value) {}
        default double random() { return Math.random(); }
        /** query.name('arg') style calls, e.g. query.property('gabriel:anim'). */
        default double query(String name, String arg) { return 0; }
    }

    @FunctionalInterface
    public interface Expr { double eval(Scope s); }

    public static final Expr ZERO = s -> 0;

    public static Expr constant(double v) { return s -> v; }

    public static Expr compile(Object o) {
        if (o == null) return ZERO;
        if (o instanceof Number n) return constant(n.doubleValue());
        if (o instanceof Boolean b) return constant(b ? 1 : 0);
        return new Parser(o.toString()).program();
    }

    static String normalize(String id) {
        if (id.startsWith("variable.")) return "v." + id.substring(9);
        if (id.startsWith("query.")) return "q." + id.substring(6);
        if (id.startsWith("temp.")) return "t." + id.substring(5);
        if (id.startsWith("context.")) return "c." + id.substring(8);
        return id;
    }

    private static final class Parser {
        final List<String> t = new ArrayList<>();
        int p;
        final String src;

        Parser(String src) {
            this.src = src;
            tokenize(src);
        }

        void tokenize(String s) {
            int i = 0, n = s.length();
            while (i < n) {
                char c = s.charAt(i);
                if (Character.isWhitespace(c)) { i++; continue; }
                if (Character.isDigit(c) || (c == '.' && i + 1 < n && Character.isDigit(s.charAt(i + 1)))) {
                    int j = i;
                    while (j < n && (Character.isDigit(s.charAt(j)) || s.charAt(j) == '.')) j++;
                    t.add(s.substring(i, j));
                    i = j;
                    continue;
                }
                if (Character.isLetter(c) || c == '_') {
                    int j = i;
                    while (j < n && (Character.isLetterOrDigit(s.charAt(j)) || s.charAt(j) == '_' || s.charAt(j) == '.')) j++;
                    t.add(s.substring(i, j).toLowerCase(Locale.ROOT));
                    i = j;
                    continue;
                }
                if (c == '\'') {
                    int j = s.indexOf('\'', i + 1);
                    if (j < 0) throw err("unterminated string");
                    t.add(s.substring(i, j + 1));
                    i = j + 1;
                    continue;
                }
                if (i + 1 < n) {
                    String two = s.substring(i, i + 2);
                    if (two.equals("==") || two.equals("!=") || two.equals("<=") || two.equals(">=")
                            || two.equals("&&") || two.equals("||") || two.equals("??")) {
                        t.add(two);
                        i += 2;
                        continue;
                    }
                }
                t.add(String.valueOf(c));
                i++;
            }
        }

        RuntimeException err(String m) { return new IllegalArgumentException("Molang: " + m + " in '" + src + "'"); }
        boolean peek(String s) { return p < t.size() && t.get(p).equals(s); }
        void expect(String s) { if (!peek(s)) throw err("expected '" + s + "'"); p++; }

        Expr program() {
            List<Expr> stmts = new ArrayList<>();
            while (p < t.size()) {
                if (peek(";")) { p++; continue; }
                if (peek("return")) p++;
                stmts.add(statement());
                if (p < t.size() && !peek(";")) throw err("unexpected '" + t.get(p) + "'");
            }
            if (stmts.isEmpty()) return ZERO;
            if (stmts.size() == 1) return stmts.get(0);
            Expr[] arr = stmts.toArray(new Expr[0]);
            return s -> { double r = 0; for (Expr e : arr) r = e.eval(s); return r; };
        }

        Expr statement() {
            if (p + 1 < t.size() && t.get(p + 1).equals("=") && (Character.isLetter(t.get(p).charAt(0)) || t.get(p).charAt(0) == '_')) {
                String name = normalize(t.get(p));
                p += 2;
                Expr rhs = ternary();
                return s -> { double v = rhs.eval(s); s.set(name, v); return v; };
            }
            return ternary();
        }

        Expr ternary() {
            Expr c = coalesce();
            if (peek("?")) {
                p++;
                Expr a = ternary();
                Expr b = ZERO;
                if (peek(":")) { p++; b = ternary(); }
                Expr bb = b;
                return s -> c.eval(s) != 0 ? a.eval(s) : bb.eval(s);
            }
            return c;
        }

        Expr coalesce() {
            Expr l = or();
            while (peek("??")) { p++; Expr r = or(); Expr ll = l; l = s -> { double v = ll.eval(s); return v != 0 ? v : r.eval(s); }; }
            return l;
        }

        Expr or() {
            Expr l = and();
            while (peek("||")) { p++; Expr r = and(); Expr ll = l; l = s -> (ll.eval(s) != 0 || r.eval(s) != 0) ? 1 : 0; }
            return l;
        }

        Expr and() {
            Expr l = equality();
            while (peek("&&")) { p++; Expr r = equality(); Expr ll = l; l = s -> (ll.eval(s) != 0 && r.eval(s) != 0) ? 1 : 0; }
            return l;
        }

        Expr equality() {
            Expr l = relational();
            while (peek("==") || peek("!=")) {
                boolean eq = t.get(p++).equals("==");
                Expr r = relational(); Expr ll = l;
                l = eq ? s -> ll.eval(s) == r.eval(s) ? 1 : 0 : s -> ll.eval(s) != r.eval(s) ? 1 : 0;
            }
            return l;
        }

        Expr relational() {
            Expr l = additive();
            while (peek("<") || peek(">") || peek("<=") || peek(">=")) {
                String op = t.get(p++);
                Expr r = additive(); Expr ll = l;
                switch (op) {
                    case "<" -> l = s -> ll.eval(s) < r.eval(s) ? 1 : 0;
                    case ">" -> l = s -> ll.eval(s) > r.eval(s) ? 1 : 0;
                    case "<=" -> l = s -> ll.eval(s) <= r.eval(s) ? 1 : 0;
                    default -> l = s -> ll.eval(s) >= r.eval(s) ? 1 : 0;
                }
            }
            return l;
        }

        Expr additive() {
            Expr l = multiplicative();
            while (peek("+") || peek("-")) {
                boolean add = t.get(p++).equals("+");
                Expr r = multiplicative(); Expr ll = l;
                l = add ? s -> ll.eval(s) + r.eval(s) : s -> ll.eval(s) - r.eval(s);
            }
            return l;
        }

        Expr multiplicative() {
            Expr l = unary();
            while (peek("*") || peek("/")) {
                boolean mul = t.get(p++).equals("*");
                Expr r = unary(); Expr ll = l;
                l = mul ? s -> ll.eval(s) * r.eval(s) : s -> { double d = r.eval(s); return d == 0 ? 0 : ll.eval(s) / d; };
            }
            return l;
        }

        Expr unary() {
            if (peek("-")) { p++; Expr e = unary(); return s -> -e.eval(s); }
            if (peek("+")) { p++; return unary(); }
            if (peek("!")) { p++; Expr e = unary(); return s -> e.eval(s) == 0 ? 1 : 0; }
            return primary();
        }

        Expr primary() {
            if (p >= t.size()) throw err("unexpected end");
            String tok = t.get(p++);
            char c = tok.charAt(0);
            if (Character.isDigit(c) || c == '.') return constant(Double.parseDouble(tok));
            if (c == '(') { Expr e = ternary(); expect(")"); return e; }
            if (c == '\'') return ZERO;
            if (Character.isLetter(c) || c == '_') {
                if (peek("(")) {
                    p++;
                    List<Expr> args = new ArrayList<>();
                    String strArg = null;
                    if (!peek(")")) {
                        do {
                            if (p < t.size() && t.get(p).startsWith("'")) {
                                if (strArg == null) strArg = t.get(p).substring(1, t.get(p).length() - 1);
                                p++;
                                args.add(ZERO);
                            } else args.add(ternary());
                            if (peek(",")) p++; else break;
                        } while (true);
                    }
                    expect(")");
                    if (tok.startsWith("query.") || tok.startsWith("q.")) {
                        String qn = normalize(tok).substring(2);
                        String sa = strArg;
                        return s -> s.query(qn, sa);
                    }
                    return function(tok, args.toArray(new Expr[0]));
                }
                switch (tok) {
                    case "true": return constant(1);
                    case "false": return constant(0);
                    case "math.pi": return constant(Math.PI);
                    default: break;
                }
                String name = normalize(tok);
                return s -> s.get(name);
            }
            throw err("unexpected '" + tok + "'");
        }

        Expr function(String raw, Expr[] a) {
            String f = raw.startsWith("math.") ? raw.substring(5) : raw;
            final double D = Math.PI / 180.0;
            switch (f) {
                case "abs": return s -> Math.abs(a[0].eval(s));
                case "sin": return s -> Math.sin(a[0].eval(s) * D);
                case "cos": return s -> Math.cos(a[0].eval(s) * D);
                case "asin": return s -> Math.asin(a[0].eval(s)) / D;
                case "acos": return s -> Math.acos(a[0].eval(s)) / D;
                case "atan": return s -> Math.atan(a[0].eval(s)) / D;
                case "atan2": return s -> Math.atan2(a[0].eval(s), a[1].eval(s)) / D;
                case "ceil": return s -> Math.ceil(a[0].eval(s));
                case "floor": return s -> Math.floor(a[0].eval(s));
                case "round": return s -> Math.rint(a[0].eval(s));
                case "trunc": return s -> { double v = a[0].eval(s); return v < 0 ? Math.ceil(v) : Math.floor(v); };
                case "sqrt": return s -> Math.sqrt(a[0].eval(s));
                case "exp": return s -> Math.exp(a[0].eval(s));
                case "ln": return s -> Math.log(a[0].eval(s));
                case "pow": return s -> Math.pow(a[0].eval(s), a[1].eval(s));
                case "min": return s -> Math.min(a[0].eval(s), a[1].eval(s));
                case "max": return s -> Math.max(a[0].eval(s), a[1].eval(s));
                case "mod": return s -> { double d = a[1].eval(s); return d == 0 ? 0 : a[0].eval(s) % d; };
                case "clamp": return s -> Math.max(a[1].eval(s), Math.min(a[2].eval(s), a[0].eval(s)));
                case "lerp": return s -> { double x = a[0].eval(s), y = a[1].eval(s), k = a[2].eval(s); return x + (y - x) * k; };
                case "random": return s -> { double lo = a[0].eval(s), hi = a[1].eval(s); return lo + s.random() * (hi - lo); };
                case "random_integer": return s -> { double lo = a[0].eval(s), hi = a[1].eval(s); return Math.floor(lo + s.random() * (hi - lo + 1)); };
                default: throw err("unsupported function '" + raw + "'");
            }
        }
    }
}
