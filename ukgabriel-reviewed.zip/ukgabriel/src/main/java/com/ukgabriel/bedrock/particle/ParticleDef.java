package com.ukgabriel.bedrock.particle;

import com.ukgabriel.bedrock.molang.Molang;
import com.ukgabriel.bedrock.molang.Molang.Expr;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Parsed Bedrock particle_effect (format 1.10.0). Built from a plain JSON object tree
 * (Map/List/Number/String/Boolean, e.g. Gson's Object.class output). Unknown components or keys
 * throw instead of being skipped, so no particle behaviour can be silently dropped.
 */
public final class ParticleDef {
    public enum Facing { ROTATE_XYZ, ROTATE_Y, LOOKAT_XYZ, LOOKAT_Y, DIRECTION_X, DIRECTION_Y, DIRECTION_Z }
    public enum ShapeKind { POINT, SPHERE }
    public enum DirMode { OUTWARDS, INWARDS, CUSTOM }

    public String identifier, material, texture;

    // emitter
    public Expr emitterActiveTime;          // emitter_lifetime_once.active_time
    public Expr instantCount;               // emitter_rate_instant.num_particles (null if steady)
    public Expr steadyRate, steadyMax;      // emitter_rate_steady
    public ShapeKind shape = ShapeKind.POINT;
    public Expr[] shapeOffset = {Molang.ZERO, Molang.ZERO, Molang.ZERO};
    public Expr shapeRadius = Molang.ZERO;
    public boolean shapeSurfaceOnly;
    public DirMode dirMode = DirMode.OUTWARDS;
    public Expr[] dirCustom = {Molang.ZERO, Molang.ZERO, Molang.ZERO};

    // particle
    public Expr maxLifetime;
    public Expr initialSpeed;               // scalar speed along emitter direction
    public Expr[] initialVelocity;          // or explicit vec3
    public boolean hasMotion;               // particle_motion_dynamic present
    public Expr[] linearAccel = {Molang.ZERO, Molang.ZERO, Molang.ZERO};
    public Expr linearDrag = Molang.ZERO;
    public Expr rotAccel = Molang.ZERO, rotDrag = Molang.ZERO;
    public Expr initialRotation = Molang.ZERO, initialRotationRate = Molang.ZERO;

    // appearance
    public Expr sizeW, sizeH;
    public Facing facing = Facing.ROTATE_XYZ;
    public boolean dirFromVelocity;
    public double dirMinSpeed = 0.01;
    public int texW = 16, texH = 16;
    public double u, v, uSize = 16, vSize = 16;
    public Expr[] color;                    // rgba exprs, or null if gradient
    public Expr gradientInterpolant;
    public float[] gradientStops;           // sorted keys
    public float[][] gradientColors;        // rgba per stop

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Object o) { return (Map<String, Object>) o; }
    @SuppressWarnings("unchecked")
    private static List<Object> list(Object o) { return (List<Object>) o; }

    private static Expr[] vec3(Object o) {
        List<Object> l = list(o);
        Expr[] r = new Expr[3];
        for (int i = 0; i < 3; i++) r[i] = Molang.compile(l.get(i));
        return r;
    }

    private static void only(String where, Map<String, Object> m, String... allowed) {
        outer:
        for (String k : m.keySet()) {
            for (String a : allowed) if (a.equals(k)) continue outer;
            throw new UnsupportedOperationException("Unsupported key '" + k + "' in " + where);
        }
    }

    public static ParticleDef parse(Object root) {
        Map<String, Object> pe = map(map(root).get("particle_effect"));
        ParticleDef d = new ParticleDef();
        Map<String, Object> desc = map(pe.get("description"));
        d.identifier = (String) desc.get("identifier");
        Map<String, Object> brp = map(desc.get("basic_render_parameters"));
        d.material = (String) brp.get("material");
        d.texture = (String) brp.get("texture");

        for (Map.Entry<String, Object> e : map(pe.get("components")).entrySet()) {
            String k = e.getKey();
            Object v = e.getValue();
            switch (k) {
                case "minecraft:emitter_lifetime_once" -> {
                    only(k, map(v), "active_time");
                    d.emitterActiveTime = Molang.compile(map(v).get("active_time"));
                }
                case "minecraft:emitter_rate_instant" -> {
                    only(k, map(v), "num_particles");
                    d.instantCount = Molang.compile(map(v).get("num_particles"));
                }
                case "minecraft:emitter_rate_steady" -> {
                    only(k, map(v), "spawn_rate", "max_particles");
                    d.steadyRate = Molang.compile(map(v).get("spawn_rate"));
                    d.steadyMax = Molang.compile(map(v).get("max_particles"));
                }
                case "minecraft:emitter_shape_point" -> {
                    only(k, map(v), "offset", "direction");
                    d.shape = ShapeKind.POINT;
                    if (map(v).containsKey("offset")) d.shapeOffset = vec3(map(v).get("offset"));
                    if (map(v).containsKey("direction")) { d.dirMode = DirMode.CUSTOM; d.dirCustom = vec3(map(v).get("direction")); }
                    else d.dirMode = DirMode.CUSTOM;
                }
                case "minecraft:emitter_shape_sphere" -> {
                    only(k, map(v), "offset", "radius", "direction", "surface_only");
                    d.shape = ShapeKind.SPHERE;
                    if (map(v).containsKey("offset")) d.shapeOffset = vec3(map(v).get("offset"));
                    d.shapeRadius = Molang.compile(map(v).get("radius"));
                    d.shapeSurfaceOnly = Boolean.TRUE.equals(map(v).get("surface_only"));
                    Object dir = map(v).get("direction");
                    if (dir instanceof String s) d.dirMode = s.equals("inwards") ? DirMode.INWARDS : DirMode.OUTWARDS;
                    else if (dir != null) { d.dirMode = DirMode.CUSTOM; d.dirCustom = vec3(dir); }
                }
                case "minecraft:particle_lifetime_expression" -> {
                    only(k, map(v), "max_lifetime");
                    d.maxLifetime = Molang.compile(map(v).get("max_lifetime"));
                }
                case "minecraft:particle_initial_speed" -> {
                    if (v instanceof List) d.initialVelocity = vec3(v);
                    else d.initialSpeed = Molang.compile(v);
                }
                case "minecraft:particle_motion_dynamic" -> {
                    Map<String, Object> m = map(v);
                    only(k, m, "linear_acceleration", "linear_drag_coefficient", "rotation_acceleration", "rotation_drag_coefficient");
                    d.hasMotion = true;
                    if (m.containsKey("linear_acceleration")) d.linearAccel = vec3(m.get("linear_acceleration"));
                    if (m.containsKey("linear_drag_coefficient")) d.linearDrag = Molang.compile(m.get("linear_drag_coefficient"));
                    if (m.containsKey("rotation_acceleration")) d.rotAccel = Molang.compile(m.get("rotation_acceleration"));
                    if (m.containsKey("rotation_drag_coefficient")) d.rotDrag = Molang.compile(m.get("rotation_drag_coefficient"));
                }
                case "minecraft:particle_initial_spin" -> {
                    only(k, map(v), "rotation", "rotation_rate");
                    if (map(v).containsKey("rotation")) d.initialRotation = Molang.compile(map(v).get("rotation"));
                    if (map(v).containsKey("rotation_rate")) d.initialRotationRate = Molang.compile(map(v).get("rotation_rate"));
                }
                case "minecraft:particle_appearance_billboard" -> {
                    Map<String, Object> m = map(v);
                    only(k, m, "size", "facing_camera_mode", "direction", "uv");
                    List<Object> sz = list(m.get("size"));
                    d.sizeW = Molang.compile(sz.get(0));
                    d.sizeH = Molang.compile(sz.get(1));
                    d.facing = switch ((String) m.get("facing_camera_mode")) {
                        case "rotate_xyz" -> Facing.ROTATE_XYZ;
                        case "rotate_y" -> Facing.ROTATE_Y;
                        case "lookat_xyz" -> Facing.LOOKAT_XYZ;
                        case "lookat_y" -> Facing.LOOKAT_Y;
                        case "direction_x" -> Facing.DIRECTION_X;
                        case "direction_y" -> Facing.DIRECTION_Y;
                        case "direction_z" -> Facing.DIRECTION_Z;
                        default -> throw new UnsupportedOperationException("facing_camera_mode " + m.get("facing_camera_mode"));
                    };
                    if (m.containsKey("direction")) {
                        Map<String, Object> dm = map(m.get("direction"));
                        only("billboard.direction", dm, "mode", "min_speed_threshold");
                        if (!"derive_from_velocity".equals(dm.get("mode"))) throw new UnsupportedOperationException("direction.mode " + dm.get("mode"));
                        d.dirFromVelocity = true;
                        if (dm.containsKey("min_speed_threshold")) d.dirMinSpeed = ((Number) dm.get("min_speed_threshold")).doubleValue();
                    }
                    Map<String, Object> uv = map(m.get("uv"));
                    only("billboard.uv", uv, "texture_width", "texture_height", "uv", "uv_size");
                    d.texW = ((Number) uv.get("texture_width")).intValue();
                    d.texH = ((Number) uv.get("texture_height")).intValue();
                    List<Object> uu = list(uv.get("uv")), us = list(uv.get("uv_size"));
                    d.u = ((Number) uu.get(0)).doubleValue(); d.v = ((Number) uu.get(1)).doubleValue();
                    d.uSize = ((Number) us.get(0)).doubleValue(); d.vSize = ((Number) us.get(1)).doubleValue();
                }
                case "minecraft:particle_appearance_tinting" -> {
                    Map<String, Object> m = map(v);
                    only(k, m, "color");
                    Object c = m.get("color");
                    if (c instanceof List) {
                        List<Object> l = list(c);
                        d.color = new Expr[4];
                        for (int i = 0; i < 4; i++) d.color[i] = Molang.compile(l.get(i));
                    } else {
                        Map<String, Object> g = map(c);
                        only("tinting.color", g, "interpolant", "gradient");
                        d.gradientInterpolant = Molang.compile(g.get("interpolant"));
                        TreeMap<Float, float[]> st = new TreeMap<>();
                        Object grad = g.get("gradient");
                        if (grad instanceof Map) {
                            for (Map.Entry<String, Object> ge : map(grad).entrySet())
                                st.put(Float.parseFloat(ge.getKey()), hex((String) ge.getValue()));
                        } else {
                            List<Object> gl = list(grad);
                            for (int i = 0; i < gl.size(); i++)
                                st.put(gl.size() == 1 ? 0f : i / (float) (gl.size() - 1), hex((String) gl.get(i)));
                        }
                        d.gradientStops = new float[st.size()];
                        d.gradientColors = new float[st.size()][];
                        int i = 0;
                        for (Map.Entry<Float, float[]> se : st.entrySet()) { d.gradientStops[i] = se.getKey(); d.gradientColors[i++] = se.getValue(); }
                    }
                }
                default -> throw new UnsupportedOperationException("Unsupported particle component " + k + " in " + d.identifier);
            }
        }
        if (d.maxLifetime == null) d.maxLifetime = Molang.constant(1);
        if (d.initialSpeed == null && d.initialVelocity == null) d.initialSpeed = Molang.ZERO;
        if (d.sizeW == null) throw new IllegalArgumentException(d.identifier + " has no billboard appearance");
        if (d.color == null && d.gradientStops == null) d.color = new Expr[]{Molang.constant(1), Molang.constant(1), Molang.constant(1), Molang.constant(1)};
        return d;
    }

    /** Bedrock hex colours are #AARRGGBB (or #RRGGBB). Returns r,g,b,a in 0..1. */
    static float[] hex(String s) {
        String h = s.startsWith("#") ? s.substring(1) : s;
        long v = Long.parseLong(h, 16);
        float a = 1f, r, g, b;
        if (h.length() == 8) { a = ((v >> 24) & 255) / 255f; r = ((v >> 16) & 255) / 255f; g = ((v >> 8) & 255) / 255f; b = (v & 255) / 255f; }
        else { r = ((v >> 16) & 255) / 255f; g = ((v >> 8) & 255) / 255f; b = (v & 255) / 255f; }
        return new float[]{r, g, b, a};
    }
}
