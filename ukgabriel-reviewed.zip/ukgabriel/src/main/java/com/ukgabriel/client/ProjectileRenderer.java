package com.ukgabriel.client;

import com.ukgabriel.entity.GabrielProjectile;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class ProjectileRenderer extends GeoEntityRenderer<GabrielProjectile> {
    public ProjectileRenderer(EntityRendererProvider.Context ctx, String kind) {
        super(ctx, new ProjectileModel());
        withScale(ProjectileAnimation.cfg(kind).scale());   // client entity scripts.scale (spiral_sword 0.8)
    }
}
