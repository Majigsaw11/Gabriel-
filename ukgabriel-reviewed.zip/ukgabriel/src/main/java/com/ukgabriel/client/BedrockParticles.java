package com.ukgabriel.client;

import com.google.gson.Gson;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.logging.LogUtils;
import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.bedrock.particle.BedrockEmitter;
import com.ukgabriel.bedrock.particle.BedrockParticle;
import com.ukgabriel.bedrock.particle.BillboardMath;
import com.ukgabriel.bedrock.particle.ParticleDef;
import net.minecraft.client.Camera;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.slf4j.Logger;

import java.io.Reader;
import java.util.*;

/**
 * Runtime for the add-on's own Bedrock particle JSON (gabriel:* and uk:* effects). The definitions in
 * assets/ukgabriel/bedrock_particles are the unmodified originals; nothing is replaced by vanilla particles.
 */
@Mod.EventBusSubscriber(modid = UkGabrielMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class BedrockParticles {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<String, ParticleDef> DEFS = new HashMap<>();
    private static final List<BedrockEmitter> EMITTERS = new ArrayList<>();
    private static final Set<String> WARNED = new HashSet<>();
    private static final Random SEEDS = new Random();
    private static final int MAX_EMITTERS = 512;

    private BedrockParticles() {}

    /** Client resource reload: parse every bedrock_particles/*.json. Unsupported components throw (never silently skipped). */
    public static void load(ResourceManager rm) {
        DEFS.clear();
        EMITTERS.clear();
        for (Map.Entry<ResourceLocation, Resource> e : rm.listResources("bedrock_particles", p -> p.getPath().endsWith(".json")).entrySet()) {
            if (!e.getKey().getNamespace().equals(UkGabrielMod.MODID)) continue;
            try (Reader r = e.getValue().openAsReader()) {
                ParticleDef d = ParticleDef.parse(new Gson().fromJson(r, Object.class));
                DEFS.put(d.identifier, d);
            } catch (Exception ex) {
                throw new IllegalStateException("Cannot load Bedrock particle " + e.getKey(), ex);
            }
        }
        LOGGER.info("Gabriel: loaded {} Bedrock particle definitions", DEFS.size());
    }

    public static void spawn(String id, double x, double y, double z) {
        ParticleDef d = DEFS.get(id);
        if (d == null) { if (WARNED.add(id)) LOGGER.warn("Gabriel: unknown Bedrock particle {}", id); return; }
        if (EMITTERS.size() < MAX_EMITTERS) EMITTERS.add(new BedrockEmitter(d, x, y, z, SEEDS.nextLong()));
    }

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || EMITTERS.isEmpty()) return;
        if (Minecraft.getInstance().isPaused()) return;
        EMITTERS.removeIf(em -> { em.tick(0.05); return em.done(); });
    }

    @SubscribeEvent
    public static void render(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || EMITTERS.isEmpty()) return;
        Camera cam = e.getCamera();
        Vec3 cp = cam.getPosition();
        PoseStack ps = e.getPoseStack();
        Matrix4f pose = ps.last().pose();
        double partial = e.getPartialTick() * 0.05;

        Vector3f left = cam.getLeftVector(), upv = cam.getUpVector();
        double[] camRight = {-left.x(), -left.y(), -left.z()};
        double[] camUp = {upv.x(), upv.y(), upv.z()};

        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getParticleShader);

        BedrockParticle.Sample s = new BedrockParticle.Sample();
        double[] toCam = new double[3], dir = new double[3], c = new double[12];
        for (BedrockEmitter em : EMITTERS) {
            if (em.particles.isEmpty()) continue;
            ParticleDef d = em.def;
            RenderSystem.setShaderTexture(0, new ResourceLocation(UkGabrielMod.MODID, d.texture + ".png"));
            if (d.material.equals("particles_add")) RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            else RenderSystem.defaultBlendFunc();
            BufferBuilder bb = Tesselator.getInstance().getBuilder();
            bb.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
            for (BedrockParticle p : em.particles) {
                p.sample(partial, s);
                if (s.alpha <= 0.001f) continue;
                double rx = s.x - cp.x, ry = s.y - cp.y, rz = s.z - cp.z;
                toCam[0] = -rx; toCam[1] = -ry; toCam[2] = -rz;
                dir[0] = s.dirX; dir[1] = s.dirY; dir[2] = s.dirZ;
                BillboardMath.corners(d.facing, s.w, s.h, Math.toRadians(s.rotation), toCam, camRight, camUp, dir, d.dirMinSpeed, c);
                float[] u = {s.u0, s.u0, s.u1, s.u1}, v = {s.v1, s.v0, s.v0, s.v1};
                for (int k = 0; k < 4; k++)
                    bb.vertex(pose, (float) (rx + c[k * 3]), (float) (ry + c[k * 3 + 1]), (float) (rz + c[k * 3 + 2]))
                      .uv(u[k], v[k]).color(clamp(s.red), clamp(s.green), clamp(s.blue), clamp(s.alpha))
                      .uv2(LightTexture.FULL_BRIGHT).endVertex();
            }
            Tesselator.getInstance().end();
        }
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private static float clamp(float f) { return Math.max(0f, Math.min(1f, f)); }
}
