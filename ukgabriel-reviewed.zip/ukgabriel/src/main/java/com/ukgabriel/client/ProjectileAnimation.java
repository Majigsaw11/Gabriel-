package com.ukgabriel.client;

import com.google.gson.Gson;
import com.mojang.logging.LogUtils;
import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.entity.GabrielProjectile;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;

import java.io.IOException;
import java.io.Reader;
import java.util.*;

/** Client config + animation glue for the seven projectile entities, read from the original RP client entity files. */
public final class ProjectileAnimation {
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final int SLOTS = 3;

    public record Cfg(String geometry, String texture, List<String> animate, Map<String, String> animations,
                      Map<String, String> sounds, Map<String, String> particles, float scale) {}

    private static final Map<String, Cfg> CFG = new HashMap<>();
    private static final Map<GabrielProjectile, String[]> CURRENT = new WeakHashMap<>();

    private ProjectileAnimation() {}

    @SuppressWarnings("unchecked")
    public static synchronized Cfg cfg(String kind) {
        return CFG.computeIfAbsent(kind, k -> {
            try (Reader r = Minecraft.getInstance().getResourceManager().getResource(new ResourceLocation(UkGabrielMod.MODID, "client_entity/" + k + ".entity.json"))
                    .orElseThrow(() -> new IOException("missing client entity " + k)).openAsReader()) {
                Map<String, Object> root = (Map<String, Object>) new Gson().fromJson(r, Object.class);
                Map<String, Object> d = (Map<String, Object>) ((Map<String, Object>) root.get("minecraft:client_entity")).get("description");
                String geo = ((String) ((Map<String, Object>) d.get("geometry")).get("default")).replace("geometry.", "");
                String tex = (String) ((Map<String, Object>) d.get("textures")).get("default");
                Map<String, Object> scripts = (Map<String, Object>) d.getOrDefault("scripts", Map.of());
                List<String> animate = new ArrayList<>();
                for (Object a : (List<Object>) scripts.getOrDefault("animate", List.of())) animate.add((String) a);
                float scale = scripts.containsKey("scale") ? Float.parseFloat(String.valueOf(scripts.get("scale"))) : 1f;
                return new Cfg(geo, tex, animate, strMap(d.get("animations")), strMap(d.get("sound_effects")), strMap(d.get("particle_effects")), scale);
            } catch (IOException e) { throw new IllegalStateException(e); }
        });
    }

    @SuppressWarnings("unchecked")
    private static Map<String, String> strMap(Object o) {
        Map<String, String> m = new HashMap<>();
        if (o != null) for (Map.Entry<String, Object> e : ((Map<String, Object>) o).entrySet()) m.put(e.getKey(), (String) e.getValue());
        return m;
    }

    public static PlayState play(GabrielProjectile e, int slot, AnimationState<GabrielProjectile> st) {
        Cfg c = cfg(e.kindName());
        String[] cur = CURRENT.computeIfAbsent(e, x -> new String[SLOTS]);
        if (slot >= c.animate().size()) return PlayState.STOP;
        String id = c.animations().get(c.animate().get(slot));
        if (id == null) return PlayState.STOP;
        if (!id.equals(cur[slot])) {
            cur[slot] = id;
            st.getController().setAnimation(RawAnimation.begin().then(id, Animation.LoopType.DEFAULT));
        }
        return PlayState.CONTINUE;
    }

    /** particle_effects keyframe ("trail" -> uk:blue_dust). */
    public static void particle(GabrielProjectile e, String alias) {
        String id = cfg(e.kindName()).particles().get(alias);
        if (id == null) { LOGGER.warn("Gabriel projectile {}: particle alias '{}' unmapped", e.kindName(), alias); return; }
        BedrockParticles.spawn(id, e.getX(), e.getY(), e.getZ());
    }

    /** sound_effects keyframe ("spawn" -> gabriel.sword.spawn). */
    public static void sound(GabrielProjectile e, String alias) {
        String id = cfg(e.kindName()).sounds().get(alias);
        if (id == null) return;
        SoundEvent ev = ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation(UkGabrielMod.MODID, id));
        if (ev != null) e.level().playLocalSound(e.getX(), e.getY(), e.getZ(), ev, SoundSource.HOSTILE, 1f, 1f, false);
    }
}
