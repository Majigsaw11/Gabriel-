package com.ukgabriel.client;

import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.entity.GabrielEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class GabrielModel extends GeoModel<GabrielEntity> {
    private static final ResourceLocation MODEL = new ResourceLocation(UkGabrielMod.MODID, "geo/gabriel_ultrakill_judge.geo.json");
    private static final ResourceLocation ANIMS = new ResourceLocation(UkGabrielMod.MODID, "animations/gabriel_all.animation.json");
    private static final ResourceLocation JUDGE = new ResourceLocation(UkGabrielMod.MODID, "textures/entity/gabriel/judge.png");
    private static final ResourceLocation PHASE2 = new ResourceLocation(UkGabrielMod.MODID, "textures/entity/gabriel/gabriel_phase2.png");
    private static final ResourceLocation ENRAGED = new ResourceLocation(UkGabrielMod.MODID, "textures/entity/gabriel/judge_enraged.png");
    private static final ResourceLocation ALT = new ResourceLocation(UkGabrielMod.MODID, "textures/entity/gabriel/judge_alt.png");
    private static final ResourceLocation[] SKINS = {JUDGE, PHASE2, ENRAGED};

    @Override public ResourceLocation getModelResource(GabrielEntity e) { return MODEL; }
    @Override public ResourceLocation getAnimationResource(GabrielEntity e) { return ANIMS; }

    /** controller.render.gabriel: Array.skins[(defeat == 1 || (form == 1 && stage >= 5)) ? 0 : enrage * 2] */
    @Override
    public ResourceLocation getTextureResource(GabrielEntity e) {
        boolean base = e.prop("gabriel:defeat") == 1 || (e.prop("gabriel:form") == 1 && e.prop("gabriel:stage") >= 5);
        int i = base ? 0 : e.prop("gabriel:enrage") * 2;
        return i == 0 && com.ukgabriel.UkGabrielConfig.ALT_SKIN.get() ? ALT : SKINS[i];
    }
}
