package com.ukgabriel.client;

import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.entity.GabrielProjectile;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class ProjectileModel extends GeoModel<GabrielProjectile> {
    private static final ResourceLocation ANIMS = new ResourceLocation(UkGabrielMod.MODID, "animations/gabriel_all.animation.json");

    @Override public ResourceLocation getModelResource(GabrielProjectile e) {
        return new ResourceLocation(UkGabrielMod.MODID, "geo/" + ProjectileAnimation.cfg(e.kindName()).geometry() + ".geo.json");
    }
    @Override public ResourceLocation getTextureResource(GabrielProjectile e) {
        return new ResourceLocation(UkGabrielMod.MODID, ProjectileAnimation.cfg(e.kindName()).texture() + ".png");
    }
    @Override public ResourceLocation getAnimationResource(GabrielProjectile e) { return ANIMS; }
}
