package com.ukgabriel.client;

import com.ukgabriel.entity.GabrielEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class GabrielRenderer extends GeoEntityRenderer<GabrielEntity> {
    public GabrielRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new GabrielModel());
        this.shadowRadius = 0.6f;
    }
}
