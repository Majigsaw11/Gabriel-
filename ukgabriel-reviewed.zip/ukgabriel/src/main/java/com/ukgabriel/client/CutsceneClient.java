package com.ukgabriel.client;

import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.command.ModNetwork.CutscenePacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Marker;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.MovementInputUpdateEvent;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Client side of the cutscene commands (Bedrock camera/hud/inputpermission):
 *  - free camera: a client-only Marker becomes the camera entity, eased towards the target and aimed at the facing entity;
 *  - fade: full-screen colour envelope (in / hold / out seconds);
 *  - HUD hide: all vanilla overlays except chat, title and action bar (boss subtitles) are cancelled;
 *  - input locks: movement impulses zeroed, look direction frozen.
 */
@Mod.EventBusSubscriber(modid = UkGabrielMod.MODID, value = Dist.CLIENT)
public final class CutsceneClient {
    private static Marker cam;
    private static Vec3 from = Vec3.ZERO, to = Vec3.ZERO;
    private static double easeTicks, easeT;
    private static int facingId = -1;
    private static boolean hudHidden, moveLocked, lookLocked;
    private static float lockYaw, lockPitch;
    private static long fadeStart = -1;
    private static double fIn, fHold, fOut;
    private static int fr, fg, fb;

    private CutsceneClient() {}

    public static void handle(CutscenePacket p) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        switch (p.kind()) {
            case CutscenePacket.CAMERA_FREE -> {
                if (cam == null) {
                    cam = new Marker(EntityType.MARKER, mc.level);
                    Vec3 cur = mc.gameRenderer.getMainCamera().getPosition();
                    cam.setPos(cur.x, cur.y, cur.z);
                    cam.setYRot(mc.gameRenderer.getMainCamera().getYRot());
                    cam.setXRot(mc.gameRenderer.getMainCamera().getXRot());
                    cam.xo = cur.x; cam.yo = cur.y; cam.zo = cur.z;
                    cam.yRotO = cam.getYRot(); cam.xRotO = cam.getXRot();
                    mc.setCameraEntity(cam);
                }
                from = cam.position();
                to = new Vec3(p.x(), p.y(), p.z());
                easeTicks = p.t1() * 20;
                easeT = 0;
                facingId = p.entity();
            }
            case CutscenePacket.CAMERA_CLEAR -> clearCamera();
            case CutscenePacket.FADE -> { fIn = p.t1(); fHold = p.t2(); fOut = p.t3(); fr = p.i1(); fg = p.i2(); fb = p.i3(); fadeStart = System.currentTimeMillis(); }
            case CutscenePacket.HUD -> hudHidden = p.flag();
            case CutscenePacket.INPUT -> {
                if (p.i1() == 0) moveLocked = !p.flag();
                else {
                    lookLocked = !p.flag();
                    if (lookLocked) { lockYaw = mc.player.getYRot(); lockPitch = mc.player.getXRot(); }
                }
            }
            default -> { }
        }
    }

    private static void clearCamera() {
        Minecraft mc = Minecraft.getInstance();
        if (cam != null && mc.player != null) mc.setCameraEntity(mc.player);
        cam = null;
        facingId = -1;
    }

    private static void resetAll() {
        clearCamera();
        hudHidden = moveLocked = lookLocked = false;
        fadeStart = -1;
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;
        if (lookLocked) { mc.player.setYRot(lockYaw); mc.player.setXRot(lockPitch); }
        if (cam == null) return;
        easeT++;
        double k = easeTicks <= 0 ? 1 : Math.min(1, easeT / easeTicks);
        Vec3 pos = from.lerp(to, k);
        cam.xo = cam.getX(); cam.yo = cam.getY(); cam.zo = cam.getZ();
        cam.setPos(pos.x, pos.y, pos.z);
        Entity face = facingId >= 0 ? mc.level.getEntity(facingId) : null;
        if (face != null) {
            Vec3 d = face.getEyePosition().subtract(pos);
            float yaw = (float) (Mth.atan2(-d.x, d.z) * 180 / Math.PI);
            float pitch = (float) (-Mth.atan2(d.y, Math.hypot(d.x, d.z)) * 180 / Math.PI);
            cam.yRotO = yaw + Mth.wrapDegrees(cam.getYRot() - yaw);
            cam.xRotO = cam.getXRot();
            cam.setYRot(yaw);
            cam.setXRot(pitch);
        }
    }

    @SubscribeEvent
    public static void movement(MovementInputUpdateEvent e) {
        if (!moveLocked) return;
        var in = e.getInput();
        in.forwardImpulse = 0; in.leftImpulse = 0; in.up = false; in.down = false; in.left = false; in.right = false; in.jumping = false; in.shiftKeyDown = false;
    }

    @SubscribeEvent
    public static void overlay(RenderGuiOverlayEvent.Pre e) {
        if (!hudHidden) return;
        var id = e.getOverlay().id();
        if (id.equals(VanillaGuiOverlay.RECORD_OVERLAY.id()) || id.equals(VanillaGuiOverlay.TITLE_TEXT.id()) || id.equals(VanillaGuiOverlay.CHAT_PANEL.id())
                || id.equals(VanillaGuiOverlay.SUBTITLES.id()) || id.getNamespace().equals(UkGabrielMod.MODID)) return;
        e.setCanceled(true);
    }

    @SubscribeEvent
    public static void logout(ClientPlayerNetworkEvent.LoggingOut e) { resetAll(); }

    /** Registered as a GUI overlay above everything (see ClientSetup). */
    public static void renderFade(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        if (fadeStart < 0) return;
        double t = (System.currentTimeMillis() - fadeStart) / 1000.0;
        double total = fIn + fHold + fOut;
        if (t >= total) { fadeStart = -1; return; }
        double a = t < fIn ? t / Math.max(fIn, 1e-6) : t < fIn + fHold ? 1 : 1 - (t - fIn - fHold) / Math.max(fOut, 1e-6);
        int alpha = (int) Math.round(Math.max(0, Math.min(1, a)) * 255);
        g.fill(0, 0, w, h, (alpha << 24) | (fr << 16) | (fg << 8) | fb);
    }
}
