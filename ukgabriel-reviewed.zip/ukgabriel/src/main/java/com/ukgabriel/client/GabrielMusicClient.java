package com.ukgabriel.client;

import com.ukgabriel.UkGabrielMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Client side of the boss music: loops gabriel.music.p1..p3 as MUSIC until told to stop. */
@Mod.EventBusSubscriber(modid = UkGabrielMod.MODID, value = Dist.CLIENT)
public final class GabrielMusicClient {
    private static SoundInstance current;
    private static int track;

    private GabrielMusicClient() {}

    public static void set(int t) {
        if (t == track) return;
        stop();
        track = t;
        if (t < 1 || t > 3) return;
        Minecraft mc = Minecraft.getInstance();
        mc.getMusicManager().stopPlaying();
        current = new SimpleSoundInstance(new ResourceLocation(UkGabrielMod.MODID, "gabriel.music.p" + t), SoundSource.MUSIC, 1f, 1f,
                SoundInstance.createUnseededRandom(), true, 0, SoundInstance.Attenuation.NONE, 0, 0, 0, true);
        mc.getSoundManager().play(current);
    }

    private static void stop() {
        if (current != null) Minecraft.getInstance().getSoundManager().stop(current);
        current = null;
        track = 0;
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) { stop(); }
}
