package com.ukgabriel.client;

import com.google.gson.Gson;
import com.mojang.logging.LogUtils;
import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.bedrock.RpAnimator;
import com.ukgabriel.entity.GabrielEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import org.slf4j.Logger;
import software.bernie.geckolib.core.animation.Animation;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.core.animation.AnimationState;
import software.bernie.geckolib.core.animation.RawAnimation;
import software.bernie.geckolib.core.object.PlayState;

import java.io.IOException;
import java.io.Reader;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

/** Client glue: drives GeckoLib from the original RP controllers (via RpAnimator) and plays animation particle keyframes. */
public final class GabrielAnimation {
    private static final Logger LOGGER = LogUtils.getLogger();
    public static final int SLOTS = 3; // controller states play at most 2 animations at once, + enrage_ring

    private static Object controllersRoot, clientEntityRoot;

    private static final class Anim {
        final RpAnimator animator;
        final String[] current = new String[SLOTS];
        int lastTick = Integer.MIN_VALUE;
        Anim(RpAnimator a) { animator = a; }
    }
    private static final Map<GabrielEntity, Anim> STATE = new WeakHashMap<>();

    private GabrielAnimation() {}

    private static Object read(String path) throws IOException {
        try (Reader r = Minecraft.getInstance().getResourceManager().getResource(new ResourceLocation(UkGabrielMod.MODID, path))
                .orElseThrow(() -> new IOException("missing " + path)).openAsReader()) {
            return new Gson().fromJson(r, Object.class);
        }
    }

    private static Anim state(GabrielEntity e) {
        Anim a = STATE.get(e);
        if (a == null) {
            try {
                if (controllersRoot == null) {
                    controllersRoot = read("animation_controllers/gabriel.animation_controllers.json");
                    clientEntityRoot = read("client_entity/gabriel.entity.json");
                }
                a = new Anim(new RpAnimator(controllersRoot, clientEntityRoot));
            } catch (IOException ex) { throw new IllegalStateException(ex); }
            STATE.put(e, a);
        }
        if (a.lastTick != e.tickCount) { // controllers run at game-tick rate (Bedrock: per tick as well)
            a.lastTick = e.tickCount;
            a.animator.tick(e::prop, 0.05);
        }
        return a;
    }

    public static PlayState play(GabrielEntity e, int slot, AnimationState<GabrielEntity> st) {
        Anim a = state(e);
        List<String> act = a.animator.active();
        AnimationController<GabrielEntity> c = st.getController();
        if (slot >= act.size()) { a.current[slot] = null; return PlayState.STOP; }
        String id = act.get(slot);
        if (!id.equals(a.current[slot])) {
            a.current[slot] = id;
            c.transitionLength((int) Math.round(a.animator.blendSeconds() * 20));
            c.setAnimation(RawAnimation.begin().then(id, Animation.LoopType.DEFAULT));
        }
        return PlayState.CONTINUE;
    }

    /** Animation particle_effects keyframe (e.g. "ring" -> gabriel:enrage_ring) -> Bedrock particle at the boss. */
    public static void particle(GabrielEntity e, String effectAlias) {
        String id = state(e).animator.particleFor(effectAlias);
        if (id == null) { LOGGER.warn("Gabriel: animation particle alias '{}' has no mapping", effectAlias); return; }
        BedrockParticles.spawn(id, e.getX(), e.getY(), e.getZ());
    }
}
