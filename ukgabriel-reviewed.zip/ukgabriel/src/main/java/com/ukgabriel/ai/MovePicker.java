package com.ukgabriel.ai;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Port of ai.js pickMove(): weighted move choice by distance band, taunt cadence, apostate combo bias. */
public final class MovePicker {
    private MovePicker() {}

    public interface Props { int get(String name); void set(String name, int value); }

    public static final class State { public int sinceTaunt; public int lastMove; }

    // move -> weight per distance band (<=6, <=12, farther), exactly as in ai.js
    private static final double[][] JOH = {{2, 4, 4}, {5, 1, 0}, {4, 4, 1}, {1, 3, 5}};   // moves 1..4
    private static final double[][] AOH = {{5, 3, 0.5}, {4, 2, 0}, {4, 3, 0.5}, {1, 4, 6}};

    public static int pick(Props p, State s, int stage, double dist, Random rng) {
        s.sinceTaunt++;
        int limit = p.get("gabriel:tier") <= 1 ? 2 : 3;
        if (s.sinceTaunt > limit) { s.sinceTaunt = 0; s.lastMove = 20; return 20; }
        boolean aoh = stage >= 4;
        if (aoh && s.lastMove == 1 && rng.nextDouble() < 0.55) { s.lastMove = 4; return 4; }
        int band = dist <= 6 ? 0 : dist <= 12 ? 1 : 2;
        double[][] table = aoh ? AOH : JOH;
        boolean axeUsed = !aoh && p.get("gabriel:throw") == 1;
        List<double[]> options = new ArrayList<>();
        for (int m = 1; m <= 4; m++) {
            double w = table[m - 1][band];
            if (w > 0 && !(m == 4 && axeUsed)) options.add(new double[]{m, w});
        }
        List<double[]> fresh = new ArrayList<>();
        for (double[] o : options) if ((int) o[0] != s.lastMove) fresh.add(o);
        if (!fresh.isEmpty()) options = fresh;
        if (options.isEmpty()) return 0;
        double total = 0;
        for (double[] o : options) total += o[1];
        double roll = rng.nextDouble() * total;
        int chosen = (int) options.get(options.size() - 1)[0];
        for (double[] o : options) { roll -= o[1]; if (roll <= 0) { chosen = (int) o[0]; break; } }
        s.lastMove = chosen;
        if (!aoh && chosen == 4) p.set("gabriel:throw", 1);
        return chosen;
    }
}
