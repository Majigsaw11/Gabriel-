package com.ukgabriel.ai;

import java.util.Random;

/** Port of ai.js chase()/stepTo()/closeIn() maths. World access is injected via {@link Clear}; pure and testable. */
public final class Movement {
    private Movement() {}

    public static final double CATCH_UP = 1.1, CLOSE_DIST = 2.0, CLOSE_SPEED = 1.6, ORBIT_MIN = 6, ORBIT_MAX = 9.5, ORBIT_FAR = 26,
            HOVER_ABOVE = 1.8, VERT_STEP = 0.22;
    public static double speedFor(int stage) {
        return switch (stage) { case 1 -> 0.46; case 2 -> 0.54; case 4 -> 0.62; case 5 -> 0.7; default -> 0.5; };
    }

    public interface Clear { boolean at(double x, double y, double z); }

    public static final class State {
        public int dir;
        public int flipAt;
        public double radius = 7.5;
        public int radiusAt;
        public double hoverY = HOVER_ABOVE;
        public State(Random rng) { dir = rng.nextDouble() < 0.5 ? 1 : -1; }
    }

    public record Goal(double x, double y, double z, double speed) {}

    /** ai.js chase(): where to go this tick and how fast. May flip orbit direction when the path is blocked. */
    public static Goal chase(State s, double[] from, double[] tl, int stage, double mult, int tick, Random rng, Clear clear) {
        double dx = tl[0] - from[0], dz = tl[2] - from[2];
        double flat = Math.hypot(dx, dz);
        double speed = flat > 30 ? CATCH_UP : speedFor(stage) * mult;
        double bob = Math.sin(tick * 0.06) * 0.5;
        double wantY = tl[1] + s.hoverY + bob;
        double gy = from[1] + Math.max(-VERT_STEP, Math.min(VERT_STEP, wantY - from[1]));
        if (flat > ORBIT_FAR) {
            double r = (flat - s.radius) / flat;
            return new Goal(from[0] + dx * r, gy, from[2] + dz * r, speed);
        }
        if (tick >= s.flipAt) {
            if (rng.nextDouble() < 0.5) s.dir = -s.dir;
            s.flipAt = tick + 40 + (int) Math.floor(rng.nextDouble() * 60);
        }
        if (tick >= s.radiusAt) {
            boolean aoh = stage >= 4;
            s.radius = aoh ? 3 + rng.nextDouble() * 6 : ORBIT_MIN + rng.nextDouble() * (ORBIT_MAX - ORBIT_MIN);
            s.hoverY = aoh ? 2 + rng.nextDouble() * 6.5 : HOVER_ABOVE + rng.nextDouble() * 1.2;
            s.radiusAt = tick + 50 + (int) Math.floor(rng.nextDouble() * 70);
        }
        double angle = Math.atan2(from[2] - tl[2], from[0] - tl[0]);
        double radius = Math.max(flat, 1);
        double nextRadius = radius + Math.max(-0.35, Math.min(0.35, (s.radius - radius) * 0.15));
        double nextAngle = angle + (s.dir * speed * 0.8) / Math.max(radius, 3);
        double gx = tl[0] + Math.cos(nextAngle) * nextRadius, gz = tl[2] + Math.sin(nextAngle) * nextRadius;
        if (!clear.at(gx, gy, gz)) { s.dir = -s.dir; s.flipAt = tick + 40; }
        return new Goal(gx, gy, gz, speed);
    }

    /** ai.js stepTo(): move up to `speed` towards goal, sliding up when blocked. Returns null when stuck. */
    public static double[] stepTo(double[] from, double gx, double gy, double gz, double speed, Clear clear) {
        double dx = gx - from[0], dy = gy - from[1], dz = gz - from[2];
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 0.05) return null;
        double k = Math.min(1, speed / dist);
        double[] dest = {from[0] + dx * k, from[1] + dy * k, from[2] + dz * k};
        if (!clear.at(dest[0], dest[1], dest[2])) {
            dest = new double[]{dest[0], from[1] + VERT_STEP, dest[2]};
            if (!clear.at(dest[0], dest[1], dest[2])) dest = new double[]{from[0], from[1] + VERT_STEP, from[2]};
            if (!clear.at(dest[0], dest[1], dest[2])) return null;
        }
        return dest;
    }

    /** ai.js closeIn(): flat step of up to CLOSE_SPEED towards the target until CLOSE_DIST away; null if already close. */
    public static double[] closeInGoal(double[] from, double[] tl) {
        double dx = tl[0] - from[0], dz = tl[2] - from[2];
        double flat = Math.hypot(dx, dz);
        if (flat <= CLOSE_DIST) return null;
        double step = Math.min(CLOSE_SPEED, flat - CLOSE_DIST);
        return new double[]{from[0] + dx / flat * step, from[1], from[2] + dz / flat * step, step};
    }

    /** ai.js yawOf(): Minecraft/Bedrock yaw for a horizontal direction. */
    public static float yawOf(double dx, double dz) { return (float) (Math.atan2(-dx, dz) * 180 / Math.PI); }
}
