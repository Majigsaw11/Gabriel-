package com.ukgabriel.ai;

import java.util.Map;

/** Port of the pure maths in scripts/gabriel/projectiles.js (flight kinds, steering, aim lead, sub-stepping, body hit test). */
public final class FlightMath {
    private FlightMath() {}

    public static final double HIT_RADIUS = 1.7, MAX_STEP = 0.75, REFLECT_BOOST = 1.3, REFLECT_TURN = 14, MIN_TRACK_DIST = 4,
            MAX_TRACK_ANGLE = 100, BOSS_RADIUS = 2.6, BOSS_CENTER = 1.7;

    public record Kind(double[] speed, double turn, int life, String hit, String end, int parry, double nonPlayerTurn) {}

    public static final Map<String, Kind> KINDS = Map.of(
        "sword_beam", new Kind(new double[]{3.752, 4.2, 5.4, 6.0}, 0, 160, "gabriel/impact_sword_beam", "gabriel/end_sword_beam", 40, 4),
        "sword_throw", new Kind(new double[]{2.124, 2.38, 3.06, 3.4}, 1.6, 600, "gabriel/impact_sword_throw", "gabriel/end_sword_throw", 80, 6),
        "light_axe", new Kind(new double[]{2.248, 2.52, 3.24, 3.6}, 1.8, 160, "gabriel/impact_light_axe", "gabriel/end_light_axe", 40, 5),
        "light_greatsword", new Kind(new double[]{2.376, 2.66, 3.42, 3.8}, 0, 160, "gabriel/impact_light_greatsword", "gabriel/end_light_greatsword", 40, 4));

    public static double[] sub(double[] a, double[] b) { return new double[]{a[0] - b[0], a[1] - b[1], a[2] - b[2]}; }
    public static double len(double[] a) { return Math.sqrt(a[0] * a[0] + a[1] * a[1] + a[2] * a[2]); }
    public static double dot(double[] a, double[] b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }

    /** JS norm(): a zero vector stays zero (division by 1). */
    public static double[] norm(double[] a) {
        double l = len(a);
        if (l == 0) l = 1;
        return new double[]{a[0] / l, a[1] / l, a[2] / l};
    }

    public static double angleBetween(double[] a, double[] b) {
        return Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, dot(a, b)))));
    }

    /** steer(): turn `dir` towards `want` by at most maxDeg degrees. */
    public static double[] steer(double[] dir, double[] want, double maxDeg) {
        double ang = angleBetween(dir, want);
        if (ang <= maxDeg) return want;
        double t = maxDeg / ang;
        return norm(new double[]{dir[0] * (1 - t) + want[0] * t, dir[1] * (1 - t) + want[1] * t, dir[2] * (1 - t) + want[2] * t});
    }

    /** Turn rate (deg/tick) for the current target: players use the kind's own rate, other mobs get at least the non-player rate. */
    public static double turnRate(Kind k, boolean targetIsPlayer) {
        if (k.turn() > 0) return targetIsPlayer ? k.turn() : Math.max(k.turn(), k.nonPlayerTurn());
        return targetIsPlayer ? 0 : k.nonPlayerTurn();
    }

    /** First-tick aim: lead the target by its velocity over the estimated flight time (max 40 ticks). */
    public static double[] leadAim(double[] pos, double[] target, double centerY, double[] vel, double speed) {
        double dist0 = len(sub(new double[]{target[0], centerY, target[2]}, pos));
        double ticks = Math.min(40, dist0 / Math.max(speed, 0.5));
        double[] lead = {target[0] + vel[0] * ticks, centerY + vel[1] * ticks * 0.5, target[2] + vel[2] * ticks};
        return norm(sub(lead, pos));
    }

    public static int steps(double speed) { return Math.max(1, (int) Math.ceil(speed / MAX_STEP)); }

    /** strikesVictim() body test for a point against a victim's feet position and height. */
    public static boolean pointHitsBody(double[] p, double vx, double feetY, double vz, double height) {
        double horizontal = Math.hypot(p[0] - vx, p[2] - vz);
        double below = feetY - 0.4 - p[1];
        double above = p[1] - (feetY + height + 0.4);
        return horizontal <= HIT_RADIUS + 0.3 && below <= 0 && above <= 0;
    }

    public static double[] bodyOf(double feetY, double headY) {
        double height = Math.max(headY - feetY, 0.6);
        return new double[]{feetY, height, feetY + height * 0.55};
    }
}
