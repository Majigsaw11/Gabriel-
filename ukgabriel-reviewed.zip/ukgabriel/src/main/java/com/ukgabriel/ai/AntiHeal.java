package com.ukgabriel.ai;

import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Port of scripts/gabriel/anti_heal.js. NO_HEAL_TAG "uk:no_heal" blocks healing (see GabrielDamage.onHeal). */
public final class AntiHeal {
    public static final String NO_HEAL_TAG = "uk:no_heal";
    private static final String STAMP = "uk_no_heal_stamp";
    private static final int NO_HEAL_TICKS = 100;
    private static final Map<UUID, Long> WINDOWS = new HashMap<>();

    private AntiHeal() {}

    public static void openHealWindow(UUID boss, int ticks) { WINDOWS.put(boss, Scheduler.now() + ticks); }
    public static boolean windowOpen(UUID boss) { return WINDOWS.getOrDefault(boss, 0L) > Scheduler.now(); }

    public static void apply(LivingEntity target) {
        target.removeEffect(MobEffects.REGENERATION);
        target.removeEffect(MobEffects.HEALTH_BOOST);
        target.removeEffect(MobEffects.ABSORPTION);
        target.addTag(NO_HEAL_TAG);
        long stamp = Scheduler.now();
        target.getPersistentData().putLong(STAMP, stamp);
        Scheduler.runLater(NO_HEAL_TICKS, () -> {
            if (target.isAlive() && target.getPersistentData().getLong(STAMP) == stamp) target.removeTag(NO_HEAL_TAG);
        });
    }
}
