package com.ukgabriel.ai;

import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import java.util.ArrayList;
import java.util.List;

/** Minimal system.runTimeout equivalent (server ticks). */
public final class Scheduler {
    private record Task(long at, Runnable run) {}
    private static final List<Task> TASKS = new ArrayList<>();
    private static long now;

    public static synchronized void runLater(int ticks, Runnable r) { TASKS.add(new Task(now + ticks, r)); }
    public static long now() { return now; }

    @SubscribeEvent
    public void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        List<Runnable> due = new ArrayList<>();
        synchronized (Scheduler.class) {
            now++;
            TASKS.removeIf(t -> { if (t.at <= now) { due.add(t.run); return true; } return false; });
        }
        for (Runnable r : due) r.run();
    }
}
