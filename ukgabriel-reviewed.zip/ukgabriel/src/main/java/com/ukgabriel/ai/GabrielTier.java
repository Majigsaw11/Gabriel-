package com.ukgabriel.ai;

/**
 * Port of scripts/gabriel/difficulty.js CONFIG (+ the TIERS order from scripts/difficulty.js). Pure data.
 * pace: AI/cooldown speed. proj: projectile speed. mobPct/mobCap: damage vs non-player mobs as % of their max health.
 * armorCap: max fraction of Gabriel's max health one hit may take. antiHeal: his hits strip healing. varied: damage cause changes per hit.
 */
public record GabrielTier(int index, String name, double pace, double proj, double dmg, double mobPct, double mobCap,
                          double armorCap, boolean antiHeal, boolean varied, int hp) {
    public static final String[] NAMES = {"Harmless", "Lenient", "Standard", "Violent", "Brutal", "Mob Battle"};

    private static final double MINOS_PCT = 0.07, MINOS_CAP = 400, MINOS_PACE = 1.75, MB_BONUS = 1.5, MB_PROJ_CLAMP = 2.0;
    private static final int MB_HP = 15000;

    public static GabrielTier of(int index) {
        int i = Math.max(0, Math.min(NAMES.length - 1, index));
        return switch (i) {
            case 0 -> new GabrielTier(0, NAMES[0], 0.8, 0.8, 1, MINOS_PCT, MINOS_CAP, 0.05, false, false, 0);
            case 1 -> new GabrielTier(1, NAMES[1], 0.9, 0.9, 1, MINOS_PCT, MINOS_CAP, 0.04, false, false, 0);
            case 2 -> new GabrielTier(2, NAMES[2], 1.0, 1.0, 1, MINOS_PCT, MINOS_CAP, 0.03, false, false, 0);
            case 3 -> new GabrielTier(3, NAMES[3], 1.25, 1.25, 1, MINOS_PCT, MINOS_CAP, 0.025, false, false, 0);
            case 4 -> new GabrielTier(4, NAMES[4], 1.5, 1.5, 1, MINOS_PCT, MINOS_CAP, 0.02, false, false, 0);
            default -> {
                double pace = Math.max(MINOS_PACE, MINOS_PACE) * MB_BONUS;
                yield new GabrielTier(5, NAMES[5], pace, Math.min(pace, MB_PROJ_CLAMP), 1,
                        (MINOS_PCT + MINOS_PCT) * MB_BONUS, (MINOS_CAP + MINOS_CAP) * MB_BONUS, 0.015, true, true, MB_HP);
            }
        };
    }

    /** scripts/difficulty.js worldDefaultIndex(): used when no tier has been chosen explicitly. */
    public static int defaultIndexFor(String worldDifficulty) {
        String d = worldDifficulty.toLowerCase();
        if (d.contains("peaceful")) return 0;
        if (d.contains("easy")) return 1;
        if (d.contains("hard")) return 3;
        return 2;
    }

    public static int indexOf(String name) {
        for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equalsIgnoreCase(name.replace('_', ' '))) return i;
        return -1;
    }

    /** Copy with the config multipliers applied (pace and projectile speed, hit damage, armor cap). */
    public GabrielTier scaled(double paceMul, double projMul, double dmgMul, double armorMul) {
        return new GabrielTier(index, name, pace * paceMul, proj * projMul, dmg * dmgMul, mobPct, mobCap, armorCap * armorMul, antiHeal, varied, hp);
    }

    /** damage.js scaled(): wiki number x tier, raised to mobPct of max health (capped) against non-players. */
    public int scaledDamage(boolean victimIsPlayer, double victimMaxHealth, double base) {
        double d = base * dmg;
        if (!victimIsPlayer && mobPct > 0) d = Math.min(mobCap, Math.max(d, jsRound(victimMaxHealth * mobPct)));
        return (int) Math.max(1, jsRound(d));
    }

    /** JavaScript Math.round (half rounds up). */
    public static double jsRound(double v) { return Math.floor(v + 0.5); }
}
