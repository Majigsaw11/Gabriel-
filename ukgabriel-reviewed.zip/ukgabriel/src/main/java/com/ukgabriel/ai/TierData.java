package com.ukgabriel.ai;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

/** Replaces the add-on's global "minos:difficulty" dynamic property: explicit tier override, else world difficulty. */
public final class TierData extends SavedData {
    private static final String NAME = "ukgabriel_tier";
    private int override = -1;

    public static TierData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(TierData::load, TierData::new, NAME);
    }

    private static TierData load(CompoundTag t) { TierData d = new TierData(); d.override = t.getInt("override"); return d; }
    @Override public CompoundTag save(CompoundTag t) { t.putInt("override", override); return t; }

    public static GabrielTier current(MinecraftServer server) {
        TierData d = get(server);
        int i = d.override;
        if (i < 0) {
            String cfg = com.ukgabriel.UkGabrielConfig.TIER.get();
            i = cfg.equals("auto") ? -1 : GabrielTier.indexOf(cfg);
        }
        if (i < 0) i = GabrielTier.defaultIndexFor(server.getWorldData().getDifficulty().name());
        return GabrielTier.of(i).scaled(com.ukgabriel.UkGabrielConfig.PACE.get(), com.ukgabriel.UkGabrielConfig.PROJECTILE_SPEED.get(), com.ukgabriel.UkGabrielConfig.DAMAGE.get(), com.ukgabriel.UkGabrielConfig.ARMOR_CAP.get());
    }

    public static void set(MinecraftServer server, int index) { TierData d = get(server); d.override = index; d.setDirty(); }
    public static void clear(MinecraftServer server) { set(server, -1); }
}
