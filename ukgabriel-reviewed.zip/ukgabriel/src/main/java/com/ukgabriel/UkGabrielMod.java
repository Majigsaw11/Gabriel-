package com.ukgabriel;

import com.ukgabriel.registry.ModEntities;
import com.ukgabriel.registry.ModItems;
import com.ukgabriel.registry.ModSounds;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(UkGabrielMod.MODID)
public final class UkGabrielMod {
    public static final String MODID = "ukgabriel";

    public UkGabrielMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        net.minecraftforge.fml.ModLoadingContext.get().registerConfig(net.minecraftforge.fml.config.ModConfig.Type.COMMON, UkGabrielConfig.SPEC);
        ModEntities.ENTITIES.register(bus);
        ModSounds.SOUNDS.register(bus);
        ModItems.ITEMS.register(bus);
        bus.addListener(ModEntities::onAttributes);
        bus.addListener(ModItems::onCreativeTab);
        bus.addListener((net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent e) -> e.enqueueWork(com.ukgabriel.command.ModNetwork::init));
        MinecraftForge.EVENT_BUS.register(new com.ukgabriel.command.ModCommands());
        MinecraftForge.EVENT_BUS.register(new com.ukgabriel.entity.Subtitles());
        MinecraftForge.EVENT_BUS.register(new com.ukgabriel.ai.Scheduler());
        MinecraftForge.EVENT_BUS.register(new com.ukgabriel.entity.GabrielMusic());
        MinecraftForge.EVENT_BUS.register(new com.ukgabriel.entity.BossCamera());
        MinecraftForge.EVENT_BUS.register(new com.ukgabriel.entity.CutsceneCleanup());
    }
}
