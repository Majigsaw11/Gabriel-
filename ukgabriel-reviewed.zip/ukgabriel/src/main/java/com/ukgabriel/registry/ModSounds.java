package com.ukgabriel.registry;

import com.ukgabriel.UkGabrielMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.LinkedHashMap;
import java.util.Map;

/** One SoundEvent per entry of sounds.json (all 55 Gabriel sound events). */
public final class ModSounds {
    private ModSounds() {}
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, UkGabrielMod.MODID);
    public static final Map<String, RegistryObject<SoundEvent>> BY_NAME = new LinkedHashMap<>();

    static {
        for (String n : SoundNames.NAMES)
            BY_NAME.put(n, SOUNDS.register(n, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(UkGabrielMod.MODID, n))));
    }
}
