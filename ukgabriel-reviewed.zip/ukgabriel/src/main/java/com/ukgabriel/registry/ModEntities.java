package com.ukgabriel.registry;

import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.entity.GabrielEntity;
import com.ukgabriel.entity.GabrielProjectile;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    private ModEntities() {}
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, UkGabrielMod.MODID);

    // collision_box 1.2 x 3.4, fire immune (damage_sensor), tracks like a boss
    public static final RegistryObject<EntityType<GabrielEntity>> GABRIEL = ENTITIES.register("gabriel",
            () -> EntityType.Builder.of(GabrielEntity::new, MobCategory.MONSTER)
                    .sized(1.2f, 3.4f).fireImmune().clientTrackingRange(16).updateInterval(1).build("gabriel"));

    private static RegistryObject<EntityType<GabrielProjectile>> projectile(String name, float w, float h) {
        return ENTITIES.register(name, () -> EntityType.Builder.<GabrielProjectile>of(GabrielProjectile::new, MobCategory.MISC)
                .sized(w, h).fireImmune().clientTrackingRange(12).updateInterval(1).setShouldReceiveVelocityUpdates(false).build(name));
    }

    // collision boxes from the BP entities
    public static final RegistryObject<EntityType<GabrielProjectile>> SWORD_BEAM = projectile("sword_beam", 1.0f, 1.0f);
    public static final RegistryObject<EntityType<GabrielProjectile>> SWORD_THROW = projectile("sword_throw", 1.0f, 1.0f);
    public static final RegistryObject<EntityType<GabrielProjectile>> LIGHT_AXE = projectile("light_axe", 1.0f, 1.0f);
    public static final RegistryObject<EntityType<GabrielProjectile>> LIGHT_GREATSWORD = projectile("light_greatsword", 1.0f, 1.0f);
    public static final RegistryObject<EntityType<GabrielProjectile>> SPIRAL_SWORD = projectile("spiral_sword", 0.2f, 0.2f);
    public static final RegistryObject<EntityType<GabrielProjectile>> SPIRAL_SWORDS = projectile("spiral_swords", 0.1f, 0.1f);
    public static final RegistryObject<EntityType<GabrielProjectile>> ORBIT_SENSOR = projectile("orbit_sensor", 0.2f, 0.2f);

    public static final java.util.List<RegistryObject<EntityType<GabrielProjectile>>> PROJECTILES = java.util.List.of(
            SWORD_BEAM, SWORD_THROW, LIGHT_AXE, LIGHT_GREATSWORD, SPIRAL_SWORD, SPIRAL_SWORDS, ORBIT_SENSOR);

    public static void onAttributes(EntityAttributeCreationEvent e) {
        e.put(GABRIEL.get(), GabrielEntity.createAttributes().build());
    }
}
