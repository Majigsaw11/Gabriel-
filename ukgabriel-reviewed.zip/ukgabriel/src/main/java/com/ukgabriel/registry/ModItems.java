package com.ukgabriel.registry;

import com.ukgabriel.UkGabrielMod;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    private ModItems() {}
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, UkGabrielMod.MODID);

    // spawn_egg colours from the client entity: base #c0392b, overlay #fecd4a
    public static final RegistryObject<Item> GABRIEL_SPAWN_EGG = ITEMS.register("gabriel_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.GABRIEL, 0xc0392b, 0xfecd4a, new Item.Properties()));

    /** Camera mode item (scripts/camera.js equivalent): right-click to follow Gabriel with a free camera, again to exit. */
    public static final RegistryObject<Item> GABRIEL_CAMERA = ITEMS.register("gabriel_camera", () -> new Item(new Item.Properties().stacksTo(1)) {
        @Override
        public net.minecraft.world.InteractionResultHolder<net.minecraft.world.item.ItemStack> use(net.minecraft.world.level.Level level, net.minecraft.world.entity.player.Player player, net.minecraft.world.InteractionHand hand) {
            if (!level.isClientSide && player instanceof net.minecraft.server.level.ServerPlayer sp) com.ukgabriel.entity.BossCamera.toggle(sp);
            return net.minecraft.world.InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
        }
    });

    public static void onCreativeTab(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) { e.accept(GABRIEL_SPAWN_EGG); e.accept(GABRIEL_CAMERA); }
    }
}
