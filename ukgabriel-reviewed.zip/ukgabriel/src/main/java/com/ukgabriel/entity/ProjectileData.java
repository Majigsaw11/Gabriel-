package com.ukgabriel.entity;

import com.google.gson.Gson;
import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.bedrock.BedrockEvents;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;

import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;

/** Server-side data of one projectile entity type (translated BP entity: events, groups, timer, parry sensor). */
public final class ProjectileData {
    private static final Map<String, ProjectileData> CACHE = new HashMap<>();

    public final BedrockEvents events;
    public final Map<String, Object> groups;
    public final Map<String, String> aliases = new HashMap<>();
    public final java.util.List<String> animate = new java.util.ArrayList<>();
    public final double timerSeconds;
    public final String timerEvent;
    public final boolean parrySensor;

    @SuppressWarnings("unchecked")
    private ProjectileData(Map<String, Object> o) {
        events = new BedrockEvents((Map<String, Object>) o.get("events"));
        groups = (Map<String, Object>) o.get("component_groups");
        for (Map.Entry<String, Object> e : ((Map<String, Object>) o.get("animations")).entrySet()) aliases.put(e.getKey(), (String) e.getValue());
        for (Object a : (java.util.List<Object>) o.get("animate")) animate.add((String) a);
        Map<String, Object> t = (Map<String, Object>) o.get("timer");
        timerSeconds = t == null ? 0 : ((Number) t.get("seconds")).doubleValue();
        timerEvent = t == null ? null : (String) t.get("event");
        parrySensor = Boolean.TRUE.equals(o.get("parry_sensor"));
    }

    @SuppressWarnings("unchecked")
    public static synchronized ProjectileData get(MinecraftServer server, String name) {
        return CACHE.computeIfAbsent(name, n -> {
            try (Reader r = server.getResourceManager().getResource(new ResourceLocation(UkGabrielMod.MODID, "ai/entities/" + n + ".json"))
                    .orElseThrow(() -> new IOException("missing ai/entities/" + n)).openAsReader()) {
                return new ProjectileData((Map<String, Object>) new Gson().fromJson(r, Object.class));
            } catch (IOException e) { throw new IllegalStateException(e); }
        });
    }

    public static synchronized void invalidate() { CACHE.clear(); }
}
