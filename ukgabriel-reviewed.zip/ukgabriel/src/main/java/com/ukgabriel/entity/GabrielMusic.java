package com.ukgabriel.entity;

import com.ukgabriel.command.ModNetwork;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.*;

/**
 * Port of scripts/gabriel/main.js music loop: every 20 ticks each boss tells players within 80 blocks which track
 * (gabriel:music 1..3 -> gabriel.music.p1..p3) to loop, and stops it for players who leave range or when the track changes.
 * (The original fades 1 s; here the client starts/stops immediately.)
 */
public final class GabrielMusic {
    private static final double RANGE = 80;
    private static final class S { int track; final Set<UUID> heard = new HashSet<>(); }
    private static final Map<UUID, S> STATE = new HashMap<>();

    private static void send(ServerPlayer p, int track) {
        ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), new ModNetwork.MusicPacket(track));
    }

    private static void stopAll(GabrielEntity boss, S s) {
        if (boss.level().getServer() != null)
            for (UUID id : s.heard) { ServerPlayer p = boss.level().getServer().getPlayerList().getPlayer(id); if (p != null) send(p, 0); }
        s.heard.clear();
    }

    @SubscribeEvent
    public void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.getServer().getTickCount() % 20 != 0) return;
        Set<UUID> seen = new HashSet<>();
        for (GabrielEntity g : GabrielEntity.BOSSES) {
            if (g.level().isClientSide || !g.isAlive()) continue;
            seen.add(g.getUUID());
            S s = STATE.computeIfAbsent(g.getUUID(), k -> new S());
            int m = g.prop("gabriel:music");
            if (m != s.track) { stopAll(g, s); s.track = m; }
            if (m == 0) continue;
            Set<UUID> near = new HashSet<>();
            for (ServerPlayer p : ((net.minecraft.server.level.ServerLevel) g.level()).players()) {
                if (p.distanceToSqr(g) > RANGE * RANGE) continue;
                near.add(p.getUUID());
                if (s.heard.add(p.getUUID())) send(p, m);
            }
            for (UUID id : new ArrayList<>(s.heard)) {
                if (near.contains(id)) continue;
                ServerPlayer p = e.getServer().getPlayerList().getPlayer(id);
                if (p != null) send(p, 0);
                s.heard.remove(id);
            }
        }
        for (Iterator<Map.Entry<UUID, S>> it = STATE.entrySet().iterator(); it.hasNext(); ) {
            Map.Entry<UUID, S> en = it.next();
            if (seen.contains(en.getKey())) continue;
            for (UUID id : en.getValue().heard) { ServerPlayer p = e.getServer().getPlayerList().getPlayer(id); if (p != null) send(p, 0); }
            it.remove();
        }
    }
}
