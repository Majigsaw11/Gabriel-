package com.ukgabriel.entity;

import com.google.gson.Gson;
import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.bedrock.BedrockController;
import com.ukgabriel.bedrock.BedrockEvents;
import com.ukgabriel.bedrock.Timeline;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.packs.resources.ResourceManager;

import java.io.IOException;
import java.io.Reader;
import java.util.*;

/** Server-side Gabriel data (translated by tools/translate_commands.py): events, groups, controllers, timelines. */
public final class AiData {
    private static AiData instance;

    public final Object controllersRoot;
    public final Map<String, Timeline> timelines;
    public final Map<String, String> aliases = new HashMap<>();
    public final BedrockEvents events;
    public final Map<String, Object> groups;
    public final Map<String, Integer> defaults = new LinkedHashMap<>();
    public final Map<String, int[]> ranges = new HashMap<>();
    public static final List<String> ANIMATE = List.of("brain", "phase");

    @SuppressWarnings("unchecked")
    private AiData(ResourceManager rm) throws IOException {
        Map<String, Object> ent = (Map<String, Object>) read(rm, "ai/entity.json");
        controllersRoot = read(rm, "ai/controllers.json");
        timelines = Timeline.parse(read(rm, "ai/timelines.json"));
        events = new BedrockEvents((Map<String, Object>) ent.get("events"));
        groups = (Map<String, Object>) ent.get("component_groups");
        for (Map.Entry<String, Object> e : ((Map<String, Object>) ent.get("animations")).entrySet()) aliases.put(e.getKey(), (String) e.getValue());
        for (Map.Entry<String, Object> e : ((Map<String, Object>) ent.get("properties")).entrySet()) {
            Map<String, Object> p = (Map<String, Object>) e.getValue();
            defaults.put(e.getKey(), ((Number) p.get("default")).intValue());
            List<Object> r = (List<Object>) p.get("range");
            ranges.put(e.getKey(), new int[]{((Number) r.get(0)).intValue(), ((Number) r.get(1)).intValue()});
        }
    }

    private static Object read(ResourceManager rm, String path) throws IOException {
        try (Reader r = rm.getResource(new ResourceLocation(UkGabrielMod.MODID, path)).orElseThrow(() -> new IOException("missing " + path)).openAsReader()) {
            return new Gson().fromJson(r, Object.class);
        }
    }

    public static synchronized AiData get(MinecraftServer server) {
        if (instance == null) {
            try { instance = new AiData(server.getResourceManager()); }
            catch (IOException e) { throw new IllegalStateException("Cannot load Gabriel AI data", e); }
        }
        return instance;
    }

    public static synchronized void invalidate() { instance = null; }

    /** Fresh controller instances (they are stateful) for one boss. */
    public Map<String, BedrockController> newControllers() { return BedrockController.parse(controllersRoot); }
}
