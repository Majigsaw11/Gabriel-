package com.ukgabriel.entity;

import com.ukgabriel.ai.AntiHeal;
import com.ukgabriel.ai.GabrielTier;
import com.ukgabriel.ai.MovePicker;
import com.ukgabriel.ai.Movement;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.Comparator;
import java.util.Random;
import java.util.UUID;

/**
 * Port of scripts/gabriel/ai.js tickBoss(): target selection (players, gabriel_target mobs, `sam` family), orbit chase,
 * attack gap, go/busy handshake with the Bedrock brain controller, special-move choice, leash and close-in.
 * Swarm (spiral sword) logic is NOT included yet.
 */
public final class GabrielAi {
    private static final int TARGET_RANGE = 64, LEASH = 22, ENGAGE_RANGE = 14;
    private static final String MARK = "gtgt";

    private final GabrielEntity boss;
    private final Random rng = new Random();
    private final Movement.State move = new Movement.State(rng);
    private final MovePicker.State picker = new MovePicker.State();
    private int gap = 20, goSince = -1, tgtTick = -99;
    private boolean attacking, wasBusy, preferMob;
    private Integer form;
    private LivingEntity target;
    private UUID markedId;

    GabrielAi(GabrielEntity boss) { this.boss = boss; }

    private ServerLevel level() { return (ServerLevel) boss.level(); }

    // ---- world queries ------------------------------------------------------------------------------------------
    private boolean solid(double x, double y, double z) {
        BlockPos p = BlockPos.containing(x, y, z);
        if (!level().isLoaded(p)) return true;
        BlockState b = level().getBlockState(p);
        return !b.isAir() && b.getFluidState().isEmpty();
    }

    private final Movement.Clear clear = (x, y, z) -> !solid(x, y, z) && !solid(x, y + 1.5, z) && !solid(x, y + 3, z);

    private boolean inFamily(Entity e) {
        return e.getType().is(GabrielDamage.fam("gabriel")) || e.getType().is(GabrielDamage.fam("inanimate")) || e.getType().is(GabrielDamage.fam("gabriel_projectile"));
    }

    private LivingEntity nearest(Iterable<? extends LivingEntity> list) {
        LivingEntity best = null; double bd = Double.MAX_VALUE;
        for (LivingEntity e : list) { double d = e.position().distanceTo(boss.position()); if (d < bd) { bd = d; best = e; } }
        return best;
    }

    private java.util.List<LivingEntity> living(double range, java.util.function.Predicate<LivingEntity> p) {
        AABB box = boss.getBoundingBox().inflate(range);
        return level().getEntitiesOfClass(LivingEntity.class, box, e -> e != boss && e.position().distanceTo(boss.position()) <= range && p.test(e));
    }

    private LivingEntity taggedMobs() {
        return nearest(living(TARGET_RANGE, e -> !(e instanceof Player) && e.isAlive() && e.getTags().contains(GabrielDamage.TARGET_TAG) && !inFamily(e)));
    }

    private LivingEntity samMobs() {
        return nearest(living(TARGET_RANGE, e -> e.isAlive() && e.getType().is(GabrielDamage.fam("sam")) && !e.getType().is(GabrielDamage.fam("gabriel"))));
    }

    private LivingEntity findMob() { LivingEntity t = taggedMobs(); return t != null ? t : samMobs(); }

    private LivingEntity findTarget(boolean preferMob) {
        if (preferMob) { LivingEntity m = findMob(); if (m != null) return m; }
        java.util.List<LivingEntity> players = living(TARGET_RANGE, e -> e instanceof ServerPlayer p && !p.isCreative() && !p.isSpectator() && p.isAlive());
        LivingEntity p = nearest(players);
        if (p != null) return p;
        return findMob();
    }

    private LivingEntity taggedTarget() {
        return nearest(living(96, e -> e.isAlive() && e.getTags().contains(MARK)));
    }

    private void markTarget(LivingEntity t) {
        if (t != null) { if (t.getUUID().equals(markedId) && t.getTags().contains(MARK)) return; }
        else if (markedId == null) return;
        boss.command("tag @e[tag=" + MARK + "] remove " + MARK);
        markedId = null;
        if (t != null) { t.addTag(MARK); markedId = t.getUUID(); }
    }

    LivingEntity target() { return target; }

    LivingEntity taggedTargetPublic() { return taggedTarget(); }

    void clearTarget() { target = null; markTarget(null); }

    // ---- movement -----------------------------------------------------------------------------------------------
    private void face(LivingEntity t) {
        float yaw = Movement.yawOf(t.getX() - boss.getX(), t.getZ() - boss.getZ());
        boss.setYRot(yaw); boss.setYHeadRot(yaw); boss.setYBodyRot(yaw);
    }

    private void stepTo(double gx, double gy, double gz, double speed, LivingEntity t) {
        double[] dest = Movement.stepTo(new double[]{boss.getX(), boss.getY(), boss.getZ()}, gx, gy, gz, speed, clear);
        if (dest == null) return;
        float yaw = Movement.yawOf(t.getX() - dest[0], t.getZ() - dest[2]);
        boss.moveTo(dest[0], dest[1], dest[2], yaw, 0f);
        boss.setYHeadRot(yaw);
        boss.setDeltaMovement(0, 0, 0);
    }

    private void closeIn(LivingEntity t) {
        double[] g = Movement.closeInGoal(new double[]{boss.getX(), boss.getY(), boss.getZ()}, new double[]{t.getX(), t.getY(), t.getZ()});
        if (g != null) stepTo(g[0], g[1], g[2], g[3], t);
    }

    private static int gapFor(int stage) { return switch (stage) { case 1 -> 10; case 2 -> 8; case 4 -> 6; case 5 -> 5; default -> 8; }; }

    // ---- main loop (ai.js tickBoss) -------------------------------------------------------------------------------
    void tick() {
        int tick = (int) level().getGameTime();
        int stage = boss.prop("gabriel:stage");
        boolean busy = boss.prop("gabriel:busy") == 1, go = boss.prop("gabriel:go") == 1;
        GabrielTier t = boss.tier();

        if (wasBusy && !busy) {
            gap = attacking ? (int) Math.round(gapFor(stage) * (1 + rng.nextDouble() * 2) / t.pace()) : 30;
            attacking = false;
        }
        wasBusy = busy;

        int f = boss.prop("gabriel:form");
        if (form == null || form != f) {
            if (form != null) AntiHeal.openHealWindow(boss.getUUID(), 100);
            form = f;
        }

        if (stage != 1 && stage != 2 && stage != 4 && stage != 5) return;

        if (busy) {
            LivingEntity tg = (attacking || go) ? taggedTarget() : null;
            if (tg != null) {
                face(tg);
                double dist = tg.position().distanceTo(boss.position());
                if (attacking && dist > LEASH) stepTo(tg.getX(), tg.getY(), tg.getZ(), Movement.CATCH_UP, tg);
                else if (boss.closeTicks > 0) closeIn(tg);
            }
            if (boss.closeTicks > 0) boss.closeTicks--;
            return;
        }

        if (go) {
            if (goSince < 0) goSince = tick;
            if (tick - goSince > 30) { boss.setProp("gabriel:go", 0); goSince = -1; attacking = false; gap = 20; }
            return;
        }
        goSince = -1;

        if (target == null || !target.isAlive() || tick - tgtTick >= 10) {
            target = findTarget(preferMob);
            tgtTick = tick;
            markTarget(target);
        }
        if (target == null) return;

        Movement.Goal g = Movement.chase(move, new double[]{boss.getX(), boss.getY(), boss.getZ()},
                new double[]{target.getX(), target.getY(), target.getZ()}, stage, t.pace(), tick, rng, clear);
        stepTo(g.x(), g.y(), g.z(), g.speed(), target);

        if (gap > 0) { gap--; return; }
        if (boss.prop("gabriel:move") >= 90) return;
        double dist = target.position().distanceTo(boss.position());
        if (dist > ENGAGE_RANGE) return;
        attacking = true;
        preferMob = rng.nextDouble() < 0.45 && findMob() != null;
        if (preferMob) boss.addTag("g_prefmob"); else boss.removeTag("g_prefmob");
        tgtTick = -99;
        if (boss.prop("gabriel:next") == 0) {
            int m = MovePicker.pick(new MovePicker.Props() {
                public int get(String n) { return boss.prop(n); }
                public void set(String n, int v) { boss.setProp(n, v); }
            }, picker, stage, dist, rng);
            if (m > 0) boss.setProp("gabriel:next", m);
        }
        boss.setProp("gabriel:go", 1);
    }
}
