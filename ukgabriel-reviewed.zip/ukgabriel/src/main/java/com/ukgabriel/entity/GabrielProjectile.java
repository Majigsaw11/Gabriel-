package com.ukgabriel.entity;

import com.mojang.logging.LogUtils;
import com.ukgabriel.ai.FlightMath;
import com.ukgabriel.bedrock.BedrockController;
import com.ukgabriel.bedrock.BrainRuntime;
import com.ukgabriel.client.ProjectileAnimation;
import com.ukgabriel.command.ModNetwork;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * One class for all seven Gabriel projectile entity types (sword_beam, sword_throw, light_axe, light_greatsword,
 * spiral_sword, spiral_swords, orbit_sensor). Behaviour is the BP entity (events, groups, timer, parry sensor) plus the
 * flight logic of scripts/gabriel/projectiles.js.
 */
public class GabrielProjectile extends Entity implements GeoEntity, BrainRuntime.Host, EventTarget {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final EntityDataAccessor<Integer> D_VARIANT = SynchedEntityData.defineId(GabrielProjectile.class, EntityDataSerializers.INT);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private ProjectileData data;
    private BrainRuntime brain;
    private String kindName;
    private FlightMath.Kind kind;
    private int timerTicks;
    private boolean timerFired;

    // flight state (projectiles.js "flights")
    private double[] dir;
    private double speed;
    private boolean speedSet, aimed, parried;
    private int age;

    public GabrielProjectile(EntityType<? extends GabrielProjectile> type, Level level) {
        super(type, level);
        noPhysics = true;
        setNoGravity(true);
    }

    public String kindName() {
        if (kindName == null) kindName = ForgeRegistries.ENTITY_TYPES.getKey(getType()).getPath();
        return kindName;
    }

    @Override protected void defineSynchedData() { entityData.define(D_VARIANT, 0); }
    public int variant() { return entityData.get(D_VARIANT); }
    @Override public int markVariant() { return variant(); }
    @Override public boolean isPickable() { return data == null ? kindName().startsWith("sword") || kindName().startsWith("light") : data.parrySensor; }
    @Override public boolean isPushable() { return false; }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }

    // ---- BrainRuntime.Host / events ----------------------------------------------------------------------------
    @Override public int prop(String n) { return 0; }
    @Override public void setProp(String n, int v) { }
    @Override public double health() { return 1; }
    @Override public double maxHealth() { return 1; }
    @Override public double random() { return random.nextDouble(); }
    @Override public void removeGroup(String g) { }

    @SuppressWarnings("unchecked")
    @Override
    public void addGroup(String g) {
        Object o = data.groups.get(g);
        if (o == null) return;
        for (Map.Entry<String, Object> c : ((Map<String, Object>) o).entrySet()) {
            switch (c.getKey()) {
                case "minecraft:mark_variant" -> entityData.set(D_VARIANT, ((Number) ((Map<String, Object>) c.getValue()).get("value")).intValue());
                case "minecraft:instant_despawn" -> discard();
                default -> LOGGER.warn("Gabriel projectile: unsupported component {} in {}", c.getKey(), g);
            }
        }
    }

    private void ensureData() {
        if (data == null && !level().isClientSide) {
            data = ProjectileData.get(level().getServer(), kindName());
            kind = FlightMath.KINDS.get(kindName());
            if (data.aliases.containsKey("ctl") && !data.animate.isEmpty()) {
                AiData ai = AiData.get(level().getServer());
                brain = new BrainRuntime(this, ai.newControllers(), ai.timelines, data.aliases, data.animate);
            }
        }
    }

    @Override
    public void fireEvent(String event) {
        ensureData();
        if (data.events.has(event)) data.events.fire(event, this);
        else LOGGER.warn("Gabriel projectile {}: unknown event {}", kindName(), event);
    }

    @Override
    public void command(String cmd) {
        if (cmd.startsWith("ukgabriel event @s ")) { fireEvent(cmd.substring("ukgabriel event @s ".length())); return; }
        if (level().getServer() == null) return;
        level().getServer().getCommands().performPrefixedCommand(createCommandSourceStack().withPermission(4).withSuppressedOutput(), cmd);
    }

    /** damage_sensor: never takes damage; anything outside the gabriel family triggers gabriel:parry. */
    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (level().isClientSide) return false;
        ensureData();
        Entity by = src.getEntity() != null ? src.getEntity() : src.getDirectEntity();
        if (data.parrySensor && !(by instanceof GabrielEntity) && !(by instanceof GabrielProjectile)) fireEvent("gabriel:parry");
        return false;
    }

    // ---- helpers -----------------------------------------------------------------------------------------------
    private ServerLevel sl() { return (ServerLevel) level(); }

    private boolean solid(double x, double y, double z) {
        BlockPos p = BlockPos.containing(x, y, z);
        if (!level().isLoaded(p)) return true;
        BlockState b = level().getBlockState(p);
        return !b.isAir() && b.getFluidState().isEmpty();
    }

    private static boolean survival(Player p) { return !p.isCreative() && !p.isSpectator(); }
    private static boolean inFamily(Entity e) {
        return e.getType().is(GabrielDamage.fam("gabriel")) || e.getType().is(GabrielDamage.fam("gabriel_projectile")) || e.getType().is(GabrielDamage.fam("inanimate"));
    }
    private static boolean isVictim(Entity v) {
        if (v == null || !v.isAlive()) return false;
        if (v instanceof Player p) return survival(p);
        return v.getTags().contains(GabrielDamage.TARGET_TAG) || v.getType().is(GabrielDamage.fam("sam"));
    }
    private static boolean isStruck(Entity v) {
        if (v == null || !v.isAlive()) return false;
        if (v instanceof Player p) return survival(p);
        return v instanceof LivingEntity;
    }

    private LivingEntity targetOf() {
        LivingEntity best = null; double bd = Double.MAX_VALUE;
        for (LivingEntity e : level().getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(128), x -> x.isAlive() && x.getTags().contains("gtgt") && x.distanceTo(this) <= 128)) {
            double d = e.distanceToSqr(this); if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    private GabrielEntity bossOf() {
        GabrielEntity best = null; double bd = Double.MAX_VALUE;
        for (GabrielEntity e : level().getEntitiesOfClass(GabrielEntity.class, getBoundingBox().inflate(256))) {
            double d = e.distanceToSqr(this); if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    private static double[] body(Entity v) { return FlightMath.bodyOf(v.getY(), v.getEyeY()); }

    private Entity strikesVictim(double[] p, boolean any) {
        for (Entity v : level().getEntities(this, new AABB(p[0] - 6, p[1] - 6, p[2] - 6, p[0] + 6, p[1] + 6, p[2] + 6), e -> !inFamily(e) && e.distanceToSqr(p[0], p[1], p[2]) <= 36)) {
            if (!(any ? isStruck(v) : isVictim(v))) continue;
            double[] b = body(v);
            if (FlightMath.pointHitsBody(p, v.getX(), b[0], v.getZ(), b[1])) return v;
        }
        return null;
    }

    private void pose(double[] p, double[] d) {
        double flat = Math.hypot(d[0], d[2]);
        float yaw = (float) (Math.atan2(-d[0], d[2]) * 180 / Math.PI), pitch = (float) (-Math.atan2(d[1], flat) * 180 / Math.PI);
        moveTo(p[0], p[1], p[2], yaw, pitch);
    }

    private void run(String function) { command("function " + com.ukgabriel.UkGabrielMod.MODID + ":" + function); }

    private void sound(String id, double[] p, String volume) { command("playsound ukgabriel:" + id + " hostile @a " + p[0] + " " + p[1] + " " + p[2] + " " + volume); }

    private void fizzle(double[] p) {
        sound("gabriel.weapon_break", p, "125");
        sl().sendParticles(ParticleTypes.EXPLOSION, p[0], p[1], p[2], 1, 0, 0, 0, 0);
        sound("gabriel.sword.break", p, "2");
        discard();
    }

    private void reflect() {
        GabrielEntity boss = bossOf();
        if (boss == null) { fizzle(new double[]{getX(), getY(), getZ()}); return; }
        parried = true;
        speed *= FlightMath.REFLECT_BOOST;
        dir = FlightMath.norm(FlightMath.sub(new double[]{boss.getX(), boss.getY() + FlightMath.BOSS_CENTER, boss.getZ()}, new double[]{getX(), getY(), getZ()}));
        command("playsound minecraft:block.anvil.land hostile @a ~ ~ ~ 3 1.6");
        sl().sendParticles(ParticleTypes.TOTEM_OF_UNDYING, getX(), getY(), getZ(), 1, 0, 0, 0, 0);
    }

    private void aftermath(double[] p) {
        if (!kindName().equals("sword_beam") && !kindName().equals("sword_throw")) return;
        for (String id : new String[]{"gabriel:blast_shell", "gabriel:blast_core", "gabriel:blast_bolts"}) ModNetwork.particle(sl(), id, p[0], p[1], p[2]);
        for (Entity v : level().getEntities(this, new AABB(p[0] - 4.5, p[1] - 4.5, p[2] - 4.5, p[0] + 4.5, p[1] + 4.5, p[2] + 4.5), e -> !inFamily(e) && e.distanceToSqr(p[0], p[1], p[2]) <= 20.25))
            if (isVictim(v)) v.setSecondsOnFire(5);
        if (!level().getGameRules().getBoolean(GameRules.RULE_MOBGRIEFING)) return;
        int bx = (int) Math.floor(p[0]), bz = (int) Math.floor(p[2]), top = (int) Math.floor(p[1]) + 6;
        for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) {
            double d = Math.hypot(dx, dz);
            if (d > 3.5) continue;
            BlockPos pos = null;
            for (int y = top; y >= level().getMinBuildHeight(); y--) {
                BlockPos c = new BlockPos(bx + dx, y, bz + dz);
                if (!level().getBlockState(c).isAir()) { pos = c; break; }
            }
            if (pos == null) continue;
            BlockState st = level().getBlockState(pos);
            if (!st.getFluidState().isEmpty()) continue;
            String id = String.valueOf(ForgeRegistries.BLOCKS.getKey(st.getBlock()));
            if (id.equals("minecraft:bedrock") || id.contains("leaves") || id.contains("log") || id.contains("chest")) continue;
            level().setBlockAndUpdate(pos, (d < 1.8 ? Blocks.GRAVEL : Blocks.COARSE_DIRT).defaultBlockState());
        }
    }

    // ---- tick ---------------------------------------------------------------------------------------------------
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        ensureData();
        if (data.timerEvent != null && !timerFired && ++timerTicks >= data.timerSeconds * 20) { timerFired = true; fireEvent(data.timerEvent); }
        if (isRemoved()) return;
        if (brain != null) brain.tick(0.05);
        if (!isRemoved() && kind != null) advance();
    }

    /** projectiles.js advance(). */
    private void advance() {
        age++;
        String k = kindName();
        if (getTags().contains("gdone")) return;
        if (age % 5 == 0 && (k.equals("light_greatsword") || k.equals("light_axe") || k.equals("sword_throw")))
            command("playsound ukgabriel:gabriel.swing_loop hostile @a ~ ~ ~ 60");
        if (dir == null) { var l = getLookAngle(); dir = FlightMath.norm(new double[]{l.x, l.y, l.z}); }

        if (!speedSet) {
            int v = variant();
            if (v < 1 || v > 4) { if (age < 3) return; v = 1; }
            speed = kind.speed()[v - 1] * TierProj.value(level().getServer());
            speedSet = true;
        }

        if (getTags().contains("gparry")) { removeTag("gparry"); if (!parried) reflect(); }
        double[] pos = {getX(), getY(), getZ()};
        if (isRemoved()) return;

        if (age > kind.life()) { if (parried) fizzle(pos); else run(kind.end()); return; }

        GabrielEntity boss = null;
        if (parried) {
            boss = bossOf();
            if (boss == null) { fizzle(pos); return; }
            dir = FlightMath.steer(dir, FlightMath.norm(FlightMath.sub(new double[]{boss.getX(), boss.getY() + FlightMath.BOSS_CENTER, boss.getZ()}, pos)), FlightMath.REFLECT_TURN);
        } else {
            LivingEntity t = targetOf();
            if (t != null) {
                double[] b = body(t);
                if (!aimed) {
                    aimed = true;
                    double[] vel = {t.getX() - t.xo, t.getY() - t.yo, t.getZ() - t.zo};
                    dir = FlightMath.leadAim(pos, new double[]{t.getX(), 0, t.getZ()}, b[2], vel, speed);
                }
                double turn = FlightMath.turnRate(kind, t instanceof Player);
                if (turn > 0) {
                    double[] d = FlightMath.sub(new double[]{t.getX(), b[2], t.getZ()}, pos);
                    if (FlightMath.len(d) > FlightMath.MIN_TRACK_DIST) {
                        double[] want = FlightMath.norm(d);
                        if (FlightMath.angleBetween(dir, want) < FlightMath.MAX_TRACK_ANGLE) dir = FlightMath.steer(dir, want, turn);
                    }
                }
            }
        }

        int steps = FlightMath.steps(speed);
        double each = speed / steps;
        for (int i = 0; i < steps; i++) {
            double[] prev = pos;
            pos = new double[]{pos[0] + dir[0] * each, pos[1] + dir[1] * each, pos[2] + dir[2] * each};
            if (solid(pos[0], pos[1], pos[2])) {
                if (!parried && k.equals("sword_throw")) { pose(prev, dir); run(kind.hit()); aftermath(prev); return; }
                pose(pos, dir);
                if (parried) fizzle(pos); else { run(kind.end()); aftermath(pos); }
                return;
            }
            if (parried) {
                double[] c = {boss.getX(), boss.getY() + FlightMath.BOSS_CENTER, boss.getZ()};
                if (FlightMath.len(FlightMath.sub(c, pos)) <= FlightMath.BOSS_RADIUS) {
                    pose(pos, dir);
                    float amount = (float) (kind.parry() * (boss.prop("gabriel:form") == 1 ? 2 : 1) * com.ukgabriel.UkGabrielConfig.PARRY_DAMAGE.get());
                    boss.hurt(level().damageSources().generic(), amount);
                    fizzle(new double[]{getX(), getY(), getZ()});
                    return;
                }
            } else {
                Entity v = strikesVictim(pos, k.equals("sword_throw"));
                if (v != null) {
                    double[] at = {v.getX(), body(v)[0] + 1.1, v.getZ()};
                    pose(at, dir); run(kind.hit()); aftermath(at);
                    return;
                }
            }
        }
        pose(pos, dir);
        sl().sendParticles(parried ? ParticleTypes.TOTEM_OF_UNDYING : ParticleTypes.END_ROD, pos[0], pos[1], pos[2], 1, 0, 0, 0, 0);
    }

    // ---- save/load: projectiles are transient; do not persist across world reloads ---------------------------------
    @Override protected void readAdditionalSaveData(CompoundTag t) { }
    @Override protected void addAdditionalSaveData(CompoundTag t) { }
    @Override public boolean shouldBeSaved() { return false; }

    // ---- GeckoLib ---------------------------------------------------------------------------------------------------
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        for (int i = 0; i < ProjectileAnimation.SLOTS; i++) {
            final int slot = i;
            controllers.add(new AnimationController<GabrielProjectile>(this, "a" + i, 0, st -> ProjectileAnimation.play(this, slot, st))
                    .setParticleKeyframeHandler(ev -> ProjectileAnimation.particle(this, ev.getKeyframeData().getEffect()))
                    .setSoundKeyframeHandler(ev -> ProjectileAnimation.sound(this, ev.getKeyframeData().getSound())));
        }
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
