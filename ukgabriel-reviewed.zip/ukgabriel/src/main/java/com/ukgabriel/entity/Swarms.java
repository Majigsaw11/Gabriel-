package com.ukgabriel.entity;

import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;

import java.util.*;

/** Port of the sword swarm in ai.js: "orbit" ring around the boss and the converging "strike" ring on the target. */
public final class Swarms {
    private static final int SW_COUNT = 8, ORBIT_LIFE = 100, STRIKE_PAUSE = 20;
    private static final double STRIKE_RADIUS = 4.4, STRIKE_SPEED = 0.5, STRIKE_BLAST = 3.2, STRIKE_DAMAGE = 35;

    private static final class Sword { GabrielProjectile ent; double[] pos; boolean dead; }
    private static final class Swarm {
        String mode; int t; LivingEntity target; double[] last; List<Sword> swords = new ArrayList<>();
    }
    private static final Map<UUID, Swarm> SWARMS = new HashMap<>();

    private Swarms() {}

    private static void sound(ServerLevel l, String id, double[] p) {
        l.getServer().getCommands().performPrefixedCommand(l.getServer().createCommandSourceStack().withSuppressedOutput(),
                "execute in " + l.dimension().location() + " run playsound " + UkGabrielMod.MODID + ":" + id + " hostile @a " + p[0] + " " + p[1] + " " + p[2] + " 3");
    }

    private static List<Sword> spawnSwords(GabrielEntity boss, double[] at, EntityType<GabrielProjectile> type) {
        List<Sword> list = new ArrayList<>();
        for (int i = 0; i < SW_COUNT; i++) {
            GabrielProjectile e = type.create(boss.level());
            if (e == null) continue;
            e.moveTo(at[0], at[1], at[2], 0, 0);
            boss.level().addFreshEntity(e);
            Sword s = new Sword(); s.ent = e; s.pos = at.clone();
            list.add(s);
        }
        return list;
    }

    private static void kill(Sword sw, boolean broke, ServerLevel l) {
        if (broke) sound(l, "gabriel.weapon_break", new double[]{sw.ent.getX(), sw.ent.getY(), sw.ent.getZ()});
        sw.ent.discard();
    }

    public static void clear(GabrielEntity boss) {
        Swarm w = SWARMS.remove(boss.getUUID());
        if (w == null || !(boss.level() instanceof ServerLevel l)) return;
        for (Sword s : w.swords) if (!s.dead && !s.ent.isRemoved()) s.ent.discard();
    }

    public static void startOrbit(GabrielEntity boss) {
        clear(boss);
        if (!(boss.level() instanceof ServerLevel l)) return;
        Swarm w = new Swarm();
        w.mode = "orbit";
        w.swords = spawnSwords(boss, new double[]{boss.getX(), boss.getY() + 1.5, boss.getZ()}, ModEntities.ORBIT_SENSOR.get());
        SWARMS.put(boss.getUUID(), w);
        sound(l, "gabriel.sword.spawn", new double[]{boss.getX(), boss.getY(), boss.getZ()});
    }

    public static void startStrike(GabrielEntity boss) {
        LivingEntity target = boss.ai().taggedTargetPublic();
        if (target == null) target = boss.ai().target();
        clear(boss);
        if (target == null || !target.isAlive() || !(boss.level() instanceof ServerLevel l)) return;
        Swarm w = new Swarm();
        w.mode = "strike"; w.target = target;
        w.swords = spawnSwords(boss, new double[]{target.getX(), target.getY() + 2, target.getZ()}, ModEntities.SPIRAL_SWORD.get());
        SWARMS.put(boss.getUUID(), w);
        sound(l, "gabriel.sword.spawn", new double[]{target.getX(), target.getY(), target.getZ()});
    }

    private static boolean isVictim(Entity e) {
        if (e == null || !e.isAlive()) return false;
        String id = String.valueOf(net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getKey(e.getType()));
        if (id.startsWith(UkGabrielMod.MODID + ":")) return false;
        if (e instanceof Player p) return !p.isCreative() && !p.isSpectator();
        return e.getTags().contains(GabrielDamage.TARGET_TAG);
    }

    private static void place(Sword sw, double[] pos, double[] dir) {
        double flat = Math.hypot(dir[0], dir[2]);
        float yaw = (float) (Math.atan2(-dir[0], dir[2]) * 180 / Math.PI), pitch = (float) (-Math.atan2(dir[1], flat) * 180 / Math.PI);
        sw.ent.moveTo(pos[0], pos[1], pos[2], yaw, pitch);
    }

    private static List<Entity> near(GabrielEntity boss, double[] c, double r) {
        return boss.level().getEntities(boss, new AABB(c[0] - r, c[1] - r, c[2] - r, c[0] + r, c[1] + r, c[2] + r),
                e -> !(e instanceof GabrielProjectile) && e.distanceToSqr(c[0], c[1], c[2]) <= r * r);
    }

    /** Called once per server tick for each boss (ai.js tickSwarms). */
    public static void tick(GabrielEntity boss) {
        Swarm w = SWARMS.get(boss.getUUID());
        if (w == null || !(boss.level() instanceof ServerLevel l)) return;
        try {
            if (w.mode.equals("orbit")) tickOrbit(boss, w, l); else tickStrike(boss, w, l);
            w.t++;
        } catch (RuntimeException e) { clear(boss); }
    }

    private static void tickOrbit(GabrielEntity boss, Swarm w, ServerLevel l) {
        double spin = w.t * 0.314, grow = Math.min(1, w.t / 8.0);
        for (int i = 0; i < w.swords.size(); i++) {
            Sword sw = w.swords.get(i);
            if (sw.dead) continue;
            double a = spin + i * Math.PI * 2 / SW_COUNT, r = 0.6 + 1.9 * grow;
            sw.pos = new double[]{boss.getX() + Math.cos(a) * r, boss.getY() + 1.5, boss.getZ() + Math.sin(a) * r};
            place(sw, sw.pos, new double[]{Math.cos(a), 0, Math.sin(a)});
            if (w.t % 2 == 0) {
                for (Entity e : near(boss, sw.pos, 1.5)) {
                    if (isVictim(e)) { GabrielDamage.hurtAs(boss, (LivingEntity) e, 35, false); kill(sw, true, l); sw.dead = true; break; }
                }
            }
        }
        if (w.t >= ORBIT_LIFE) clear(boss);
    }

    private static void tickStrike(GabrielEntity boss, Swarm w, ServerLevel l) {
        LivingEntity tg = w.target;
        if (tg != null && tg.isAlive() && w.t < STRIKE_PAUSE) w.last = new double[]{tg.getX(), tg.getY(), tg.getZ()};
        double[] c = w.last != null ? w.last : new double[]{boss.getX(), boss.getY(), boss.getZ()};
        double[] center = {c[0], c[1] + 0.6, c[2]};
        double r = STRIKE_RADIUS;
        if (w.t >= STRIKE_PAUSE) r = Math.max(0.5, STRIKE_RADIUS - (w.t - STRIKE_PAUSE + 1) * STRIKE_SPEED);
        double spin = w.t < STRIKE_PAUSE ? w.t * 0.09 : STRIKE_PAUSE * 0.09;
        for (int i = 0; i < w.swords.size(); i++) {
            Sword sw = w.swords.get(i);
            if (sw.dead) continue;
            double a = spin + i * Math.PI * 2 / SW_COUNT;
            sw.pos = new double[]{center[0] + Math.cos(a) * r, center[1], center[2] + Math.sin(a) * r};
            place(sw, sw.pos, new double[]{-Math.cos(a), 0, -Math.sin(a)});
        }
        if (w.t == STRIKE_PAUSE) sound(l, "gabriel.swing.aoh", center);
        if (w.t >= STRIKE_PAUSE && r <= 0.8) {
            for (Entity e : near(boss, center, STRIKE_BLAST)) if (isVictim(e)) GabrielDamage.hurtAs(boss, (LivingEntity) e, (float) STRIKE_DAMAGE, true);
            l.sendParticles(ParticleTypes.EXPLOSION, center[0], center[1], center[2], 1, 0, 0, 0, 0);
            sound(l, "gabriel.sword.break", center);
            clear(boss);
        }
    }
}
