package com.ukgabriel.entity;

import com.ukgabriel.ai.TierData;
import net.minecraft.server.MinecraftServer;

/** projectiles.js tierSpeed(): projectile speed multiplier of the current difficulty tier. */
final class TierProj {
    private TierProj() {}
    static double value(MinecraftServer server) { return TierData.current(server).proj(); }
}
