package com.ukgabriel.entity;

import com.ukgabriel.command.ModNetwork;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

/**
 * main.js cutscene safety net: every second, players tagged gabriel_cine get HUD, camera and input restored
 * unless some Gabriel is in stage 3 (transformation) or 6 (defeat).
 */
public final class CutsceneCleanup {
    @SubscribeEvent
    public void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.getServer().getTickCount() % 20 != 0) return;
        boolean active = false;
        for (GabrielEntity g : GabrielEntity.BOSSES) { int st = g.prop("gabriel:stage"); if (st == 3 || st == 6) { active = true; break; } }
        if (active) return;
        for (ServerPlayer p : e.getServer().getPlayerList().getPlayers()) {
            if (!p.getTags().contains("gabriel_cine")) continue;
            for (ModNetwork.CutscenePacket pkt : new ModNetwork.CutscenePacket[]{ModNetwork.CutscenePacket.hud(false), ModNetwork.CutscenePacket.cameraClear(),
                    ModNetwork.CutscenePacket.input(false, true), ModNetwork.CutscenePacket.input(true, true)})
                ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt);
            p.removeTag("gabriel_cine");
        }
    }
}
