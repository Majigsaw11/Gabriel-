package com.ukgabriel.entity;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

/** Port of scripts/gabriel/subtitles.js `show`/`push`: action-bar subtitle for players within 96 blocks. */
public final class Subtitles {
    private static final double RANGE = 96;
    private static ServerLevel level;
    private static Vec3 loc;
    private static Component text;
    private static long until;

    public static void show(ServerLevel lvl, Vec3 pos, String msg, double seconds) {
        level = lvl; loc = pos; text = Component.literal(msg); until = lvl.getGameTime() + Math.round(seconds * 20);
        push();
    }

    private static void push() {
        if (level == null) return;
        if (level.getGameTime() >= until) { level = null; return; }
        for (ServerPlayer p : level.players()) if (p.position().distanceToSqr(loc) <= RANGE * RANGE) p.displayClientMessage(text, true);
    }

    @SubscribeEvent
    public void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END && level != null && level.getGameTime() % 5 == 0) push();
    }
}
