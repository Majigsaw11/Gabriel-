package com.ukgabriel.entity;

/** Entities that understand Bedrock-style events (`/ukgabriel event <targets> <event>`). */
public interface EventTarget {
    void fireEvent(String event);
}
