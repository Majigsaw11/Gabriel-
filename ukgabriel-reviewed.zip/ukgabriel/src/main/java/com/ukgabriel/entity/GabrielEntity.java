package com.ukgabriel.entity;

import com.mojang.logging.LogUtils;
import com.ukgabriel.bedrock.BedrockEvents;
import com.ukgabriel.bedrock.BrainRuntime;
import com.ukgabriel.ai.GabrielTier;
import com.ukgabriel.ai.TierData;
import com.ukgabriel.client.GabrielAnimation;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.level.Level;
import org.slf4j.Logger;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.AnimatableManager;
import software.bernie.geckolib.core.animation.AnimationController;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * Gabriel. Properties (gabriel:anim/form/stage/...) and component groups mirror the Bedrock entity; the Bedrock
 * brain/phase controllers, timelines and events run through {@link BrainRuntime} unchanged.
 */
public class GabrielEntity extends Monster implements GeoEntity, BrainRuntime.Host, EventTarget {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final EntityDataAccessor<Integer> D_ANIM = SynchedEntityData.defineId(GabrielEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> D_FORM = SynchedEntityData.defineId(GabrielEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> D_STAGE = SynchedEntityData.defineId(GabrielEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> D_ENRAGE = SynchedEntityData.defineId(GabrielEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> D_DEFEAT = SynchedEntityData.defineId(GabrielEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> D_MUSIC = SynchedEntityData.defineId(GabrielEntity.class, EntityDataSerializers.INT);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final Map<String, Integer> props = new LinkedHashMap<>();
    private final Set<String> groups = new LinkedHashSet<>();
    private final ServerBossEvent bossBar = new ServerBossEvent(Component.literal("Gabriel"), BossEvent.BossBarColor.YELLOW, BossEvent.BossBarOverlay.PROGRESS);
    private AiData data;
    private BrainRuntime brain;
    private boolean spawnEventFired;
    private GabrielAi ai;
    private String hpTier = "";
    private int introTicks;
    /** Loaded bosses (used by server-side music). */
    public static final java.util.Set<GabrielEntity> BOSSES = java.util.concurrent.ConcurrentHashMap.newKeySet();
    /** Set by `/ukgabriel script close` (scriptevent gabriel:close): ai.js reads it to close the gap to the target. */
    public int closeTicks;

    public GabrielEntity(EntityType<? extends GabrielEntity> type, Level level) {
        super(type, level);
        setNoGravity(true);
        xpReward = 500;
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 1000)
                .add(Attributes.MOVEMENT_SPEED, 0.35)
                .add(Attributes.FLYING_SPEED, 0.45)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                .add(Attributes.FOLLOW_RANGE, 64)
                .add(Attributes.ATTACK_DAMAGE, 1);
    }

    /** Base BP behaviours: hurt_by_target (1), nearest_attackable_target (2: players, gabriel_target mobs, `sam` family; 64 blocks, no line of sight), look_at_player (6, 48). */
    @Override
    protected void registerGoals() {
        targetSelector.addGoal(1, new HurtByTargetGoal(this));
        targetSelector.addGoal(2, new NearestAttackableTargetGoal<LivingEntity>(this, LivingEntity.class, 10, false, false, e ->
                e instanceof Player
                || (e.getTags().contains(GabrielDamage.TARGET_TAG) && !e.getType().is(GabrielDamage.fam("inanimate")) && !e.getType().is(GabrielDamage.fam("gabriel")) && !e.getType().is(GabrielDamage.fam("gabriel_projectile")))
                || (e.getType().is(GabrielDamage.fam("sam")) && !e.getType().is(GabrielDamage.fam("gabriel")))));
        goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 48f));
    }

    /** The add-on maps Peaceful to its Harmless tier, so Gabriel must not be removed by vanilla Peaceful despawning. */
    @Override public boolean shouldDespawnInPeaceful() { return false; }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(D_ANIM, 0);
        entityData.define(D_FORM, 0);
        entityData.define(D_STAGE, 0);
        entityData.define(D_ENRAGE, 0);
        entityData.define(D_DEFEAT, 0);
        entityData.define(D_MUSIC, 0);
    }

    // ---- properties -------------------------------------------------------------------------------------------
    @Override
    public int prop(String n) {
        return switch (n) {
            case "gabriel:anim" -> entityData.get(D_ANIM);
            case "gabriel:form" -> entityData.get(D_FORM);
            case "gabriel:stage" -> entityData.get(D_STAGE);
            case "gabriel:enrage" -> entityData.get(D_ENRAGE);
            case "gabriel:defeat" -> entityData.get(D_DEFEAT);
            case "gabriel:music" -> entityData.get(D_MUSIC);
            default -> {
                Integer v = props.get(n);
                if (v == null) {
                    if (data == null) yield 0; // client: unsynced property, not needed there
                    throw new IllegalStateException("unknown property " + n);
                }
                yield v;
            }
        };
    }

    @Override
    public void setProp(String n, int v) {
        int[] r = data != null ? data.ranges.get(n) : null;
        if (r != null) v = Mth.clamp(v, r[0], r[1]);
        props.put(n, v);
        switch (n) {
            case "gabriel:anim" -> entityData.set(D_ANIM, v);
            case "gabriel:form" -> entityData.set(D_FORM, v);
            case "gabriel:stage" -> entityData.set(D_STAGE, v);
            case "gabriel:enrage" -> entityData.set(D_ENRAGE, v);
            case "gabriel:defeat" -> entityData.set(D_DEFEAT, v);
            case "gabriel:music" -> entityData.set(D_MUSIC, v);
            default -> { }
        }
    }

    private static String nbtKey(String prop) {
        String s = prop.substring(prop.indexOf(':') + 1);
        return "Gab" + Character.toUpperCase(s.charAt(0)) + s.substring(1); // gabriel:form -> GabForm (used by nbt= selectors)
    }

    private void ensureData() {
        if (data == null && !level().isClientSide) {
            data = AiData.get(level().getServer());
            for (Map.Entry<String, Integer> e : data.defaults.entrySet()) props.putIfAbsent(e.getKey(), e.getValue());
            for (Map.Entry<String, Integer> e : props.entrySet()) setProp(e.getKey(), e.getValue()); // mirror into synced data
            brain = new BrainRuntime(this, data.newControllers(), data.timelines, data.aliases, AiData.ANIMATE);
            ai = new GabrielAi(this);
        }
    }

    // ---- events and component groups --------------------------------------------------------------------------
    @Override
    public void fireEvent(String event) {
        ensureData();
        if (data.events.has(event)) data.events.fire(event, this);
        else LOGGER.warn("Gabriel: unknown event {}", event);
    }

    @SuppressWarnings("unchecked")
    @Override
    public void addGroup(String g) {
        groups.add(g);
        Object o = data.groups.get(g);
        if (o == null) return;
        for (Map.Entry<String, Object> c : ((Map<String, Object>) o).entrySet()) {
            Map<String, Object> v = (Map<String, Object>) c.getValue();
            switch (c.getKey()) {
                case "minecraft:health" -> {
                    getAttribute(Attributes.MAX_HEALTH).setBaseValue(((Number) v.get("max")).doubleValue());
                    setHealth((float) ((Number) v.get("value")).doubleValue());
                }
                case "minecraft:movement" -> getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(((Number) v.get("value")).doubleValue());
                case "minecraft:flying_speed" -> getAttribute(Attributes.FLYING_SPEED).setBaseValue(((Number) v.get("value")).doubleValue());
                case "minecraft:boss" -> bossBar.setName(Component.literal(((String) v.get("name")).replace("\u00a7g", "\u00a76")));
                case "minecraft:instant_despawn" -> discard();
                case "minecraft:damage_sensor" -> { /* evaluated in hurt() from the active groups */ }
                default -> LOGGER.warn("Gabriel: unsupported component {} in group {}", c.getKey(), g);
            }
        }
    }

    @Override public void removeGroup(String g) { groups.remove(g); }

    /** Runs a translated Java command as the boss (permission 4, silent). */
    @Override
    public void command(String cmd) {
        if (cmd.startsWith("ukgabriel event @s ")) { fireEvent(cmd.substring("ukgabriel event @s ".length())); return; }
        if (level().getServer() == null) return;
        level().getServer().getCommands().performPrefixedCommand(createCommandSourceStack().withPermission(4).withSuppressedOutput(), cmd);
    }

    @Override public double random() { return getRandom().nextDouble(); }
    @Override public double health() { return getHealth(); }
    @Override public double maxHealth() { return getMaxHealth(); }

    public GabrielAi ai() { return ai; }

    // ---- difficulty tier (scripts/gabriel/difficulty.js) ------------------------------------------------------
    public GabrielTier tier() { return TierData.current(level().getServer()); }

    /** immortal.js isGabrielIntro: immortal for 140 ticks after being freshly spawned. */
    public boolean isIntro() { return introTicks > 0 || getTags().contains("gabriel_immortal"); }

    private void applyTier() {
        GabrielTier t = tier();
        if (prop("gabriel:tier") != t.index()) setProp("gabriel:tier", t.index());
        if (t.hp() > 0 && !hpTier.equals(t.name())) { fireEvent("gabriel:hp_mob_battle"); hpTier = t.name(); }
    }

    @Override public void onAddedToWorld() { super.onAddedToWorld(); BOSSES.add(this); }
    @Override public void onRemovedFromWorld() {
        super.onRemovedFromWorld();
        BOSSES.remove(this);
        if (ai != null) ai.clearTarget();
        Swarms.clear(this);
    }

    // ---- ticking ----------------------------------------------------------------------------------------------
    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        ensureData();
        if (!spawnEventFired) {
            spawnEventFired = true;
            if (groups.isEmpty()) { fireEvent("minecraft:entity_spawned"); introTicks = 140; }
        }
        if (introTicks > 0) introTicks--;
        if (tickCount % 20 == 1) applyTier();
        ai.tick();
        Swarms.tick(this);
        brain.tick(0.05);
        bossBar.setProgress(Mth.clamp(getHealth() / getMaxHealth(), 0f, 1f));
    }

    // ---- damage_sensor ----------------------------------------------------------------------------------------
    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (level().isClientSide) return super.hurt(src, amount);
        if (groups.contains("gabriel:invuln") || isIntro()) return false;          // damage_sensor: cause "all" -> no; immortal.js intro
        if (src.is(DamageTypes.FALL) || src.is(DamageTypes.DROWN) || src.is(DamageTypes.IN_WALL) || src.is(DamageTypes.IN_FIRE)
                || src.is(DamageTypes.ON_FIRE) || src.is(DamageTypes.LAVA) || src.is(DamageTypes.WITHER)
                || src.is(DamageTypes.MAGIC) || src.is(DamageTypes.INDIRECT_MAGIC)) return false;
        boolean hurt = super.hurt(src, amount);
        if (hurt && groups.contains("gabriel:stunned")) fireEvent("gabriel:bounce"); // on_damage -> gabriel:bounce
        return hurt;
    }

    @Override
    public void die(DamageSource src) {
        super.die(src);
        if (!level().isClientSide) fireEvent("gabriel:died"); // minecraft:on_death
    }

    // ---- boss bar / persistence -------------------------------------------------------------------------------
    @Override public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bossBar.addPlayer(p); }
    @Override public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bossBar.removePlayer(p); }
    @Override public boolean isPushable() { return false; }
    @Override public boolean removeWhenFarAway(double d) { return false; }
    @Override public boolean causeFallDamage(float f, float m, DamageSource s) { return false; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        for (Map.Entry<String, Integer> e : props.entrySet()) tag.putInt(nbtKey(e.getKey()), e.getValue());
        ListTag g = new ListTag();
        for (String s : groups) g.add(StringTag.valueOf(s));
        tag.put("GabGroups", g);
        tag.putBoolean("GabInit", spawnEventFired);
        tag.putString("GabHpTier", hpTier);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        ensureData();
        if (data == null) return;
        for (String p : data.defaults.keySet()) if (tag.contains(nbtKey(p))) setProp(p, tag.getInt(nbtKey(p)));
        float hp = getHealth();
        for (Tag t : tag.getList("GabGroups", Tag.TAG_STRING)) addGroup(t.getAsString());
        setHealth(hp); // groups reset health; keep the saved value
        spawnEventFired = tag.getBoolean("GabInit");
        hpTier = tag.getString("GabHpTier");
    }

    // ---- GeckoLib ---------------------------------------------------------------------------------------------
    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        for (int i = 0; i < GabrielAnimation.SLOTS; i++) {
            final int slot = i;
            controllers.add(new AnimationController<GabrielEntity>(this, "slot" + i, 3, st -> GabrielAnimation.play(this, slot, st))
                    .setParticleKeyframeHandler(ev -> GabrielAnimation.particle(this, ev.getKeyframeData().getEffect())));
        }
    }

    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}
