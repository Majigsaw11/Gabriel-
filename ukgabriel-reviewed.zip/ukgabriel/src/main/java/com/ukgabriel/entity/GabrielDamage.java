package com.ukgabriel.entity;

import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.ai.AntiHeal;
import com.ukgabriel.ai.GabrielTier;
import com.ukgabriel.ai.TierData;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.tags.TagKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.event.entity.living.LivingDamageEvent;
import net.minecraftforge.event.entity.living.LivingHealEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.EventPriority;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Ports of scripts/gabriel/{damage,armor,anti_heal,target}.js as Forge events.
 * (Chara buff hooks from chara_buffs.js belong to another boss's system and are intentionally not ported.)
 */
@Mod.EventBusSubscriber(modid = UkGabrielMod.MODID)
public final class GabrielDamage {
    public static final String TARGET_TAG = "gabriel_target";
    private static final double AOH_CUT = 0.85;
    private static boolean applying;

    private static final TagKey<EntityType<?>> FAM_GABRIEL = fam("gabriel"), FAM_PROJECTILE = fam("gabriel_projectile"), FAM_INANIMATE = fam("inanimate");
    static TagKey<EntityType<?>> fam(String n) { return TagKey.create(Registries.ENTITY_TYPE, new net.minecraft.resources.ResourceLocation(UkGabrielMod.MODID, "family/" + n)); }

    private GabrielDamage() {}

    // damage causes used by damage.js (Bedrock cause -> closest Java damage type)
    private static ResourceKey<DamageType> cause(String c) {
        return switch (c) {
            case "override" -> DamageTypes.GENERIC_KILL;
            case "selfDestruct", "entityExplosion", "blockExplosion" -> DamageTypes.EXPLOSION;
            case "void" -> DamageTypes.FELL_OUT_OF_WORLD;
            case "sonicBoom" -> DamageTypes.SONIC_BOOM;
            default -> DamageTypes.MOB_ATTACK;
        };
    }

    private static final String[][] JOH_MELEE = {{"override", "selfDestruct"}}, AOH_MELEE = {{"void", "sonicBoom"}};
    private static String[] sources(boolean projectile, boolean aoh) {
        if (projectile) return aoh ? new String[]{"blockExplosion", "override"} : new String[]{"entityExplosion", "blockExplosion"};
        return aoh ? AOH_MELEE[0] : JOH_MELEE[0];
    }

    @SubscribeEvent(priority = EventPriority.HIGH)
    public static void onHurt(LivingHurtEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide) return;
        Entity src = e.getSource().getEntity();
        if (victim instanceof GabrielEntity g) { armor(g, e); tagAttacker(src); return; }
        if (applying || !(src instanceof GabrielEntity boss)) return;

        GabrielTier t = boss.tier();
        int dmg = t.scaledDamage(victim instanceof Player, victim.getMaxHealth(), e.getAmount());
        boolean toPlayer = victim instanceof Player;
        double mul = toPlayer ? com.ukgabriel.UkGabrielConfig.PLAYER_DAMAGE.get() : com.ukgabriel.UkGabrielConfig.MOB_DAMAGE.get();
        if (mul != 1) dmg = (int) GabrielTier.jsRound(dmg * mul);
        int cap = com.ukgabriel.UkGabrielConfig.MAX_PLAYER_HIT.get();
        if (toPlayer && cap > 0) dmg = Math.min(dmg, cap);
        if (dmg <= 0) { e.setCanceled(true); return; }
        if (!t.varied()) { e.setAmount(dmg); return; }
        // Mob Battle: re-deliver the hit with a varied damage cause (damage.js deliver()).
        e.setCanceled(true);
        boolean projectile = e.getSource().is(DamageTypes.EXPLOSION);
        String[] attempts = sources(projectile, boss.prop("gabriel:form") == 1);
        applying = true;
        try {
            for (String c : attempts) {
                if (!victim.isAlive() || !boss.isAlive()) break;
                float before = victim.getHealth();
                victim.invulnerableTime = 0;
                victim.hurt(victim.level().damageSources().source(cause(c), boss), dmg);
                if (victim.getHealth() < before - 0.001f) break;
            }
        } finally { applying = false; }
        AntiHeal.apply(victim);
    }

    /** damage.js hurtAs(): deliver a scripted hit; onHurt() then applies the tier scaling / Mob Battle cause variation. */
    public static void hurtAs(GabrielEntity boss, LivingEntity victim, float amount, boolean explosion) {
        if (!victim.isAlive()) return;
        var ds = victim.level().damageSources();
        victim.hurt(explosion ? ds.explosion(boss, boss) : ds.mobAttack(boss), amount);
    }

    /** armor.js: cap one hit to armorCap x max health, apostate takes 15% less, min 1 (not during stage 0/3 or while stunned). */
    private static void armor(GabrielEntity g, LivingHurtEvent e) {
        int stage = g.prop("gabriel:stage");
        if (g.isIntro() || stage == 0 || stage == 3 || g.getTags().contains("gabriel_stunned")) return;
        double max = g.getMaxHealth(), dmg = e.getAmount();
        if (max > 0) dmg = Math.min(dmg, max * g.tier().armorCap());
        if (g.prop("gabriel:form") == 1) dmg *= AOH_CUT;
        e.setAmount((float) Math.max(1, GabrielTier.jsRound(dmg)));
    }

    /** target.js: whoever hurts Gabriel becomes a valid mob target (gabriel_target). */
    private static void tagAttacker(Entity src) {
        if (src == null || !src.isAlive() || src instanceof GabrielEntity || src.getTags().contains(TARGET_TAG)) return;
        String id = String.valueOf(net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getKey(src.getType()));
        if (id.startsWith(UkGabrielMod.MODID + ":")) return;
        if (src instanceof Player p) { if (p.isCreative() || p.isSpectator()) return; }
        else if (src.getType().is(FAM_GABRIEL) || src.getType().is(FAM_PROJECTILE) || src.getType().is(FAM_INANIMATE)) return;
        src.addTag(TARGET_TAG);
    }

    /** anti_heal.js: Mob Battle hits strip healing from victims for 5 s. */
    @SubscribeEvent
    public static void onDamaged(LivingDamageEvent e) {
        if (e.getEntity().level().isClientSide || applying) return;
        if (e.getSource().getEntity() instanceof GabrielEntity boss && !(e.getEntity() instanceof GabrielEntity) && boss.tier().antiHeal())
            AntiHeal.apply(e.getEntity());
    }

    @SubscribeEvent
    public static void onHeal(LivingHealEvent e) {
        LivingEntity v = e.getEntity();
        if (v.level().isClientSide) return;
        if (v.getTags().contains(AntiHeal.NO_HEAL_TAG)) { e.setCanceled(true); return; }
        if (v instanceof GabrielEntity g && g.tier().antiHeal()) {
            int stage = g.prop("gabriel:stage");
            if (stage != 0 && stage != 3 && !AntiHeal.windowOpen(g.getUUID())) e.setCanceled(true);
        }
    }
}
