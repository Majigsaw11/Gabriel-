package com.ukgabriel.entity;

import com.mojang.logging.LogUtils;
import com.ukgabriel.UkGabrielMod;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

import java.util.HashMap;
import java.util.Map;

/** Ports of the `scriptevent gabriel:*` handlers in scripts/gabriel/ai.js and subtitles.js. */
public final class GabrielScripts {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<String, Integer> LAST_TAUNT = new HashMap<>();

    private static final Object[][] JOH = {
        {"You defy the light!", 2.29}, {"A mere object!", 2.78}, {"There can be only light!", 3.21},
        {"Foolishness, machine. Foolishness.", 2.97}, {"An imperfection to be cleansed...", 2.8}, {"Not. Even. Mortal.", 2.78},
        {"You are less than nothing", 2.6}, {"You're an error to be corrected!", 2.96}, {"The light IS perfection!", 2.72},
        {"You are outclassed!", 2.05}, {"Your crime is existence!", 2.4}, {"You make even the DEVIL CRY!", 2.51}};
    private static final Object[][] APO = {
        {"IS THIS WHAT I LOST TO!?", 2.47}, {"YOU'RE GETTING RUSTY, MACHINE!", 2.7}, {"LET'S SETTLE THIS!", 2.08},
        {"NOTHING BUT SCRAP!", 2.05}, {"I'LL SHOW YOU DIVINE JUSTICE!", 3.51}, {"TIME TO RIGHT MY WRONG!", 2.97}, {"YOU NEED. MORE. POWER!", 3.17}};
    private static final Object[][] ECS = {
        {"I've never had a fight like this before!", 3.01}, {"Show me what you were made for!", 3.68},
        {"Now THIS is a fight worthy of God's Will!", 3.56}, {"What is this FEELING?", 3.8}, {"Come get some BLOOD!", 3.55},
        {"Come on, machine! Fight me like an ANIMAL!", 3.19}, {"I'll show you TRUE splendor!", 2.61}};

    private GabrielScripts() {}

    public static boolean run(CommandSourceStack src, String name, String args) {
        Entity e = src.getEntity();
        GabrielEntity boss = e instanceof GabrielEntity g ? g : null;
        switch (name) {
            case "close" -> { if (boss != null) boss.closeTicks = 6; return true; }                        // s.close = 6
            case "ground" -> { if (boss != null) ground(boss, parse(args)); return true; }
            case "taunt" -> { if (boss != null) taunt(boss); return true; }
            case "skip_aoh_intro" -> { skipAohIntro(src); return true; }
            case "spiral" -> { if (boss != null) { if (args.trim().equals("strike")) Swarms.startStrike(boss); else Swarms.startOrbit(boss); } return true; }
            case "summon" -> { LOGGER.warn("Gabriel: scriptevent gabriel:summon is not ported yet"); return false; }
            default -> { LOGGER.warn("Gabriel: unknown script {}", name); return false; }
        }
    }

    private static double parse(String s) { try { return Double.parseDouble(s.trim()); } catch (Exception ex) { return 0; } }

    /** ai.js: raycast straight down up to 96 blocks and stand 1 + lift above the hit block. */
    private static void ground(GabrielEntity b, double lift) {
        Vec3 from = b.position();
        BlockHitResult hit = b.level().clip(new ClipContext(from, from.add(0, -96, 0), ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, b));
        if (hit.getType() == HitResult.Type.BLOCK) b.teleportTo(from.x, hit.getBlockPos().getY() + 1 + lift, from.z);
    }

    private static void skipAohIntro(CommandSourceStack src) {
        boolean skipped = false;
        for (ServerLevel lvl : src.getServer().getAllLevels()) {
            for (Entity en : lvl.getAllEntities()) {
                if (!(en instanceof GabrielEntity b) || b.prop("gabriel:stage") != 3) continue;
                b.fireEvent("gabriel:skip_on");
                for (String snd : new String[]{"gabriel.intro.phase2", "gabriel.insignificant", "gabriel.enrage_end"})
                    src.getServer().getCommands().performPrefixedCommand(src.getServer().createCommandSourceStack().withSuppressedOutput(),
                            "stopsound @a * " + UkGabrielMod.MODID + ":" + snd);
                Subtitles.show(lvl, b.position(), " ", 0.05);
                skipped = true;
            }
        }
        if (!skipped && src.getEntity() instanceof ServerPlayer p) p.displayClientMessage(Component.literal("Gabriel isn't transforming."), true);
    }

    /** subtitles.js taunt(): random line per stage, never the same twice in a row; voice at volume 3 to players within 128. */
    private static void taunt(GabrielEntity b) {
        int stage = b.prop("gabriel:stage");
        String prefix = "gabriel.taunt.judge"; Object[][] list = JOH;
        if (stage == 4) { prefix = "gabriel.taunt.apostate"; list = APO; }
        else if (stage == 5) { prefix = "gabriel.taunt.ecstatic"; list = ECS; }
        int i = b.getRandom().nextInt(list.length);
        Integer last = LAST_TAUNT.get(prefix);
        if (list.length > 1 && last != null && last == i) i = (i + 1) % list.length;
        LAST_TAUNT.put(prefix, i);
        SoundEvent snd = ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation(UkGabrielMod.MODID, prefix + "." + i));
        if (snd != null && b.level() instanceof ServerLevel lvl)
            for (ServerPlayer p : lvl.players()) if (p.distanceToSqr(b) <= 128 * 128) p.playNotifySound(snd, SoundSource.HOSTILE, 3f, 1f);
        if (b.level() instanceof ServerLevel lvl) Subtitles.show(lvl, b.position(), (String) list[i][0], (Double) list[i][1] + 0.4);
    }
}
