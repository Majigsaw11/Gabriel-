package com.ukgabriel.entity;

import com.ukgabriel.command.ModNetwork.CutscenePacket;
import com.ukgabriel.command.ModNetwork;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

/**
 * Port of scripts/camera.js (Minos Prime's camera mode) for Gabriel, driven by the Gabriel Camera item:
 * a free camera follows the nearest Gabriel at offset (-7, +3, +2) looking at him, HUD hidden, movement locked, player invisible.
 * Use the item again to leave; also ends when Gabriel is gone, the player changes dimension or logs out.
 */
public final class BossCamera {
    private static final double OX = -7, OY = 3, OZ = 2;
    private static final Set<UUID> VIEWERS = new HashSet<>();

    public static boolean active(ServerPlayer p) { return VIEWERS.contains(p.getUUID()); }

    private static GabrielEntity boss(ServerPlayer p) {
        GabrielEntity best = null; double bd = Double.MAX_VALUE;
        for (GabrielEntity g : GabrielEntity.BOSSES) {
            if (!g.isAlive() || g.level() != p.level()) continue;
            double d = g.distanceToSqr(p);
            if (d < bd) { bd = d; best = g; }
        }
        return best;
    }

    private static void send(ServerPlayer p, CutscenePacket pkt) { ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt); }

    public static void toggle(ServerPlayer p) {
        if (active(p)) { stop(p, null); return; }
        GabrielEntity g = boss(p);
        if (g == null) { p.displayClientMessage(Component.literal("\u00a7cGabriel needs to be summoned first."), true); return; }
        VIEWERS.add(p.getUUID());
        send(p, CutscenePacket.hud(true));
        send(p, CutscenePacket.input(false, false));
        p.displayClientMessage(Component.literal("Use the camera again to exit Camera Mode"), true);
        update(p, g);
    }

    private static void stop(ServerPlayer p, String why) {
        VIEWERS.remove(p.getUUID());
        send(p, CutscenePacket.cameraClear());
        send(p, CutscenePacket.hud(false));
        send(p, CutscenePacket.input(false, true));
        p.removeEffect(MobEffects.INVISIBILITY);
        if (why != null) p.displayClientMessage(Component.literal(why), true);
    }

    private static void update(ServerPlayer p, GabrielEntity g) {
        send(p, CutscenePacket.cameraFree(g.getX() + OX, g.getY() + OY, g.getZ() + OZ, g.getId(), 0.1));
        if (p.tickCount % 20 == 0 || !p.hasEffect(MobEffects.INVISIBILITY))
            p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY, 60, 0, true, false, false));
    }

    @SubscribeEvent
    public void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || VIEWERS.isEmpty() || e.getServer().getTickCount() % 2 != 0) return;
        for (Iterator<UUID> it = new HashSet<>(VIEWERS).iterator(); it.hasNext(); ) {
            UUID id = it.next();
            ServerPlayer p = e.getServer().getPlayerList().getPlayer(id);
            if (p == null) { VIEWERS.remove(id); continue; }
            GabrielEntity g = boss(p);
            if (g == null) { stop(p, "Gabriel is gone - leaving Camera Mode."); continue; }
            update(p, g);
        }
    }

    @SubscribeEvent
    public void onDimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer p && VIEWERS.contains(p.getUUID())) stop(p, null);
    }

    @SubscribeEvent
    public void onLogout(PlayerEvent.PlayerLoggedOutEvent e) { VIEWERS.remove(e.getEntity().getUUID()); }
}
