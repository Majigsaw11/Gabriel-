package com.ukgabriel;

import net.minecraftforge.common.ForgeConfigSpec;

import java.util.List;

/** config/ukgabriel-common.toml. Precedence: /ukgabriel tier <name> (saved in the world) > `tier` below > world difficulty. */
public final class UkGabrielConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.ConfigValue<String> TIER;
    public static final ForgeConfigSpec.DoubleValue PACE, PROJECTILE_SPEED, DAMAGE, ARMOR_CAP, PLAYER_DAMAGE, MOB_DAMAGE, PARRY_DAMAGE;
    public static final ForgeConfigSpec.IntValue MAX_PLAYER_HIT;
    public static final ForgeConfigSpec.BooleanValue ALT_SKIN;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.comment("Gabriel difficulty").push("difficulty");
        TIER = b.comment("Difficulty tier when no /ukgabriel tier override is set in the world.",
                "auto = follow world difficulty (Peaceful=harmless, Easy=lenient, Normal=standard, Hard=violent).")
                .defineInList("tier", "auto", List.of("auto", "harmless", "lenient", "standard", "violent", "brutal", "mob_battle"));
        PACE = b.comment("Multiplier on AI/cooldown speed (attack frequency, movement).").defineInRange("paceMultiplier", 1.0, 0.1, 5.0);
        PROJECTILE_SPEED = b.comment("Multiplier on projectile speed.").defineInRange("projectileSpeedMultiplier", 1.0, 0.1, 5.0);
        DAMAGE = b.comment("Multiplier on Gabriel's hit damage.").defineInRange("damageMultiplier", 1.0, 0.0, 10.0);
        ARMOR_CAP = b.comment("Multiplier on the max fraction of his health one hit can remove (higher = he takes more per hit).")
                .defineInRange("armorCapMultiplier", 1.0, 0.1, 10.0);
        b.pop();
        b.comment("Gabriel attack damage (applied to every hit he or his projectiles deal, after the tier scaling above)").push("damage");
        PLAYER_DAMAGE = b.comment("Multiplier on damage dealt to players. 0 = harmless.").defineInRange("playerDamageMultiplier", 1.0, 0.0, 20.0);
        MOB_DAMAGE = b.comment("Multiplier on damage dealt to mobs he targets.").defineInRange("mobDamageMultiplier", 1.0, 0.0, 20.0);
        MAX_PLAYER_HIT = b.comment("Max damage (half-hearts) of a single hit on a player. 0 = no cap.").defineInRange("maxPlayerHit", 0, 0, 1000);
        PARRY_DAMAGE = b.comment("Multiplier on damage a parried projectile deals back to Gabriel.").defineInRange("parryDamageMultiplier", 1.0, 0.0, 20.0);
        b.pop();
        b.comment("Visuals").push("visual");
        ALT_SKIN = b.comment("Use the alternate red/gold judge skin (judge_alt.png from Gaybriel.bbmodel) for Gabriel's main form.").define("alternateSkin", false);
        b.pop();
        SPEC = b.build();
    }

    private UkGabrielConfig() {}
}
