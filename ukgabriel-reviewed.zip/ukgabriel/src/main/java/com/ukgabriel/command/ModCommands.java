package com.ukgabriel.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.logging.LogUtils;
import com.ukgabriel.entity.EventTarget;
import com.ukgabriel.entity.GabrielEntity;
import com.ukgabriel.entity.GabrielScripts;
import com.ukgabriel.entity.Subtitles;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.commands.arguments.ResourceLocationArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.network.PacketDistributor;
import org.slf4j.Logger;

import java.util.HashSet;
import java.util.Set;

/**
 * /ukgabriel ... : the Java counterparts of the Bedrock-only commands/events used by Gabriel's timelines
 * (see tools/translate_commands.py). camera/hud/input are registered but not implemented yet (logged once).
 */
public final class ModCommands {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Set<String> WARNED = new HashSet<>();

    private static void todo(String what) {
        if (WARNED.add(what)) LOGGER.warn("Gabriel: /ukgabriel {} is not implemented yet", what);
    }

    @SubscribeEvent
    public void register(RegisterCommandsEvent e) {
        CommandDispatcher<CommandSourceStack> d = e.getDispatcher();
        d.register(Commands.literal("ukgabriel").requires(s -> s.hasPermission(2))
            .then(Commands.literal("event")
                .then(Commands.argument("targets", EntityArgument.entities())
                    .then(Commands.argument("event", ResourceLocationArgument.id()).executes(this::event))))
            .then(Commands.literal("particle")
                .then(Commands.argument("id", ResourceLocationArgument.id())
                    .then(Commands.argument("pos", Vec3Argument.vec3()).executes(this::particle))))
            .then(Commands.literal("sub")
                .then(Commands.argument("seconds", DoubleArgumentType.doubleArg(0))
                    .then(Commands.argument("text", StringArgumentType.greedyString()).executes(this::sub))))
            .then(Commands.literal("script")
                .then(Commands.argument("name", StringArgumentType.word())
                    .executes(c -> script(c, ""))
                    .then(Commands.argument("args", StringArgumentType.greedyString()).executes(c -> script(c, StringArgumentType.getString(c, "args"))))))
            .then(Commands.literal("summon")
                .then(Commands.argument("type", ResourceLocationArgument.id())
                    .then(Commands.argument("pos", Vec3Argument.vec3())
                        .then(Commands.argument("variant", ResourceLocationArgument.id()).executes(this::summon)))))
            .then(Commands.literal("tier")
                .executes(c -> tierShow(c))
                .then(Commands.argument("name", StringArgumentType.word())
                    .suggests((c, b) -> net.minecraft.commands.SharedSuggestionProvider.suggest(
                            java.util.Arrays.stream(com.ukgabriel.ai.GabrielTier.NAMES).map(n -> n.toLowerCase().replace(' ', '_')).toList(), b))
                    .executes(c -> tierSet(c))))
            .then(Commands.literal("camera").then(Commands.argument("targets", EntityArgument.players())
                .then(Commands.literal("clear").executes(c -> cutscene(c, ModNetwork.CutscenePacket.cameraClear())))
                .then(Commands.literal("free").then(Commands.argument("time", DoubleArgumentType.doubleArg(0))
                    .then(Commands.argument("ease", StringArgumentType.word())
                        .then(Commands.literal("pos").then(Commands.argument("pos", Vec3Argument.vec3())
                            .then(Commands.literal("facing").then(Commands.argument("facing", EntityArgument.entity()).executes(this::cameraFree))))))))
                .then(Commands.literal("fade").then(Commands.argument("in", DoubleArgumentType.doubleArg(0))
                    .then(Commands.argument("hold", DoubleArgumentType.doubleArg(0))
                        .then(Commands.argument("out", DoubleArgumentType.doubleArg(0))
                            .then(Commands.argument("r", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 255))
                                .then(Commands.argument("g", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 255))
                                    .then(Commands.argument("b", com.mojang.brigadier.arguments.IntegerArgumentType.integer(0, 255)).executes(this::cameraFade))))))))))
            .then(Commands.literal("hud").then(Commands.argument("targets", EntityArgument.players())
                .then(Commands.literal("hide").executes(c -> cutscene(c, ModNetwork.CutscenePacket.hud(true))))
                .then(Commands.literal("reset").executes(c -> cutscene(c, ModNetwork.CutscenePacket.hud(false))))))
            .then(Commands.literal("input").then(Commands.argument("targets", EntityArgument.players())
                .then(Commands.literal("movement")
                    .then(Commands.literal("enabled").executes(c -> cutscene(c, ModNetwork.CutscenePacket.input(false, true))))
                    .then(Commands.literal("disabled").executes(c -> cutscene(c, ModNetwork.CutscenePacket.input(false, false)))))
                .then(Commands.literal("camera")
                    .then(Commands.literal("enabled").executes(c -> cutscene(c, ModNetwork.CutscenePacket.input(true, true))))
                    .then(Commands.literal("disabled").executes(c -> cutscene(c, ModNetwork.CutscenePacket.input(true, false))))))));
    }

    private int event(CommandContext<CommandSourceStack> c) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        String ev = ResourceLocationArgument.getId(c, "event").toString();
        int n = 0;
        for (Entity t : EntityArgument.getEntities(c, "targets")) if (t instanceof EventTarget et) { et.fireEvent(ev); n++; }
        return n;
    }

    private int particle(CommandContext<CommandSourceStack> c) {
        String id = ResourceLocationArgument.getId(c, "id").toString();
        Vec3 p = Vec3Argument.getVec3(c, "pos");
        var level = c.getSource().getLevel();
        ModNetwork.particle(level, id, p.x, p.y, p.z);
        return 1;
    }

    private int sub(CommandContext<CommandSourceStack> c) {
        double secs = DoubleArgumentType.getDouble(c, "seconds");
        if (secs <= 0) return 0;
        Subtitles.show(c.getSource().getLevel(), c.getSource().getPosition(), StringArgumentType.getString(c, "text"), secs);
        return 1;
    }

    private int script(CommandContext<CommandSourceStack> c, String args) {
        return GabrielScripts.run(c.getSource(), StringArgumentType.getString(c, "name"), args) ? 1 : 0;
    }

    private int cutscene(CommandContext<CommandSourceStack> c, ModNetwork.CutscenePacket pkt) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        int n = 0;
        for (var p : EntityArgument.getPlayers(c, "targets")) { ModNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt); n++; }
        return n;
    }

    private int cameraFree(CommandContext<CommandSourceStack> c) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        Vec3 pos = Vec3Argument.getVec3(c, "pos");
        Entity facing = EntityArgument.getEntity(c, "facing");
        return cutscene(c, ModNetwork.CutscenePacket.cameraFree(pos.x, pos.y, pos.z, facing.getId(), DoubleArgumentType.getDouble(c, "time")));
    }

    private int cameraFade(CommandContext<CommandSourceStack> c) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        return cutscene(c, ModNetwork.CutscenePacket.fade(DoubleArgumentType.getDouble(c, "in"), DoubleArgumentType.getDouble(c, "hold"), DoubleArgumentType.getDouble(c, "out"),
                com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "r"), com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "g"),
                com.mojang.brigadier.arguments.IntegerArgumentType.getInteger(c, "b")));
    }

    private int tierShow(CommandContext<CommandSourceStack> c) {
        var t = com.ukgabriel.ai.TierData.current(c.getSource().getServer());
        c.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal("Gabriel difficulty tier: " + t.name()
                + " (set with /ukgabriel tier <harmless|lenient|standard|violent|brutal|mob_battle|default>)"), false);
        return t.index();
    }

    private int tierSet(CommandContext<CommandSourceStack> c) {
        String n = StringArgumentType.getString(c, "name");
        var server = c.getSource().getServer();
        if (n.equalsIgnoreCase("default")) { com.ukgabriel.ai.TierData.clear(server); return tierShow(c); }
        int i = com.ukgabriel.ai.GabrielTier.indexOf(n);
        if (i < 0) { c.getSource().sendFailure(net.minecraft.network.chat.Component.literal("Unknown tier " + n)); return 0; }
        com.ukgabriel.ai.TierData.set(server, i);
        return tierShow(c);
    }

    private int summon(CommandContext<CommandSourceStack> c) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
        var type = net.minecraftforge.registries.ForgeRegistries.ENTITY_TYPES.getValue(ResourceLocationArgument.getId(c, "type"));
        String variant = ResourceLocationArgument.getId(c, "variant").toString();
        Vec3 p = Vec3Argument.getVec3(c, "pos");
        var level = c.getSource().getLevel();
        if (type == null) { c.getSource().sendFailure(net.minecraft.network.chat.Component.literal("Unknown entity type")); return 0; }
        Entity e = type.create(level);
        if (e == null) return 0;
        var rot = c.getSource().getRotation();                     // Bedrock summon inherits the executing rotation
        e.moveTo(p.x, p.y, p.z, rot.y, rot.x);
        level.addFreshEntity(e);
        if (e instanceof EventTarget et) et.fireEvent(variant);
        return 1;
    }
}
