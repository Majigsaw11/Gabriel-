package com.ukgabriel.command;

import com.ukgabriel.UkGabrielMod;
import com.ukgabriel.client.BedrockParticles;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public final class ModNetwork {
    private ModNetwork() {}
    private static final String VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(UkGabrielMod.MODID, "main"), () -> VERSION, VERSION::equals, VERSION::equals);

    /** Send a Bedrock particle effect to every client within 160 blocks of the position. */
    public static void particle(net.minecraft.server.level.ServerLevel level, String id, double x, double y, double z) {
        CHANNEL.send(net.minecraftforge.network.PacketDistributor.NEAR.with(() ->
                new net.minecraftforge.network.PacketDistributor.TargetPoint(x, y, z, 160, level.dimension())), new ParticlePacket(id, x, y, z));
    }

    public static void init() {
        CHANNEL.registerMessage(0, ParticlePacket.class, ParticlePacket::encode, ParticlePacket::decode, ParticlePacket::handle);
        CHANNEL.registerMessage(1, MusicPacket.class, MusicPacket::encode, MusicPacket::decode, MusicPacket::handle);
        CHANNEL.registerMessage(2, CutscenePacket.class, CutscenePacket::encode, CutscenePacket::decode, CutscenePacket::handle);
    }

    /** Spawns a Bedrock-format particle effect (uk:* / gabriel:*) at a world position on the client. */
    public record ParticlePacket(String id, double x, double y, double z) {
        void encode(FriendlyByteBuf b) { b.writeUtf(id); b.writeDouble(x); b.writeDouble(y); b.writeDouble(z); }
        static ParticlePacket decode(FriendlyByteBuf b) { return new ParticlePacket(b.readUtf(), b.readDouble(), b.readDouble(), b.readDouble()); }
        void handle(Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> BedrockParticles.spawn(id, x, y, z)));
            ctx.setPacketHandled(true);
        }
    }

    /** Start looping Gabriel's music track (1..3) on this client, or stop it (0). */
    public record MusicPacket(int track) {
        void encode(FriendlyByteBuf b) { b.writeVarInt(track); }
        static MusicPacket decode(FriendlyByteBuf b) { return new MusicPacket(b.readVarInt()); }
        void handle(Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.ukgabriel.client.GabrielMusicClient.set(track)));
            ctx.setPacketHandled(true);
        }
    }

    /** Cutscene control for one client: camera (free/clear), fade, HUD visibility, input locks. */
    public record CutscenePacket(int kind, double x, double y, double z, double t1, double t2, double t3, int i1, int i2, int i3, int entity, boolean flag) {
        public static final int CAMERA_FREE = 0, CAMERA_CLEAR = 1, FADE = 2, HUD = 3, INPUT = 4;
        void encode(FriendlyByteBuf b) {
            b.writeVarInt(kind); b.writeDouble(x); b.writeDouble(y); b.writeDouble(z); b.writeDouble(t1); b.writeDouble(t2); b.writeDouble(t3);
            b.writeVarInt(i1); b.writeVarInt(i2); b.writeVarInt(i3); b.writeVarInt(entity); b.writeBoolean(flag);
        }
        static CutscenePacket decode(FriendlyByteBuf b) {
            return new CutscenePacket(b.readVarInt(), b.readDouble(), b.readDouble(), b.readDouble(), b.readDouble(), b.readDouble(), b.readDouble(),
                    b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readVarInt(), b.readBoolean());
        }
        void handle(Supplier<NetworkEvent.Context> sup) {
            NetworkEvent.Context ctx = sup.get();
            ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.ukgabriel.client.CutsceneClient.handle(this)));
            ctx.setPacketHandled(true);
        }
        public static CutscenePacket cameraFree(double x, double y, double z, int facing, double ease) { return new CutscenePacket(CAMERA_FREE, x, y, z, ease, 0, 0, 0, 0, 0, facing, false); }
        public static CutscenePacket cameraClear() { return new CutscenePacket(CAMERA_CLEAR, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, false); }
        public static CutscenePacket fade(double in, double hold, double out, int r, int g, int bl) { return new CutscenePacket(FADE, 0, 0, 0, in, hold, out, r, g, bl, -1, false); }
        public static CutscenePacket hud(boolean hidden) { return new CutscenePacket(HUD, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, hidden); }
        public static CutscenePacket input(boolean camera, boolean enabled) { return new CutscenePacket(INPUT, 0, 0, 0, 0, 0, 0, camera ? 1 : 0, 0, 0, -1, enabled); }
    }
}
