#!/usr/bin/env python3
"""Translate Gabriel's Bedrock timeline/controller/function commands into Java 1.20.1 commands.
Custom (mod) commands are namespaced under /ukgabriel and implemented in Java:
  event <targets> <event>                       entity events (set_property / component groups)
  particle <ns:id> <pos>                        Bedrock particle runtime (never vanilla substitution)
  summon <type> <pos> <variant_event>           summon using the executing rotation
  script <name> [args...]                       gabriel:ground|spiral|close|taunt|skip_aoh_intro ...
  sub <seconds> <text...>                       boss subtitle (action bar)
  camera <targets> free|fade|clear ...          cutscene camera / fades
  hud <targets> hide|reset                      hide / restore HUD
  input <targets> movement|camera enabled|disabled
"""
import json, re, sys, os, glob, collections, shutil

MOD = 'ukgabriel'
SRC = sys.argv[1]; OUT = sys.argv[2]
SEL = r'@[aepsrn](?:\[(?:[^\[\]{}]|\{[^{}]*\})*\])?'
VANILLA_PARTICLE = {'endrod': 'end_rod', 'totem_particle': 'totem_of_undying', 'large_explosion': 'explosion',
                    'huge_explosion_emitter': 'explosion_emitter'}
VANILLA_SOUND = {'random.explode': 'minecraft:entity.generic.explode'}
DAMAGE = {'entity_attack': 'minecraft:mob_attack', 'entity_explosion': 'minecraft:explosion'}
stats = collections.Counter(); unhandled = []

def split_args(s):
    out, depth, cur = [], 0, ''
    for ch in s:
        if ch in '{[': depth += 1
        if ch in '}]': depth -= 1
        if ch == ',' and depth == 0: out.append(cur); cur = ''
        else: cur += ch
    if cur: out.append(cur)
    return out

def sel(s):
    m = re.fullmatch(r'@([aepsrn])(?:\[(.*)\])?', s, re.S)
    if not m: raise ValueError('bad selector ' + s)
    kind, body = m.group(1), m.group(2) or ''
    args, rmax, rmin = [], None, None
    if kind == 'n':
        kind = 'e'; args += ['sort=nearest', 'limit=1']
    for a in split_args(body):
        k, _, v = a.partition('=')
        if k == 'r': rmax = re.sub(r'^\.+', '', v)
        elif k == 'rm': rmin = v
        elif k == 'm': args.append('gamemode=' + v)
        elif k == 'family':
            neg = v.startswith('!'); v = v.lstrip('!')
            args.append('type=' + ('!' if neg else '') + f'#{MOD}:family/{v}')
        elif k == 'type':
            neg = v.startswith('!'); v = v.lstrip('!')
            v = 'minecraft:player' if v == 'player' else (v.replace('gabriel:', f'{MOD}:') if v.startswith('gabriel:') else v)
            args.append('type=' + ('!' if neg else '') + v)
        elif k == 'has_property':
            mm = re.fullmatch(r'\{gabriel:(\w+)=(\d+)\}', v)
            if not mm: raise ValueError('property filter ' + a)
            args.append('nbt={Gab%s:%s}' % (mm.group(1).capitalize(), mm.group(2)))
        elif k == 'tag': args.append(a)
        else: raise ValueError('selector arg ' + a)
    if rmax is not None or rmin is not None:
        args.append('distance=' + (rmin or '') + ('..' + rmax if rmax is not None else '..'))
    return '@' + kind + ('[' + ','.join(args) + ']' if args else '')

def sels(text):
    return re.sub(SEL, lambda m: sel(m.group(0)), text)

def tr(cmd):
    c = cmd.strip()
    if c.startswith('/'): c = c[1:]
    # event shorthand used by controller on_entry: "@s gabriel:evt"
    m = re.fullmatch(r'(' + SEL + r') (gabriel:\w+)', c)
    if m: stats['event'] += 1; return f'{MOD} event {sel(m.group(1))} {m.group(2)}'
    verb = c.split(' ', 1)[0]
    rest = c[len(verb):].strip()
    if verb == 'execute':
        i = c.find(' run ')
        if i < 0: raise ValueError('execute without run')
        chain, sub = c[len('execute '):i], c[i + 5:]
        stats['execute'] += 1
        return 'execute ' + sels(chain) + ' run ' + tr(sub)
    if verb == 'tp':
        m = re.fullmatch(r'(' + SEL + r') (' + SEL + r')', rest)
        if m: stats['tp'] += 1; return f'tp {sel(m.group(1))} {sel(m.group(2))}'
        m = re.fullmatch(r'(' + SEL + r') (\S+ \S+ \S+)(?: facing (' + SEL + r')(?: true)?)?', rest)
        if m:
            stats['tp'] += 1
            face = f' facing entity {sel(m.group(3))} feet' if m.group(3) else ''
            return f'tp {sel(m.group(1))} {m.group(2)}{face}'
    if verb == 'particle':
        m = re.fullmatch(r'(\S+) (\S+ \S+ \S+)', rest)
        if m:
            pid, pos = m.groups(); stats['particle'] += 1
            if pid.startswith('minecraft:'):
                n = pid[10:]
                if n not in VANILLA_PARTICLE: raise ValueError('vanilla particle ' + pid)
                stats['particle_vanilla'] += 1
                return f'particle minecraft:{VANILLA_PARTICLE[n]} {pos}'
            stats['particle_bedrock'] += 1
            return f'{MOD} particle {pid} {pos}'
    if verb == 'playsound':
        m = re.fullmatch(r'(\S+) (' + SEL + r')(?: (.*))?', rest)
        if m:
            snd, tgt, tail = m.groups(); stats['playsound'] += 1
            if snd in VANILLA_SOUND: s, cat = VANILLA_SOUND[snd], 'hostile'
            else: s, cat = f'{MOD}:{snd}', 'hostile'
            return f'playsound {s} {cat} {sel(tgt)}' + (' ' + tail if tail else '')
    if verb == 'damage':
        m = re.fullmatch(r'(' + SEL + r') (\d+) (\w+) entity (' + SEL + r')', rest)
        if m and m.group(3) in DAMAGE:
            stats['damage'] += 1
            return f'damage {sel(m.group(1))} {m.group(2)} {DAMAGE[m.group(3)]} by {sel(m.group(4))}'
    if verb == 'tag':
        m = re.fullmatch(r'(' + SEL + r') (add|remove) (\S+)', rest)
        if m: stats['tag'] += 1; return f'tag {sel(m.group(1))} {m.group(2)} {m.group(3)}'
    if verb == 'effect':
        m = re.fullmatch(r'(' + SEL + r') (\w+) (\d+) (\d+) (true|false)', rest)
        if m: stats['effect'] += 1; return f'effect give {sel(m.group(1))} minecraft:{m.group(2)} {m.group(3)} {m.group(4)} {m.group(5)}'
    if verb == 'summon':
        m = re.fullmatch(r'gabriel:(\w+) (\S+ \S+ \S+) \S+ \S+ gabriel:(\w+)', rest)
        if m: stats['summon'] += 1; return f'{MOD} summon {MOD}:{m.group(1)} {m.group(2)} gabriel:{m.group(3)}'
    if verb == 'event':
        m = re.fullmatch(r'entity (' + SEL + r') (gabriel:\w+)', rest)
        if m: stats['event'] += 1; return f'{MOD} event {sel(m.group(1))} {m.group(2)}'
    if verb == 'scriptevent':
        sid, _, msg = rest.partition(' ')
        if sid == 'gabriel:sub':
            secs, _, text = msg.partition('|'); stats['sub'] += 1
            return f'{MOD} sub {secs} {text}'
        stats['script'] += 1
        return f'{MOD} script {sid.split(":",1)[1]}' + (f' {msg}' if msg else '')
    if verb == 'camera':
        m = re.fullmatch(r'(' + SEL + r') set minecraft:free ease (\S+) (\S+) pos (\S+ \S+ \S+) facing (' + SEL + r')', rest)
        if m: stats['camera'] += 1; return f'{MOD} camera {sel(m.group(1))} free {m.group(2)} {m.group(3)} pos {m.group(4)} facing {sel(m.group(5))}'
        m = re.fullmatch(r'(' + SEL + r') fade time (\S+) (\S+) (\S+) color (\d+) (\d+) (\d+)', rest)
        if m: stats['camera'] += 1; return f'{MOD} camera {sel(m.group(1))} fade {m.group(2)} {m.group(3)} {m.group(4)} {m.group(5)} {m.group(6)} {m.group(7)}'
        m = re.fullmatch(r'(' + SEL + r') clear', rest)
        if m: stats['camera'] += 1; return f'{MOD} camera {sel(m.group(1))} clear'
    if verb == 'hud':
        m = re.fullmatch(r'(' + SEL + r') (hide|reset) all', rest)
        if m: stats['hud'] += 1; return f'{MOD} hud {sel(m.group(1))} {m.group(2)}'
    if verb == 'inputpermission':
        m = re.fullmatch(r'set (' + SEL + r') (movement|camera) (enabled|disabled)', rest)
        if m: stats['input'] += 1; return f'{MOD} input {sel(m.group(1))} {m.group(2)} {m.group(3)}'
    if verb == 'title':
        m = re.fullmatch(r'(' + SEL + r') times (\d+) (\d+) (\d+)', rest)
        if m: stats['title'] += 1; return f'title {sel(m.group(1))} times {m.group(2)} {m.group(3)} {m.group(4)}'
    if verb == 'titleraw':
        m = re.fullmatch(r'(' + SEL + r') (title|subtitle) (\{.*\})', rest)
        if m:
            raw = json.loads(m.group(3)); txt = ''.join(p['text'] for p in raw['rawtext'])
            stats['title'] += 1
            return f'title {sel(m.group(1))} {m.group(2)} ' + json.dumps({'text': txt})
    if verb == 'function':
        stats['function'] += 1; return f'function {MOD}:{rest}'
    raise ValueError('unhandled command: ' + cmd)

def safe(cmd):
    try: return tr(cmd)
    except Exception as e:
        unhandled.append((cmd, str(e))); return None

# --- run over every source -------------------------------------------------
bp = json.load(open(f'{SRC}/UK BP/animations/gabriel_ai.animation.json'))['animations']
timelines, total = {}, 0
for name, a in bp.items():
    tl = {}
    for t, cmds in a.get('timeline', {}).items():
        out = []
        for c in (cmds if isinstance(cmds, list) else [cmds]):
            total += 1; r = safe(c)
            if r is not None: out.append(r)
        tl[t] = out
    timelines[name] = {'animation_length': a.get('animation_length'), 'loop': a.get('loop'), 'timeline': tl}
ctl = json.load(open(f'{SRC}/../ukgabriel/src/main/resources/assets/{MOD}/animation_controllers/gabriel_ai.controllers.json')) if False else \
      json.load(open(f'{OUT}/src/main/resources/assets/{MOD}/animation_controllers/gabriel_ai.controllers.json'))
for cn, c in ctl['animation_controllers'].items():
    for sn, s in c['states'].items():
        if 'on_entry' in s:
            new = []
            for x in s['on_entry']:
                total += 1; r = safe(x)
                if r is not None: new.append(r)
            s['on_entry'] = new
D = f'{OUT}/src/main/resources/data/{MOD}'
os.makedirs(f'{D}/ai', exist_ok=True)
json.dump(timelines, open(f'{D}/ai/timelines.json', 'w'), indent=1)
json.dump(ctl, open(f'{D}/ai/controllers.json', 'w'), indent=1)
os.makedirs(f'{D}/functions/gabriel', exist_ok=True)
nfun = 0
for f in sorted(glob.glob(f'{SRC}/UK BP/functions/gabriel/*.mcfunction')):
    lines = []
    for line in open(f, encoding='utf-8'):
        line = line.strip()
        if not line or line.startswith('#'): continue
        total += 1; r = safe(line)
        if r is not None: lines.append(r)
    open(f'{D}/functions/gabriel/{os.path.basename(f)}', 'w').write('\n'.join(lines) + '\n'); nfun += 1


# --- entity events (BP) with queue_command translated ---------------------------------
ent = json.load(open(f'{SRC}/UK BP/entities/gabriel.entity.json'))['minecraft:entity']
tests = collections.Counter()
def conv(o):
    global total
    if isinstance(o, dict):
        r = {}
        for k, v in o.items():
            if k == 'command':
                new = []
                for x in v:
                    total += 1; t = safe(x)
                    if t is not None: new.append(t)
                r[k] = new
            else:
                if k == 'test': tests[v] += 1
                r[k] = conv(v)
        return r
    if isinstance(o, list): return [conv(x) for x in o]
    return o
events = conv(ent['events'])
json.dump({'events': events, 'component_groups': ent['component_groups'],
           'properties': ent['description']['properties'],
           'animations': ent['description'].get('animations', {})}, open(f'{D}/ai/entity.json', 'w'), indent=1)
print('event filter tests used:', dict(tests))


# --- projectile entities (BP): events/groups/timer/damage_sensor, commands translated -------------------------------
os.makedirs(f'{D}/ai/entities', exist_ok=True)
for name in ['sword_beam','sword_throw','light_axe','light_greatsword','spiral_sword','spiral_swords','orbit_sensor']:
    e = json.load(open(f'{SRC}/UK BP/entities/{name}.entity.json'))['minecraft:entity']
    comps = e['components']
    timer = comps.get('minecraft:timer')
    out = {
        'identifier': e['description']['identifier'],
        'animations': e['description'].get('animations', {}),
        'animate': e['description'].get('scripts', {}).get('animate', []),
        'component_groups': e.get('component_groups', {}),
        'events': conv(e.get('events', {})),
        'timer': {'seconds': timer['time'], 'event': timer['time_down_event']['event']} if timer else None,
        'parry_sensor': 'minecraft:damage_sensor' in comps,
        'collision': comps.get('minecraft:collision_box'),
    }
    json.dump(out, open(f'{D}/ai/entities/{name}.json', 'w'), indent=1)
    shutil.copyfile(f'{SRC}/UltrakillRP/entity/{name}.entity.json', f'{OUT}/src/main/resources/assets/{MOD}/client_entity/{name}.entity.json')
print('projectile entity files written')

# --- entity type tags for Bedrock families ---------------------------------
tags = {
 'gabriel': [f'{MOD}:gabriel'],
 'gabriel_projectile': [f'{MOD}:{n}' for n in ['light_axe','light_greatsword','orbit_sensor','spiral_sword','spiral_swords','sword_beam','sword_throw']],
 'inanimate': ['minecraft:armor_stand','minecraft:item','minecraft:item_frame','minecraft:glow_item_frame','minecraft:painting','minecraft:boat','minecraft:chest_boat','minecraft:minecart','minecraft:chest_minecart','minecraft:furnace_minecart','minecraft:hopper_minecart','minecraft:tnt_minecart','minecraft:command_block_minecart','minecraft:spawner_minecart','minecraft:tnt','minecraft:falling_block','minecraft:experience_orb','minecraft:end_crystal','minecraft:marker','minecraft:area_effect_cloud','minecraft:text_display','minecraft:item_display','minecraft:block_display','minecraft:interaction','minecraft:lightning_bolt'],
 'sam': [],
}
os.makedirs(f'{D}/tags/entity_types/family', exist_ok=True)
for k, v in tags.items():
    json.dump({'replace': False, 'values': v}, open(f'{D}/tags/entity_types/family/{k}.json', 'w'), indent=1)

# --- lint: no Bedrock-only syntax may survive ------------------------------
bad = re.compile(r'@n\b|\bfamily=|[\[,]r=|[\[,]rm=|[\[,]m=|has_property|rawtext|entity_attack|entity_explosion')
allout = [c for t in timelines.values() for l in t['timeline'].values() for c in l]
allout += [x for c in ctl['animation_controllers'].values() for s in c['states'].values() for x in s.get('on_entry', [])]
for f in glob.glob(f'{D}/functions/gabriel/*'): allout += open(f).read().split('\n')
leaks = [c for c in allout if c and bad.search(c.replace('ukgabriel:family','')) ]
ok_roots = ('execute','tp','particle','playsound','damage','tag','effect','title','function',MOD)
badroot = []
for c in allout:
    if not c: continue
    r = c
    while r.startswith('execute '): r = r[r.find(' run ')+5:]
    if not r.startswith(ok_roots): badroot.append(c)
print('commands total', total, '| translated', total - len(unhandled), '| unhandled', len(unhandled))
for c, e in unhandled[:20]: print('  UNHANDLED', c[:120], '->', e)
print('by kind', dict(stats))
print('lint leaks', len(leaks), leaks[:5]); print('bad roots', len(badroot), badroot[:5])
print('functions written', nfun, '| timelines', len(timelines))
