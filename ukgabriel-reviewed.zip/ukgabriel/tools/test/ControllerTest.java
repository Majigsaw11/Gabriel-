import com.ukgabriel.bedrock.BedrockController;
import com.ukgabriel.bedrock.molang.Molang;
import java.nio.file.*;
import java.util.*;

public class ControllerTest {
    static int fails = 0;
    static void check(boolean ok, String m) { if (!ok) { fails++; System.out.println("FAIL: " + m); } }
    public static void main(String[] a) throws Exception {
        for (String file : new String[]{"gabriel.animation_controllers.json", "gabriel_ai.controllers.json"}) {
            Map<String, BedrockController> cs = BedrockController.parse(ParticleCoreTest.parse(Files.readString(Path.of(a[0], file))));
            for (BedrockController c : cs.values()) {
                int anim[] = {0}; double[] speed = {0};
                Molang.Scope sc = new Molang.Scope() {
                    public double get(String n) { return n.equals("q.modified_move_speed") ? speed[0] : 0; }
                    public double query(String n, String arg) { return n.equals("property") && "gabriel:anim".equals(arg) ? anim[0] : 0; }
                };
                Set<String> reached = new TreeSet<>();
                for (int v = 0; v <= 60; v++) { anim[0] = v; c.reset(); c.update(sc, 0.05); reached.add(c.current().name); }
                speed[0] = 0.3; anim[0] = 0; c.reset(); c.update(sc, 0.05); reached.add(c.current().name);
                Set<String> missing = new TreeSet<>(c.states.keySet()); missing.removeAll(reached);
                System.out.printf("%-38s states=%2d reachable-by-anim-value=%2d unreachable=%s%n", c.id, c.states.size(), reached.size(), missing);
            }
            // spot checks on the RP controllers
            if (file.startsWith("gabriel.anim")) {
                BedrockController combat = cs.get("controller.animation.gabriel.combat"), joh = cs.get("controller.animation.gabriel.joh");
                int[] anim = {35}; double[] sp = {0};
                Molang.Scope sc = new Molang.Scope() {
                    public double get(String n) { return n.equals("q.modified_move_speed") ? sp[0] : 0; }
                    public double query(String n, String arg) { return anim[0]; }
                };
                combat.reset(); combat.update(sc, 0.05);
                check(combat.current().name.equals("v35") && combat.current().animations.equals(List.of("idle", "aoh_intro")), "combat anim 35 -> idle+aoh_intro, got " + combat.current().animations);
                anim[0] = 0; combat.update(sc, 0.05); check(combat.current().name.equals("idle"), "combat back to idle");
                sp[0] = 0.5; combat.update(sc, 0.05); check(combat.current().name.equals("walk"), "combat walk on move speed");
                anim[0] = 36; joh.update(sc, 0.05); check(joh.current().animations.equals(List.of("j_intro")), "joh 36 -> j_intro");
                anim[0] = 46; joh.update(sc, 0.05);
                joh.update(sc, 0.05); check(joh.current().animations.equals(List.of("j_outro")), "joh 46 -> j_outro (was in intro, goes idle then outro)");
            }
        }
        System.out.println("controller checks done; failures=" + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
