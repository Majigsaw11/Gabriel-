import com.ukgabriel.bedrock.RpAnimator;
import java.nio.file.*;
import java.util.*;

public class RpAnimatorTest {
    static int fails = 0;
    static void check(boolean ok, String m) { if (!ok) { fails++; System.out.println("FAIL: " + m); } }
    @SuppressWarnings("unchecked")
    public static void main(String[] a) throws Exception {
        Path assets = Path.of(a[0]);
        Object ctl = ParticleCoreTest.parse(Files.readString(assets.resolve("animation_controllers/gabriel.animation_controllers.json")));
        Object ent = ParticleCoreTest.parse(Files.readString(assets.resolve("client_entity/gabriel.entity.json")));
        Map<String, Object> merged = (Map<String, Object>) ((Map<String, Object>) ParticleCoreTest.parse(Files.readString(assets.resolve("animations/gabriel_all.animation.json")))).get("animations");
        int[] form = {0}, anim = {0}, enrage = {0}, defeat = {0};
        RpAnimator.Props props = n -> switch (n) {
            case "gabriel:form" -> form[0]; case "gabriel:anim" -> anim[0]; case "gabriel:enrage" -> enrage[0]; case "gabriel:defeat" -> defeat[0];
            default -> throw new IllegalStateException(n); };
        Set<String> used = new TreeSet<>();
        for (int f = 0; f <= 1; f++) {
            RpAnimator an = new RpAnimator(ctl, ent);
            form[0] = f;
            for (int v = 0; v <= 60; v++) {
                anim[0] = v; an.tick(props, 0.05); an.tick(props, 0.05);
                for (String id : an.active()) { used.add(id); check(merged.containsKey(id), "form " + f + " anim " + v + " -> missing animation " + id); }
                check(!an.active().isEmpty(), "form " + f + " anim " + v + " plays nothing");
            }
        }
        RpAnimator an = new RpAnimator(ctl, ent);
        form[0] = 0; anim[0] = 36; an.tick(props, 0.05);
        check(an.active().equals(List.of("animation.gabriel_ultrakill.judge_intro")), "judge intro, got " + an.active());
        anim[0] = 0; enrage[0] = 1; defeat[0] = 0; an.tick(props, 0.05);
        check(an.active().contains("animation.gabriel.enrage_ring"), "enrage ring when enraged: " + an.active());
        defeat[0] = 1; an.tick(props, 0.05);
        check(!an.active().contains("animation.gabriel.enrage_ring"), "no ring during defeat");
        check("gabriel:enrage_ring".equals(an.particleFor("ring")), "ring particle mapping");
        Set<String> never = new TreeSet<>(merged.keySet()); never.removeAll(used);
        System.out.println("distinct animations reachable via gabriel:anim: " + used.size() + " of " + merged.size());
        System.out.println("animations only reachable by other means (legacy model / projectiles / ring): " + never);
        System.out.println("RpAnimator checks done; failures=" + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
