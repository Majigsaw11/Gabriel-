import com.ukgabriel.ai.FlightMath;
import static com.ukgabriel.ai.FlightMath.*;

public class FlightTest {
    static int fails = 0;
    static void check(boolean ok, String m) { if (!ok) { fails++; System.out.println("FAIL: " + m); } }
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-6; }
    public static void main(String[] x) {
        check(KINDS.size() == 4 && KINDS.get("sword_throw").life() == 600 && KINDS.get("sword_beam").speed()[3] == 6.0 && KINDS.get("sword_throw").parry() == 80, "kind table");
        double[] z = norm(new double[]{0, 0, 0});
        check(z[0] == 0 && z[1] == 0 && z[2] == 0, "norm of zero vector stays zero");
        double[] d = {1, 0, 0}, want = {0, 0, 1};
        double[] s = steer(d, want, 14);
        // projectiles.js blends vectors linearly then normalizes: t = 14/90, angle = atan(t/(1-t)) (~10.44 deg), never above the limit
        double t = 14.0 / 90.0;
        check(near(angleBetween(d, s), Math.toDegrees(Math.atan(t / (1 - t)))) && angleBetween(d, s) <= 14 && near(len(s), 1), "steer blend matches projectiles.js: " + angleBetween(d, s));
        check(steer(d, new double[]{Math.cos(0.1), 0, Math.sin(0.1)}, 14)[2] > 0.09, "steer snaps when within limit");
        // turn rates (players vs mobs)
        Kind beam = KINDS.get("sword_beam"), thr = KINDS.get("sword_throw"), axe = KINDS.get("light_axe");
        check(turnRate(beam, true) == 0 && turnRate(beam, false) == 4, "beam turn: none at players, 4 at mobs");
        check(turnRate(thr, true) == 1.6 && turnRate(thr, false) == 6, "throw turn");
        check(turnRate(axe, true) == 1.8 && turnRate(axe, false) == 5, "axe turn");
        // sub-stepping
        check(steps(3.752) == 6 && steps(0.5) == 1 && steps(6.0) == 8 && steps(0.75) == 1, "steps");
        // aim lead: target moving +x at 0.2/tick, projectile 20 blocks away at speed 2 -> 10 ticks of lead
        double[] dir = leadAim(new double[]{0, 0, 0}, new double[]{0, 0, 20}, 0, new double[]{0.2, 0, 0}, 2);
        check(near(dir[0], 2 / Math.sqrt(4 + 400)) && dir[2] > 0.99, "lead aim " + java.util.Arrays.toString(dir));
        double[] far = leadAim(new double[]{0, 0, 0}, new double[]{0, 0, 400}, 0, new double[]{1, 0, 0}, 1);
        check(near(far[0], 40 / Math.hypot(40, 400)), "lead capped at 40 ticks");
        // body test
        double[] b = bodyOf(64, 65.62);
        check(near(b[1], 1.62) && near(b[2], 64 + 1.62 * 0.55), "bodyOf");
        check(pointHitsBody(new double[]{1.9, 65, 0}, 0, 64, 0, 1.62) && !pointHitsBody(new double[]{2.1, 65, 0}, 0, 64, 0, 1.62), "horizontal hit radius 2.0");
        check(pointHitsBody(new double[]{0, 63.7, 0}, 0, 64, 0, 1.62) && !pointHitsBody(new double[]{0, 63.5, 0}, 0, 64, 0, 1.62), "vertical lower bound feet-0.4");
        check(pointHitsBody(new double[]{0, 66.0, 0}, 0, 64, 0, 1.62) && !pointHitsBody(new double[]{0, 66.1, 0}, 0, 64, 0, 1.62), "vertical upper bound head+0.4");
        System.out.println("flight maths checks done; failures=" + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
