import com.ukgabriel.bedrock.particle.BillboardMath;
import com.ukgabriel.bedrock.particle.ParticleDef.Facing;

public class BillboardTest {
    static int fails = 0;
    static void check(boolean ok, String m) { if (!ok) { fails++; System.out.println("FAIL: " + m); } }
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-6; }
    static double dot(double[] a, double[] b) { return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]; }
    static double[] sub(double[] c, int i, int j) { return new double[]{c[i*3]-c[j*3], c[i*3+1]-c[j*3+1], c[i*3+2]-c[j*3+2]}; }
    static double len(double[] a) { return Math.sqrt(dot(a, a)); }
    static double[] cross(double[] a, double[] b) { return new double[]{a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]}; }

    public static void main(String[] x) {
        double[] out = new double[12];
        double[] right = {1, 0, 0}, up = {0, 1, 0}, toCam = {3, 2, 5}, dir = {0, 0, 0};
        for (Facing f : Facing.values()) {
            for (double spin : new double[]{0, 0.7}) {
                double[] d = f.name().startsWith("DIRECTION") ? new double[]{0.4, 1.5, -0.3} : dir;
                BillboardMath.corners(f, 0.5, 0.25, spin, toCam, right, up, d, 0.01, out);
                double[] w = sub(out, 3, 0), h = sub(out, 1, 0);   // BL->BR (width), BL->TL (height)
                double[] ww = sub(out, 3, 0), hh = sub(out, 1, 0);
                check(near(len(sub(out, 2, 1)), 1.0) && near(len(sub(out, 1, 0)), 0.5), f + " extents (half 0.5/0.25 -> 1.0 x 0.5), got " + len(sub(out,2,1)) + " x " + len(sub(out,1,0)));
                check(near(dot(ww, hh), 0), f + " quad not rectangular");
                double[] n = cross(sub(out, 2, 1), sub(out, 1, 0));
                if (!f.name().equals("DIRECTION_Z")) check(Math.abs(dot(n, toCam)) / (len(n) * len(toCam)) > 0.05, f + " quad edge-on to camera");
            }
        }
        // exact cases
        BillboardMath.corners(Facing.ROTATE_XYZ, 1, 2, 0, toCam, right, up, dir, 0.01, out);
        check(near(out[0], -1) && near(out[1], -2) && near(out[3], -1) && near(out[4], 2) && near(out[6], 1) && near(out[7], 2), "rotate_xyz corners");
        BillboardMath.corners(Facing.LOOKAT_XYZ, 1, 1, 0, new double[]{0, 0, 5}, right, up, dir, 0.01, out);
        check(near(out[0], -1) && near(out[1], -1) && near(out[2], 0), "lookat_xyz facing +z gives an XY quad");
        BillboardMath.corners(Facing.DIRECTION_Y, 0.2, 1, 0, new double[]{0, 0, 5}, right, up, new double[]{0, 0, 2}, 0.01, out);
        double[] axis = sub(out, 1, 0);                                  // BL->TL must follow the velocity direction (+z)
        check(near(axis[0], 0) && near(axis[1], 0) && near(axis[2], 2), "direction_y: quad height follows velocity, got " + java.util.Arrays.toString(axis));
        BillboardMath.corners(Facing.DIRECTION_Y, 0.2, 1, 0, new double[]{0, 0, 5}, right, up, new double[]{0, 0, 0}, 0.01, out);
        axis = sub(out, 1, 0);
        check(near(axis[1], 2), "direction_y below min speed falls back to world up");
        BillboardMath.corners(Facing.ROTATE_Y, 1, 1, 0, toCam, new double[]{0.6, 0.5, 0.2}, new double[]{0, 1, 0}, dir, 0.01, out);
        check(near(out[1], -1) && near(out[4], 1), "rotate_y keeps the quad vertical");
        System.out.println("billboard checks done; failures=" + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
