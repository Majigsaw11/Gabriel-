import com.ukgabriel.bedrock.*;
import java.nio.file.*;
import java.util.*;

public class ProjectileTest implements BrainRuntime.Host {
    static int fails = 0;
    static void check(boolean ok, String m) { if (!ok) { fails++; System.out.println("FAIL: " + m); } }

    int variant; boolean despawned; List<String> cmds = new ArrayList<>(); Set<String> tags = new HashSet<>();
    Map<String, Object> groups; BedrockEvents events;
    public int prop(String n) { return 0; } public void setProp(String n, int v) { }
    public void removeGroup(String g) { }
    public double random() { return 0.5; } public double health() { return 1; } public double maxHealth() { return 1; }
    public int markVariant() { return variant; }
    @SuppressWarnings("unchecked")
    public void addGroup(String g) {
        Map<String, Object> grp = (Map<String, Object>) groups.get(g);
        if (grp == null) return;
        if (grp.containsKey("minecraft:mark_variant")) variant = ((Number) ((Map<String, Object>) grp.get("minecraft:mark_variant")).get("value")).intValue();
        if (grp.containsKey("minecraft:instant_despawn")) despawned = true;
    }
    public void command(String c) {
        cmds.add(c);
        if (c.startsWith("ukgabriel event @s ")) events.fire(c.substring(19), this);
        if (c.equals("tag @s add gparry")) tags.add("gparry");
        if (c.equals("tag @s add gdone")) tags.add("gdone");
    }

    @SuppressWarnings("unchecked")
    public static void main(String[] a) throws Exception {
        Path res = Path.of(a[0]);
        Map<String, BedrockController> ctls = BedrockController.parse(ParticleCoreTest.parse(Files.readString(res.resolve("ai/controllers.json"))));
        Map<String, Timeline> tls = Timeline.parse(ParticleCoreTest.parse(Files.readString(res.resolve("ai/timelines.json"))));
        String[] kinds = {"sword_beam", "sword_throw", "light_axe", "light_greatsword", "spiral_sword", "spiral_swords", "orbit_sensor"};
        Map<String, Double> expectTimer = Map.of("sword_beam", 8.0, "sword_throw", 30.0, "light_axe", 8.0, "light_greatsword", 8.0, "spiral_sword", 8.0, "spiral_swords", 5.2, "orbit_sensor", 8.0);
        for (String k : kinds) {
            Map<String, Object> d = (Map<String, Object>) ParticleCoreTest.parse(Files.readString(res.resolve("ai/entities/" + k + ".json")));
            ProjectileTest h = new ProjectileTest();
            h.groups = (Map<String, Object>) d.get("component_groups");
            h.events = new BedrockEvents((Map<String, Object>) d.get("events"));
            Map<String, Object> timer = (Map<String, Object>) d.get("timer");
            check(timer != null && ((Number) timer.get("seconds")).doubleValue() == expectTimer.get(k), k + " timer " + timer);
            // flying projectiles: variants 1..4, parry tagging, expire -> end function, despawn
            if (d.get("parry_sensor").equals(Boolean.TRUE)) {
                for (int v = 1; v <= 4; v++) { h.events.fire("gabriel:v" + v, h); check(h.variant == v, k + " variant " + v); }
                h.events.fire("gabriel:parry", h);
                check(h.tags.contains("gparry"), k + " parry tags gparry");
                h.events.fire("gabriel:expire", h);
                check(h.cmds.contains("function ukgabriel:gabriel/end_" + k), k + " expire runs end function, cmds=" + h.cmds);
                // the end function marks gdone then despawns
                ProjectileTest h2 = new ProjectileTest(); h2.groups = h.groups; h2.events = h.events;
                h2.events.fire("gabriel:despawn", h2); check(h2.despawned, k + " despawn removes entity");
            } else {
                h.events.fire("gabriel:despawn", h); check(h.despawned, k + " despawn");
            }
        }
        // ring entity: orbit event -> controller enters 'orbit' and plays follow (every tick) + hit (every 0.6 s) timelines
        Map<String, Object> d = (Map<String, Object>) ParticleCoreTest.parse(Files.readString(res.resolve("ai/entities/spiral_swords.entity.json".replace(".entity", ""))));
        ProjectileTest r = new ProjectileTest();
        r.groups = (Map<String, Object>) d.get("component_groups");
        r.events = new BedrockEvents((Map<String, Object>) d.get("events"));
        Map<String, String> aliases = new HashMap<>();
        for (Map.Entry<String, Object> e : ((Map<String, Object>) d.get("animations")).entrySet()) aliases.put(e.getKey(), (String) e.getValue());
        BrainRuntime br = new BrainRuntime(r, ctls, tls, aliases, List.of("ctl"));
        for (int t = 0; t < 5; t++) br.tick(0.05);
        check(br.stateOf("ctl").equals("default") && r.cmds.isEmpty(), "ring idle before orbit");
        r.events.fire("gabriel:orbit", r);
        check(r.variant == 1 && r.tags.isEmpty(), "orbit sets mark_variant 1");
        int before = r.cmds.size();
        for (int t = 0; t < 60; t++) br.tick(0.05);
        long follows = r.cmds.stream().skip(before).filter(c -> c.contains("tp @s ~ ~0.2 ~")).count();
        long hits = r.cmds.stream().skip(before).filter(c -> c.contains("damage @a[")).count();
        check(br.stateOf("ctl").equals("orbit"), "ring controller in orbit state: " + br.stateOf("ctl"));
        check(follows >= 58 && follows <= 61, "ring follows the boss every tick: " + follows);
        check(hits >= 4 && hits <= 6, "ring damages every 0.6s (5 times in 3s): " + hits);
        System.out.println("projectile entity checks done; failures=" + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
