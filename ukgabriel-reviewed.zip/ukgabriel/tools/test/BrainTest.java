import com.ukgabriel.bedrock.*;
import java.nio.file.*;
import java.util.*;
import java.util.regex.*;

public class BrainTest implements BrainRuntime.Host {
    static final double DT = 0.05;
    Map<String, Integer> props = new LinkedHashMap<>();
    Map<String, int[]> ranges = new HashMap<>();
    Set<String> tags = new HashSet<>(), groups = new HashSet<>();
    double hp = 1000, max = 1000;
    boolean playerNear = true;
    Random rng = new Random(Long.getLong("seed", 7L));
    int tick;
    BedrockEvents events;
    record Rec(int tick, String cmd) {}
    List<Rec> log = new ArrayList<>();
    static int fails = 0;
    static void check(boolean ok, String m) { if (!ok) { fails++; System.out.println("FAIL: " + m); } }

    public int prop(String n) { Integer v = props.get(n); if (v == null) throw new IllegalStateException("unknown prop " + n); return v; }
    public void setProp(String n, int v) {
        int[] r = ranges.get(n);
        check(r != null && v >= r[0] && v <= r[1], "property " + n + "=" + v + " outside range");
        props.put(n, v);
    }
    public void addGroup(String g) {
        groups.add(g);
        switch (g) { case "gabriel:hp_joh" -> { max = hp = 1000; } case "gabriel:hp_aoh" -> { max = hp = 1500; } default -> { } }
    }
    public void removeGroup(String g) { groups.remove(g); }
    public double random() { return rng.nextDouble(); }
    public double health() { return hp; }
    public double maxHealth() { return max; }
    static final Pattern IF_TAG = Pattern.compile("execute if entity @s\\[tag=(!?)(\\w+)\\] run (.*)");
    static final Pattern IF_FORM = Pattern.compile("execute if entity @s\\[nbt=\\{GabForm:(\\d)\\}\\] run (.*)");
    static final Pattern IF_NEAR = Pattern.compile("execute if entity @[ae]\\[.*\\] run tag @s add g_close");
    public void command(String c) {
        log.add(new Rec(tick, c));
        if (c.startsWith("ukgabriel event @s ")) { events.fire(c.substring("ukgabriel event @s ".length()), this); return; }
        Matcher m = IF_TAG.matcher(c);
        if (m.matches()) { if (tags.contains(m.group(2)) != m.group(1).equals("!")) command(m.group(3)); return; }
        m = IF_FORM.matcher(c);
        if (m.matches()) { if (prop("gabriel:form") == Integer.parseInt(m.group(1))) command(m.group(2)); return; }
        if (IF_NEAR.matcher(c).matches()) { if (playerNear) tags.add("g_close"); return; }
        if (c.matches("tag @s add \\w+")) { tags.add(c.substring(11)); return; }
        if (c.matches("tag @s remove \\w+")) { tags.remove(c.substring(14)); return; }
    }

    @SuppressWarnings("unchecked")
    public static void main(String[] a) throws Exception {
        String res = a[0];
        Map<String, Object> ent = (Map<String, Object>) ParticleCoreTest.parse(Files.readString(Path.of(res, "ai/entity.json")));
        Map<String, BedrockController> ctls = BedrockController.parse(ParticleCoreTest.parse(Files.readString(Path.of(res, "ai/controllers.json"))));
        Map<String, Timeline> tls = Timeline.parse(ParticleCoreTest.parse(Files.readString(Path.of(res, "ai/timelines.json"))));
        Map<String, String> aliases = new HashMap<>();
        for (Map.Entry<String, Object> e : ((Map<String, Object>) ent.get("animations")).entrySet()) aliases.put(e.getKey(), (String) e.getValue());

        BrainTest h = new BrainTest();
        for (Map.Entry<String, Object> e : ((Map<String, Object>) ent.get("properties")).entrySet()) {
            Map<String, Object> p = (Map<String, Object>) e.getValue();
            h.props.put(e.getKey(), ((Number) p.get("default")).intValue());
            List<Object> r = (List<Object>) p.get("range");
            h.ranges.put(e.getKey(), new int[]{((Number) r.get(0)).intValue(), ((Number) r.get(1)).intValue()});
        }
        h.events = new BedrockEvents((Map<String, Object>) ent.get("events"));
        h.events.fire("minecraft:entity_spawned", h);
        BrainRuntime brain = new BrainRuntime(h, ctls, tls, aliases, List.of("brain", "phase"));

        // scripted fight: ai.js role = raise go when idle; "player" role = deal damage after a while in each stage
        Map<String, Integer> visited = new TreeMap<>();
        Map<String, Integer> stageEnter = new LinkedHashMap<>();
        String lastState = null; int stageTicks = 0, lastStage = -1, entryTick = 0;
        List<int[]> m1Plays = new ArrayList<>();      // entry tick of each m1_s1 play
        int maxTicks = 60 * 60 * 20;
        boolean defeated = false;
        for (h.tick = 0; h.tick < maxTicks && !defeated; h.tick++) {
            String st = brain.stateOf("brain");
            if (st.equals("idle") && h.prop("gabriel:go") == 0 && h.prop("gabriel:busy") == 0) h.setProp("gabriel:go", 1);
            int stage = h.prop("gabriel:stage");
            if (stage != lastStage) { lastStage = stage; stageTicks = 0; stageEnter.put("stage" + stage, h.tick); }
            stageTicks++;
            if (stageTicks > Integer.getInteger("dwell", 1200)) {
                switch (stage) {
                    case 1 -> h.hp = h.max * 0.45;
                    case 2 -> h.hp = h.max * 0.05;
                    case 4 -> h.hp = h.max * 0.45;
                    case 5 -> h.hp = h.max * 0.02;
                    default -> { }
                }
            }
            int before = h.log.size();
            brain.tick(DT);
            String now = brain.stateOf("brain");
            if (!now.equals(st) || h.tick == 0) {
                visited.merge(now, 1, Integer::sum);
                if (now.equals("m1_s1")) m1Plays.add(new int[]{h.tick});
            }
            if (now.equals("t_defeat")) { /* run it to completion */ }
            if (stage == 6 && now.equals("idle")) defeated = true;
        }
        System.out.println("simulated ticks: " + h.tick + "  (" + h.tick / 1200.0 + " min)  commands emitted: " + h.log.size());
        System.out.println("stage timeline (tick of entry): " + stageEnter);
        System.out.println("brain states visited: " + visited);
        Set<String> allBrain = new TreeSet<>(ctls.get("controller.animation.gabriel.brain").states.keySet());
        allBrain.removeAll(visited.keySet());
        System.out.println("brain states never visited: " + allBrain);

        for (String must : new String[]{"intro", "choose", "m1_s1", "taunt_s1", "rest_s1", "t_joh2", "m1_s2", "t_aoh", "t_aoh_b", "t_aoh2", "t_defeat", "m1_s4", "m1_s5"})
            check(visited.containsKey(must), "state never visited: " + must);
        check(stageEnter.containsKey("stage6") || h.prop("gabriel:stage") == 6, "never reached stage 6 (defeat)");
        check(h.prop("gabriel:form") == 1 && h.prop("gabriel:defeat") == 1, "defeat flags form/defeat not set");

        // timing: every timeline command of the first m1_s1 play must fire at its original time
        Timeline m1 = tls.get("animation.gabriel.ai.m1_s1");
        int t0 = m1Plays.get(0)[0];
        List<Rec> played = new ArrayList<>();
        for (Rec r : h.log) if (r.tick >= t0 && r.tick < t0 + (int) Math.round(m1.length / DT) + 2) played.add(r);
        int inTimeline = 0;
        for (Rec r : played) if (!r.cmd.startsWith("ukgabriel event @s gabriel:move_0") && !r.cmd.startsWith("ukgabriel event @s gabriel:combo_up")) inTimeline++;
        System.out.println("m1_s1: length=" + m1.length + "s, commands in file=" + m1.commandCount() + ", seen in window=" + inTimeline);
        check(inTimeline >= m1.commandCount(), "m1_s1 emitted fewer commands than its timeline defines");
        System.out.println("controller+timeline+events integration finished; failures=" + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
