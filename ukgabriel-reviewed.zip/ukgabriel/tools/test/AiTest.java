import com.ukgabriel.ai.*;
import java.util.*;

public class AiTest {
    static int fails = 0;
    static void check(boolean ok, String m) { if (!ok) { fails++; System.out.println("FAIL: " + m); } }

    public static void main(String[] a) {
        // ---- tiers (difficulty.js) ----
        GabrielTier mb = GabrielTier.of(5), std = GabrielTier.of(2);
        check(Math.abs(mb.pace() - 2.625) < 1e-9 && mb.proj() == 2.0 && Math.abs(mb.mobPct() - 0.21) < 1e-9 && mb.mobCap() == 1200 && mb.hp() == 15000 && mb.antiHeal() && mb.varied(), "Mob Battle tier numbers");
        check(std.armorCap() == 0.03 && std.pace() == 1.0 && !std.varied() && std.hp() == 0, "Standard tier numbers");
        check(GabrielTier.defaultIndexFor("PEACEFUL") == 0 && GabrielTier.defaultIndexFor("easy") == 1 && GabrielTier.defaultIndexFor("normal") == 2 && GabrielTier.defaultIndexFor("hard") == 3, "world difficulty -> tier");
        check(GabrielTier.indexOf("mob_battle") == 5 && GabrielTier.indexOf("Brutal") == 4, "tier lookup");
        // damage.js scaled(): player takes wiki number; 200hp mob takes max(35, 7% of 200 = 14) = 35; 1000hp mob: 70 -> 70; huge mob capped at 400
        check(std.scaledDamage(true, 20, 35) == 35, "player dmg 35");
        check(std.scaledDamage(false, 200, 35) == 35 && std.scaledDamage(false, 1000, 35) == 70 && std.scaledDamage(false, 100000, 35) == 400, "mob dmg scaling and cap");
        check(mb.scaledDamage(false, 1000, 35) == 210 && mb.scaledDamage(false, 100000, 35) == 1200, "Mob Battle mob scaling");
        check(std.scaledDamage(true, 20, 0.2) == 1, "minimum 1 damage");

        // ---- move picking (pickMove) ----
        Map<String, Integer> props = new HashMap<>(Map.of("gabriel:tier", 2, "gabriel:throw", 0));
        MovePicker.Props pr = new MovePicker.Props() { public int get(String n) { return props.get(n); } public void set(String n, int v) { props.put(n, v); } };
        Random rng = new Random(11);
        MovePicker.State st = new MovePicker.State();
        int[] seq = new int[12];
        for (int i = 0; i < 12; i++) seq[i] = MovePicker.pick(pr, st, 1, 4, rng);
        check(seq[3] == 20 && seq[7] == 20 && seq[11] == 20, "taunt (20) on every 4th pick at tier>=2: " + Arrays.toString(seq));
        for (int i = 1; i < 12; i++) if (seq[i] != 20 && seq[i - 1] != 20) check(seq[i] != seq[i - 1], "never repeats last move: " + Arrays.toString(seq));
        props.put("gabriel:tier", 1); st = new MovePicker.State();
        check(MovePicker.pick(pr, st, 1, 4, rng) != 20 && MovePicker.pick(pr, st, 1, 4, rng) != 20 && MovePicker.pick(pr, st, 1, 4, rng) == 20, "taunt every 3rd at tier<=1");
        props.put("gabriel:tier", 2);
        // judge, far band: weights m1:4 m2:0 m3:1 m4:5 -> m2 never; after axe thrown m4 excluded and throw set on first use
        Map<Integer, Integer> hist = new TreeMap<>();
        props.put("gabriel:throw", 0);
        for (int i = 0; i < 4000; i++) { st = new MovePicker.State(); st.sinceTaunt = -99; props.put("gabriel:throw", 0); hist.merge(MovePicker.pick(pr, st, 2, 20, rng), 1, Integer::sum); }
        check(!hist.containsKey(2) && hist.get(4) > hist.get(1) * 1.05 && hist.get(1) > hist.get(3) * 2, "joh far-band weights " + hist);
        props.put("gabriel:throw", 1); hist.clear();
        for (int i = 0; i < 2000; i++) { st = new MovePicker.State(); st.sinceTaunt = -99; hist.merge(MovePicker.pick(pr, st, 2, 20, rng), 1, Integer::sum); }
        check(!hist.containsKey(4), "axe already used -> move 4 excluded " + hist);
        props.put("gabriel:throw", 0); st = new MovePicker.State(); st.sinceTaunt = -99;
        for (int i = 0; i < 400 && props.get("gabriel:throw") == 0; i++) { st.lastMove = 0; MovePicker.pick(pr, st, 1, 20, rng); }
        check(props.get("gabriel:throw") == 1, "choosing 4 as judge sets gabriel:throw");
        int fours = 0, n = 5000;
        for (int i = 0; i < n; i++) { st = new MovePicker.State(); st.sinceTaunt = -99; st.lastMove = 1; if (MovePicker.pick(pr, st, 4, 3, rng) == 4) fours++; }
        check(fours > n * 0.55 && fours < n * 0.75, "apostate: after move 1, move 4 ~55% + weighted share, got " + fours / (double) n);

        // ---- movement (chase / stepTo) ----
        Movement.Clear open = (x, y, z) -> true;
        Random r2 = new Random(5);
        Movement.State ms = new Movement.State(r2);
        double[] boss = {60, 80, 0}, tgt = {0, 64, 0};
        double maxStep = 0; int closeTick = -1;
        double minFlat = 1e9, maxFlat = 0;
        for (int t = 0; t < 3000; t++) {
            Movement.Goal g = Movement.chase(ms, boss, tgt, 1, 1.0, t, r2, open);
            double[] d = Movement.stepTo(boss, g.x(), g.y(), g.z(), g.speed(), open);
            if (d != null) { maxStep = Math.max(maxStep, Math.sqrt(Math.pow(d[0]-boss[0],2)+Math.pow(d[1]-boss[1],2)+Math.pow(d[2]-boss[2],2))); boss = d; }
            double flat = Math.hypot(boss[0] - tgt[0], boss[2] - tgt[2]);
            if (closeTick < 0 && flat < 12) closeTick = t;
            if (t > 400) { minFlat = Math.min(minFlat, flat); maxFlat = Math.max(maxFlat, flat); }
        }
        check(maxStep <= 1.1 + 1e-9, "step never exceeds catch-up speed: " + maxStep);
        check(closeTick > 30 && closeTick < 120, "catches up from 60 blocks in ~50 ticks, got " + closeTick);
        check(minFlat > 4.5 && maxFlat < 11, "orbits inside the engage band after catch-up: " + minFlat + ".." + maxFlat);
        check(boss[1] > tgt[1] && boss[1] < tgt[1] + 5, "hovers just above the target, y=" + boss[1]);
        // blocked goal flips orbit direction; fully blocked stepTo returns null
        Movement.State bs = new Movement.State(new Random(1)); int before = bs.dir;
        Movement.Goal g = Movement.chase(bs, new double[]{8, 65, 0}, new double[]{0, 64, 0}, 1, 1.0, 1000, new Random(2), (x, y, z) -> false);
        check(bs.flipAt == 1040 && g != null, "blocked orbit goal schedules a flip");
        check(Movement.stepTo(new double[]{0, 0, 0}, 5, 0, 0, 1, (x, y, z) -> false) == null, "stuck stepTo");
        double[] ci = Movement.closeInGoal(new double[]{0, 0, 0}, new double[]{10, 0, 0});
        check(ci != null && Math.abs(ci[0] - 1.6) < 1e-9 && Movement.closeInGoal(new double[]{0, 0, 0}, new double[]{1.5, 0, 0}) == null, "closeIn step");
        check(Math.abs(Movement.yawOf(0, 1)) < 1e-4 && Math.abs(Movement.yawOf(-1, 0) - 90) < 1e-4, "yawOf convention");
        System.out.println("AI port checks done; failures=" + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
