import com.ukgabriel.bedrock.molang.Molang;
import com.ukgabriel.bedrock.particle.*;
import java.io.File;
import java.nio.file.Files;
import java.util.*;

public class ParticleCoreTest {
    // --- minimal JSON parser (test only; the mod uses Gson) ---
    static String s; static int i;
    static Object parse(String src) { s = src; i = 0; return val(); }
    static void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
    static Object val() {
        ws(); char c = s.charAt(i);
        if (c == '{') { i++; Map<String,Object> m = new LinkedHashMap<>(); ws(); if (s.charAt(i)=='}') {i++; return m;}
            while (true) { ws(); String k = str(); ws(); i++; m.put(k, val()); ws(); if (s.charAt(i)==',') {i++; continue;} i++; return m; } }
        if (c == '[') { i++; List<Object> l = new ArrayList<>(); ws(); if (s.charAt(i)==']') {i++; return l;}
            while (true) { l.add(val()); ws(); if (s.charAt(i)==',') {i++; continue;} i++; return l; } }
        if (c == '"') return str();
        if (s.startsWith("true", i)) { i += 4; return true; }
        if (s.startsWith("false", i)) { i += 5; return false; }
        if (s.startsWith("null", i)) { i += 4; return null; }
        int j = i; while (j < s.length() && "+-0123456789.eE".indexOf(s.charAt(j)) >= 0) j++;
        double d = Double.parseDouble(s.substring(i, j)); i = j; return d;
    }
    static String str() { i++; StringBuilder b = new StringBuilder(); while (s.charAt(i) != '"') { if (s.charAt(i)=='\\') { i++; char e = s.charAt(i); b.append(e=='n'?'\n':e); } else b.append(s.charAt(i)); i++; } i++; return b.toString(); }

    static int fails = 0;
    static void check(boolean ok, String msg) { if (!ok) { fails++; System.out.println("FAIL: " + msg); } }
    static boolean near(double a, double b) { return Math.abs(a - b) < 1e-3; }

    public static void main(String[] a) throws Exception {
        // Molang unit checks
        Molang.Scope sc = new Molang.Scope() { public double get(String n) { return n.equals("v.x") ? 4 : 0; } };
        check(near(Molang.compile("1 + 2 * 3").eval(sc), 7), "precedence");
        check(near(Molang.compile("Math.pow(v.x, 2) + variable.x").eval(sc), 20), "pow/var alias");
        check(near(Molang.compile("v.x > 3 ? 10 : 20").eval(sc), 10), "ternary");
        check(near(Molang.compile("math.min(v.x / 8, 1)").eval(sc), 0.5), "min");
        check(near(Molang.compile("math.sin(90)").eval(sc), 1), "sin degrees");
        check(near(Molang.compile("1 - Math.max(0, ((v.x / 8) - 0.6) / 0.4)").eval(sc), 1 - 0), "nested max");

        File dir = new File(a[0]);
        File[] files = dir.listFiles((d, n) -> n.endsWith(".json"));
        Arrays.sort(files);
        int ok = 0;
        for (File f : files) {
            ParticleDef def = ParticleDef.parse(parse(Files.readString(f.toPath())));
            BedrockEmitter e = new BedrockEmitter(def, 0, 0, 0, 42);
            int peak = 0, ticks = 0; double maxSize = 0;
            BedrockParticle.Sample smp = new BedrockParticle.Sample();
            while (!e.done() && ticks < 2000) {
                e.tick(0.05); ticks++;
                peak = Math.max(peak, e.particles.size());
                for (BedrockParticle p : e.particles) {
                    p.sample(0.02, smp);
                    check(!Double.isNaN(smp.w + smp.h + smp.red + smp.alpha + (float) smp.x + (float) smp.y), f.getName() + " NaN sample");
                    check(smp.alpha >= -1e-4 && smp.alpha <= 1.0001, f.getName() + " alpha range " + smp.alpha);
                    maxSize = Math.max(maxSize, Math.max(smp.w, smp.h));
                }
            }
            check(ticks < 2000, f.getName() + " never finished");
            check(peak > 0, f.getName() + " spawned nothing");
            System.out.printf("%-34s %-26s mat=%-15s peak=%3d ticks=%3d maxSize=%.2f%n", f.getName(), def.identifier, def.material, peak, ticks, maxSize);
            ok++;
        }
        // exact-value checks taken straight from gabriel_blast_core.json
        ParticleDef core = ParticleDef.parse(parse(Files.readString(new File(dir, "gabriel_blast_core.json").toPath())));
        BedrockEmitter ce = new BedrockEmitter(core, 0, 0, 0, 1);
        ce.tick(0.0);                       // spawn
        BedrockParticle p = ce.particles.get(0);
        BedrockParticle.Sample sm = new BedrockParticle.Sample();
        p.age = 0.12; p.lifetime = 1.1; p.sample(0, sm);
        check(near(sm.w, 0.6 + 6.4 + 0.5 * 0.12), "blast_core size at 0.12s = " + sm.w);
        p.age = 0.385; p.sample(0, sm);     // t = 0.35 -> stop #FFFFC640
        check(near(sm.red, 1f) && near(sm.green, 0xC6 / 255f) && near(sm.blue, 0x40 / 255f) && near(sm.alpha, 1f), "gradient stop 0.35 rgba=" + sm.red + "," + sm.green + "," + sm.blue + "," + sm.alpha);
        p.age = 1.1; p.sample(0, sm);
        check(near(sm.alpha, 0f), "gradient end alpha");
        System.out.println(ok + " particle definitions loaded and simulated; failures=" + fails);
        System.exit(fails == 0 ? 0 : 1);
    }
}
