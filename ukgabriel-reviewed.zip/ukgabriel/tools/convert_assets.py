#!/usr/bin/env python3
"""Converts Gabriel's assets from Ultrakill.mcaddon (extracted) into a Forge 1.20.1 resource tree.
Nothing is simplified: geo/animation/particle JSON is carried over verbatim (GeckoLib reads Bedrock
geo 1.12.0 + animation 1.8.0 natively; particle JSON is interpreted by the mod's own Bedrock particle runtime)."""
import json, os, re, shutil, sys

SRC = sys.argv[1]            # extracted addon root (contains UltrakillRP, UK BP)
OUT = sys.argv[2]            # project root
MOD = 'ukgabriel'
RP = os.path.join(SRC, 'UltrakillRP')
RES = os.path.join(OUT, 'src/main/resources/assets', MOD)
DATA = os.path.join(OUT, 'src/main/resources/data', MOD)

def jload(p): return json.load(open(p, encoding='utf-8'))
def jdump(o, p):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    json.dump(o, open(p, 'w', encoding='utf-8'), indent=1, ensure_ascii=False)
def cp(src, dst):
    os.makedirs(os.path.dirname(dst), exist_ok=True); shutil.copyfile(src, dst)

report = {}

# 1. geometry: one geometry per file so GeckoLib can address each by name
n = 0
for f in ['gabriel', 'gabriel_judge', 'gabriel_projectiles', 'gabriel_judge_projectiles']:
    g = jload(f'{RP}/models/entity/{f}.geo.json')
    for geo in g['minecraft:geometry']:
        name = geo['description']['identifier'].replace('geometry.', '')
        jdump({'format_version': g['format_version'], 'minecraft:geometry': [geo]}, f'{RES}/geo/{name}.geo.json')
        n += 1
report['geometries'] = n

# 2. animations (Bedrock 1.8.0 files, verbatim). Shared RP anims + the BP timeline anims split by purpose.
n = 0
for f in ['gabriel', 'gabriel_judge']:
    d = jload(f'{RP}/animations/{f}.animation.json')
    jdump(d, f'{RES}/animations/{f}.animation.json'); n += len(d['animations'])
d = jload(f'{SRC}/UK BP/animations/gabriel_ai.animation.json')
jdump(d, f'{RES}/animations/gabriel_ai.animation.json'); n += len(d['animations'])
report['animations'] = n
# animation controllers (RP + BP) are kept as data for the Java state machine port
for src, dst in [(f'{RP}/animation_controllers/gabriel.animation_controllers.json', 'gabriel.animation_controllers.json'),
                 (f'{SRC}/UK BP/animation_controllers/gabriel_ai.controllers.json', 'gabriel_ai.controllers.json')]:
    cp(src, f'{RES}/animation_controllers/{dst}')

# 3. particles: Gabriel's own + the shared uk: ones Gabriel's timelines / functions / projectiles spawn
PARTICLES = {
 'gabriel_blast_bolts','gabriel_blast_core','gabriel_blast_shell','gabriel_dash_trail','gabriel_enrage_ring','gabriel_light_pillar',
 'flash','flash_yellow','gold_shards','orange_glow','shockwave_cyan','shockwave_orange','shockwave_white','soul_burst','sp_rays',
 'sprime_shockwave_orange','blue_dust'}
used_tex, ids = set(), []
for p in sorted(os.listdir(f'{RP}/particles')):
    stem = p.replace('.particle.json', '').replace('.json', '')
    if stem not in PARTICLES: continue
    d = jload(f'{RP}/particles/{p}')
    ids.append(d['particle_effect']['description']['identifier'])
    t = d['particle_effect']['description']['basic_render_parameters']['texture']
    used_tex.add(t)
    jdump(d, f'{RES}/bedrock_particles/{stem}.json')
report['particles'] = sorted(ids)
report['particle_textures'] = sorted(used_tex)
tex_missing = []
for t in sorted(used_tex):
    s = f'{RP}/{t}.png'
    if os.path.exists(s): cp(s, f'{RES}/{t}.png')
    else: tex_missing.append(t)
report['particle_textures_missing'] = tex_missing

# 4. entity textures (all gabriel/*), vfx textures not needed by Gabriel
for f in os.listdir(f'{RP}/textures/entity/gabriel'):
    cp(f'{RP}/textures/entity/gabriel/{f}', f'{RES}/textures/entity/gabriel/{f}')

# 5. sounds -> sounds.json (Java format), ogg copied to sounds/gabriel
sd = jload(f'{RP}/sounds/sound_definitions.json')['sound_definitions']
out, n_ogg = {}, 0
for k, v in sd.items():
    if not k.startswith('gabriel'): continue
    lst = []
    for s in v['sounds']:
        s = {'name': s} if isinstance(s, str) else dict(s)
        s['name'] = f"{MOD}:" + s['name'].replace('sounds/', '', 1)
        s.pop('load_on_low_memory', None)
        lst.append(s)
    out[k] = {'sounds': lst}
jdump(out, f'{RES}/sounds.json')
for f in os.listdir(f'{RP}/sounds/gabriel'):
    cp(f'{RP}/sounds/gabriel/{f}', f'{RES}/sounds/gabriel/{f}'); n_ogg += 1
report['sound_events'] = len(out); report['ogg_files'] = n_ogg

# 6. lang
lang = {}
for line in open(f'{RP}/texts/en_US.lang', encoding='utf-8'):
    if '=' not in line or 'gabriel' not in line: continue
    k, v = line.rstrip('\n').split('=', 1)
    m = re.match(r'entity\.gabriel:(\w+)\.name', k)
    if m: lang[f'entity.{MOD}.{m.group(1)}'] = v
    m = re.match(r'item\.spawn_egg\.entity\.gabriel:(\w+)\.name', k)
    if m: lang[f'item.{MOD}.{m.group(1)}_spawn_egg'] = v
jdump(lang, f'{RES}/lang/en_us.json')

# 7. render-controller + client-entity + particle-table data kept verbatim for reference/runtime
cp(f'{RP}/entity/gabriel.entity.json', f'{RES}/client_entity/gabriel.entity.json')
cp(f'{RP}/render_controllers/gabriel.render_controllers.json', f'{RES}/client_entity/gabriel.render_controllers.json')

# 8. difficulty subpacks (tier data) copied for the Java difficulty port
for sp in os.listdir(f'{SRC}/UK BP/subpacks'):
    p = f'{SRC}/UK BP/subpacks/{sp}/scripts/difficulty.js'
    if os.path.exists(p): cp(p, f'{DATA}/reference/subpacks/{sp}_difficulty.js')
# original scripts kept as the porting reference
for f in os.listdir(f'{SRC}/UK BP/scripts/gabriel'):
    cp(f'{SRC}/UK BP/scripts/gabriel/{f}', f'{OUT}/reference/scripts/gabriel/{f}')
for f in os.listdir(f'{SRC}/UK BP/functions/gabriel'):
    cp(f'{SRC}/UK BP/functions/gabriel/{f}', f'{OUT}/reference/functions/gabriel/{f}')
for f in ['gabriel.entity.json','sword_beam.entity.json','light_axe.entity.json','light_greatsword.entity.json','sword_throw.entity.json','spiral_sword.entity.json','spiral_swords.entity.json','orbit_sensor.entity.json']:
    cp(f'{SRC}/UK BP/entities/{f}', f'{OUT}/reference/entities/{f}')

# 9. loot table (Bedrock -> Java format)
src = jload(f'{SRC}/UK BP/loot_tables/entities/gabriel.json')
def _rolls(r): return r if isinstance(r, int) else {'type': 'minecraft:uniform', 'min': r['min'], 'max': r['max']}
pools = []
for p_ in src['pools']:
    ents = []
    for e in p_['entries']:
        je = {'type': 'minecraft:item', 'name': e['name'], 'weight': e.get('weight', 1)}
        for f in e.get('functions', []):
            je.setdefault('functions', []).append({'function': 'minecraft:set_count', 'count': _rolls(f['count'])})
        ents.append(je)
    pools.append({'rolls': _rolls(p_['rolls']), 'entries': ents})
jdump({'type': 'minecraft:entity', 'pools': pools}, f'{DATA}/loot_tables/entities/gabriel.json')

jdump(report, f'{OUT}/tools/conversion_report.json')
print(json.dumps(report, indent=1))
