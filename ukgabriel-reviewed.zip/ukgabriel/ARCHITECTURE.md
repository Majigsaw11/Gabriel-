# Gabriel (Ultrakill) -> Forge 1.20.1 port: architecture and status

Mod id `ukgabriel`, package `com.ukgabriel`. Target: Forge 47.x, GeckoLib 4.x (`geckolib-forge-1.20.1`).

## Findings from the add-on
* Only `geometry.gabriel_ultrakill_judge` is rendered (both forms). `geometry.gabriel` and the 20 animations in
  `gabriel.animation.json` (except projectile ones) target its bones only; they are kept but never drive the visible model.
* RP controllers (`combat`, `joh`, `aoh`) map synced int `gabriel:anim` -> animation(s). 60 states, all reachable (tested).
* BP controllers (`brain`, `phase`, `ring`, `proj`) are the boss brain: `phase` watches HP (stage 1->2 at 50%, 2->3 at 8%,
  4->5 at 50%, 4/5->defeat at 3%), `brain` picks moves from `gabriel:move/next/stage/combo/tier`, each state plays a BP
  animation whose `timeline` holds ~1048 timed Bedrock commands, `on_entry` entries are `@s gabriel:<event>` entity events.
* Animations use catmullrom interpolation and Molang (`query.anim_time`, `query.life_time`, `math.random`, `math.sin`).
* Animation keyframes emit particles `ring` (-> gabriel:enrage_ring) and `trail`, and sound `spawn`.

## Layers
1. `bedrock.molang.Molang` - interpreter incl. `query.name('arg')`.            [done, tested]
2. `bedrock.particle.*`   - Bedrock particle runtime (17 effects) + `BillboardMath` (7 facing modes).  [core + maths tested; `client/BedrockParticles` renderer written, UNTESTED in-game]
3. `bedrock.BedrockController` - controller state machines (RP and BP).          [done, tested]
4. `Timeline` + `BrainRuntime` + `BedrockEvents`: BP brain/phase controllers, timed timeline commands, entity events.  [done, tested headless: full fight intro->s1->s2->cutscene->s4->s5->defeat, commands fire at original times]
5. Command translation Bedrock -> Java 1.20.1 (`tools/translate_commands.py`; 1175/1175 translated, lint clean; syntax NOT yet verified by Minecraft's parser): `@n` -> `@e[sort=nearest,limit=1]`, `r=` -> `distance=..`,
   `m=` -> `gamemode=`, `family=` -> entity type tags, `playsound`/`effect`/`titleraw`/`tp ... facing` syntax; custom mod commands
   for `event`, `particle <bedrock id>`, `scriptevent gabriel:sub`, `camera`, `hud`, `inputpermission`.   [done]
6. Entity events: interpreter done (`BedrockEvents`); still TODO in Forge glue: apply component groups (health, speed, damage immunity, boss bar, instant despawn).
7. Scripts port (scripts/gabriel/*.js):
   * ai.js tickBoss/chase/stepTo/closeIn/pickMove/targeting -> `ai.{Movement,MovePicker}` (pure, tested) + `entity.GabrielAi` (Forge, untested).
   * difficulty.js -> `ai.GabrielTier` (tested) + `ai.TierData` (`/ukgabriel tier [name|default]`; default follows world difficulty).
   * damage.js, armor.js, target.js, anti_heal.js -> `entity.GabrielDamage` + `ai.AntiHeal` (Forge events, untested).
   * main.js music loop -> `entity.GabrielMusic` + `client.GabrielMusicClient` (no 1 s fade). main.js cutscene cleanup -> `entity.CutsceneCleanup`.
   * scriptevents close/ground/taunt/skip_aoh_intro/spiral -> `GabrielScripts` (+ `Swarms` = ai.js orbit/strike swarm, re-checked line by line against the original).
   * projectiles.js -> `ai.FlightMath` (pure, tested) + `entity.GabrielProjectile` (all 7 BP entity types; flight/parry/reflect/aftermath) + `ProjectileData` (translated BP events).
   * Intentionally NOT ported: chara_buffs.js hooks (another boss's system; treated as identity), summon_rules.js.
8. Projectiles: sword_beam, sword_throw, light_axe, light_greatsword, spiral_sword(s), orbit_sensor + impact/end functions.  [TODO]
9. Client: GeckoLib model/renderer + texture rule + RP controller glue (`RpAnimator`, tested) written, UNTESTED in-game. Cutscenes: `client.CutsceneClient` (free camera via a client Marker, fade overlay, HUD hide, input locks) - untested in game. Particle `locator`s are ignored (effects spawn at the entity origin).

## Tests (pure Java 21, no Minecraft)
`tools/test/ParticleCoreTest.java`, `tools/test/ControllerTest.java`.

## Known gaps / next
* `m6_s2`/`m6_s5` need `gabriel:next` = 5/6, which only the (unported) swarm/projectile logic and special cases set; verify in game.
* Custom commands to implement in Java: `/ukgabriel event|particle|summon|script|sub|camera|hud|input` (see tools/translate_commands.py header).
* Selector notes: `has_property` -> `nbt={GabForm:N}` so the entity must save `GabForm`, `GabStage`, ... in NBT; Bedrock families -> entity type tags
  `ukgabriel:family/*` (data/ukgabriel/tags/entity_types/family; `sam` is an empty tag).
* Run tests: javac all of src/main/java + tools/test, then `java BrainTest src/main/resources/data/ukgabriel` etc.

## Forge layer status (written without being able to compile against Forge/GeckoLib)
Files: UkGabrielMod, registry/{ModEntities,ModSounds,ModItems,SoundNames}, entity/{GabrielEntity,AiData,EventTarget,Subtitles,GabrielScripts,GabrielAiStub},
command/{ModCommands,ModNetwork}, client/{GabrielAnimation,GabrielModel,GabrielRenderer,ClientSetup,BedrockParticles}.
Checked: parses with javac (only missing-library symbol errors). NOT checked: Forge 47.x / GeckoLib 4.4.9 API names, runtime behaviour.
Build: add the Gradle wrapper (copy from a Forge 1.20.1 MDK), run `./gradlew build`, then `./gradlew runClient`.
Not implemented: loot table, particle locators, `spiral_swords` ring is registered but nothing in the add-on spawns it.

## Tests (pure Java): ParticleCoreTest, ControllerTest, BrainTest, RpAnimatorTest, BillboardTest, AiTest, FlightTest, ProjectileTest
Also verified offline: all 484 translated /ukgabriel commands match the implemented command grammar (see tools/translate_commands.py).
